<?php 

/**
 * 
 */
class Module_Admin_Request_Login extends Request
{
    
    
}