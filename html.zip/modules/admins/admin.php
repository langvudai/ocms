<?php 

return array(
    array(
        '' => function() {},
        '/' => array('class' => 'Module_Admin_Controller_Index::index'),
        'login' => array('class' => 'Module_Admin_Controller_Login::index'),
        'check-login' => array('class' => 'Module_Admin_Controller_Login::checkLogin'),
        'logout' => array('class' => 'Module_Admin_Controller_Login::logout'),
        'password' => array(
            'class' => 'Module_Admin_Controller_Password::index',
            // 'args' => function() {
            //     // return array(
            //     //     'method' => 'index'
            //     // );
            //     return array(
            //         'method' => Request::getMethod() == Request::POST ? 'save' : 'index'
            //     );
            // }
        ),
        'password-change' => array('class' => 'Module_Admin_Controller_Password::change'),
    ),
    function($_this) {
        include_once 'helper.php';
        Template::setViewDir(__DIR__.DS.'views');
        Template::setCompilerDir(DA.DS.'data'.DS.'views');
        // echo ord('w');
        // echo base_convert(uniqid(), 10, 32);
        // echo session()->uniqid();
        // echo '0'.chr(rand(119, 122)).base_convert(rand(111111, 999999), 10, 32).base_convert(uniqid(), 16, 32).base_convert(time(), 10, 32);
    }
);