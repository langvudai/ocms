<?php 

return array(
    array(
        '' => function() {},
        '/' => array('class' => 'Module_Admin_Controller_Index::index'),
        'login' => array('class' => 'Module_Admin_Controller_Login::index'),
        'logout' => array('class' => 'Module_Admin_Controller_Login::logout'),
        'password' => array('class' => 'Module_Admin_Controller_Password::index'),
    ),
    function($_this) {
        include_once 'helper.php';
        Template::setViewDir(__DIR__.DS.'views');
        Template::setCompilerDir(DA.DS.'data'.DS.'views');
        // echo ord('w');
        // echo base_convert(uniqid(), 10, 32);
        // echo session()->uniqid();
        // echo '0'.chr(rand(119, 122)).base_convert(rand(111111, 999999), 10, 32).base_convert(uniqid(), 16, 32).base_convert(time(), 10, 32);
    }
);