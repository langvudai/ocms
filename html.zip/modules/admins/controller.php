<?php 

/**
 * 
 */
class Module_Admin_Controller extends Base
{
    private $messages;

    final function run()
    {
        $user_id = session()->user_id;
        if (!$user_id) {
            redirect('/login');
            exit();
        }
        if ($this->app->uniqid !== session()->uniqid()) {
            redirect('/login');
            exit();
        }
        $model = new Module_Admin_Model_Auth($user_id);
        // // $user = new 
        Template::setUserModel($model);
        $this->auth = $model;
        parent::run();
    }

    protected final function message($message = null, $type = null)
    {
        if (!$message) {
            $messages = session()->get('messages');
            session()->delete('messages');
            return $messages;
        }

        if (!$this->messages) {
            $this->messages = array(array($message, $type));
        } else {
            $this->messages[] = array($message, $type);
        }
    }

    public function __destruct()
    {
        if ($this->messages) {
            session()->set('messages', $this->messages);
        }
    }
}