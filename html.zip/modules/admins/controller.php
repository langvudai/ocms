<?php 

/**
 * 
 */
class Module_Admin_Controller extends Base
{
    
    function __construct()
    {
        $user_id = session()->user_id;
        if (!$user_id) {
            redirect('/login');
            exit();
        }
        if ($this->app->uniqid !== session()->uniqid()) {
            redirect('/login');
            exit();
        }
        $model = new Module_Admin_Model_Auth($user_id);
        // // $user = new 
        Template::setUserModel($model);
    }
}