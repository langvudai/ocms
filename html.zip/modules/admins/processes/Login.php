<?php 

/**
 * 
 */
class Module_Admin_Process_Login extends Db_Sql
{
    function transactionConfirmUserPass(Module_Admin_Request_Login $request)
    {
        $username = preg_replace('/[^a-z0-9]+/i','',$request->username);
        $query = $this->select()
            ->from(array('u'=>'users'), 'id, password, salt')
            ->innerJoin('user_role', 'u.id=user_id')
            ->where(Db_Where::isNull('u.deleted_time'))
            ->where('actived', 1)
            ->where('username', $username)
            ->query();
        $user = $query->fetchRow();
        /*var_dump($user);
        var_dump($request->password);
        var_dump($this->getPassword($request->password, $user['salt']));
        exit;*/
        if ($user) {
            if ($this->getPassword($request->password, $user['salt']) == $user['password']) {
                $this->_name = 'users';
                $this->update(array(
                    'last_access' => 'login',
                    'updated_time'=>time(), 
                    // 'dtoken'=>$this->createDToken(), 
                ), 'id='.$user['id']);
                return $user['id'];
            } else {
                $this->error = 'invalid password';
            }
        } else {
            $this->error = 'username not exist';
        }
        return 0;
    }

    function verifyCurrentPassword($id, $password)
    {
        $user = $this->select()
            ->from(array('u'=>'users'), 'password, salt')
            ->innerJoin('user_role', 'u.id=user_id')
            ->where(Db_Where::isNull('u.deleted_time'))
            ->where('actived', 1)
            ->where('u.id', $id)
            ->query()
            ->fetchRow();
        
        if (!$user) {
            return false;
        }
        
        return $this->getPassword($password, $user['salt']) === $user['password'];
    }

    function getPassword($password, $salt)
    {
        return sha1(sha1($password).$salt);
    }

    function generatorSalt()
    {
        $a = range('!', '~');
        shuffle($a);
        return implode('', array_slice($a, rand(0, 75), 15));
    }

    function updatePassword($id, $password)
    {
        // print_r(func_get_args());
        $this->transaction();
        $this->_name = 'users';
        $salt = $this->generatorSalt();
        $result = $this->update(array(
            'salt' => $salt,
            'password' => $this->getPassword($password, $salt),
            'updated_time'=>time(), 
        ), 'id='.$id);
        $this->endTransaction();
        return $result;
    }
}