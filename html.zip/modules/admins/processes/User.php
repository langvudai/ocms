<?php 

class Module_Admin_Process_User extends Db_Sql
{
    public function verifyCurrentPassword($id, $password)
    {
        $user = $this->select()
            ->from(array('u'=>'users'), 'id, password, salt')
            ->innerJoin('user_role', 'u.id=user_id')
            ->where(Db_Where::isNull('u.deleted_time'))
            ->where('actived', 1)
            ->where('id', $id)
            ->query()
            ->fetchRow();
        
        if (!$user) {
            return false;
            if ($this->getPassword($request->username, $user['salt']) == $user['password']) {
            } else {
                $this->error = 'invalid password';
            }
        } else {
            $this->error = 'username not exist';
        }
        return 0;
    }
}