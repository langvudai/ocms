<?php 

/**
 * 
 */
class Module_Admin_Model_Auth extends Db_Sql
{
    private $user;
    function __construct($auth_id)
    {
        // id, username, password, salt, actived, last_access, created_time, updated_time, deleted_time, timestamp
        $query = $this->select()
            ->from(array('u'=>'users'), 'id, username, last_access')
            ->where('id', $auth_id);
        $this->user = $query->fetchRow();
    }

    public function __get($name)
    {
        return isset($this->user[$name]) ? $this->user[$name] : null;
    }
}