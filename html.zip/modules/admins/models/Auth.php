<?php 

/**
 * 
 */
class Module_Admin_Model_Auth extends Module_Mvc_Model
{
    function __construct($auth_id)
    {
        $db = new Db_Sql();
        $user = $db->select()
            ->from(array('u'=>'users'), 'id, username, last_access, updated_time')
            ->where('id', $auth_id)
            ->query()
            ->fetchRow();
            // print_r($user);
        $this->set('id', $user['id']);
        $this->set('username', $user['username']);
        $this->set('last_access', $user['last_access']);
        $this->set('updated_time', $user['updated_time']);
    }
}