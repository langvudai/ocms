<?php 

/**
 * 
 */
class Module_Admin_Model_Auth extends Db_Sql
{
    function __construct($id = null)
    {
        if ($id) {
            $query = $this->select()
            ->from('users', 'id, password, salt')
            ->innerJoin('user_role', 'u.id=user_id')
            ->where(Db_Where::isNull('u.deleted_time'))
            ->where('actived', 1)
            ->where('username', $username);
        }
    }
    
    function transactionConfirmUserPass(Module_Admin_Request_Login $request)
    {
        // echo "striaaaang";exit();
        // return 0;
        
        $username = preg_replace('/[^a-z0-9]+/i','',$request->username);
        $query = $this->select()
            ->from(array('u'=>'users'), 'id, password, salt')
            ->innerJoin('user_role', 'u.id=user_id')
            ->where(Db_Where::isNull('u.deleted_time'))
            ->where('actived', 1)
            ->where('username', $username);
        $user = $query->fetchRow();
        /*echo $query;
        print_r($user);
        exit();*/
        if ($user) {
            if ($this->getPassword($request->username, $user['salt']) == $user['password']) {
                $this->_name = 'user';
                $this->update(array(
                    'last_access' => 'login',
                    'updated_time'=>time(), 
                    // 'dtoken'=>$this->createDToken(), 
                ), 'id='.$user['id']);
                return $user['id'];
            } else {
                $this->error = 'invalid password';
            }
        } else {
            $this->error = 'username not exist';
        }
        return 0;
    }

    function getPassword($password, $salt)
    {
        return sha1(sha1($password).$salt);
    }

    function generatorSalt()
    {
        $a = range('!', '~');
        shuffle($a);
        return implode('', array_slice($a, rand(0, 75), 15));
    }
}