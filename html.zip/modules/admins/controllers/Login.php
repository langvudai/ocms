<?php 

class Module_Admin_Controller_Login extends Module_Mvc_Controller
{
    public function index()
    {
        $user = new Module_Admin_Model_User();
        $user->createpw();
        return view('user/login', array('user' => $user));
    }

    public function checkLogin(Module_Admin_Process_Login $process, Module_Admin_Request_Login $request)
    {
        // echo "string";
        // var_dump('$id = $model->confirmUserPass($request)');exit;
        if ($id = $process->confirmUserPass($request)) {
            session()->user_id = $id;
            // var_dump(session()->user_id);
            // var_dump('78878798798');
            // exit();
            redirect('/');
        } else {
            redirect('/login');
        }
    }

    public function logout()
    {
        if (session()->uniqid() === $this->app->uniqid) {
            session()->destroy();
            redirect('/login');
        }
    }
}