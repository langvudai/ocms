<?php 

class Module_Admin_Controller_Login extends Base
{
    public function index()
    {
        return view('user/login');
    }

    public function POST_index(Module_Admin_Process_Login $process, Module_Admin_Request_Login $request)
    {
        // var_dump($id = $model->confirmUserPass($request));exit;
        if ($id = $process->confirmUserPass($request)) {
            session()->user_id = $id;
            // var_dump(session()->user_id);exit();
            redirect('/');
        } else {
            redirect('/login');
        }
    }

    public function logout()
    {
        if (session()->uniqid() === $this->app->uniqid) {
            session()->destroy();
            redirect('/login');
        }
    }
}