<?php 

class Module_Admin_Controller_Index extends Module_Admin_Controller
{
    public function index()
    {
        // echo "string";exit();
        // print_r($this->app->ic);
        // return 'admin/default';
        // return new View('admin/default',array('username' => $this->user['username']));
        // echo 1121212;
        return view('layout/default');
    }
}