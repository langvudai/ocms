<?php 
/**
 * 
 */
class Module_Admin_Controller_Password extends Module_Admin_Controller
{
    function change(Request $request)
    {
        $this->save($request);
        // echo "test";
        // print_r($_REQUEST);
        // print_r(Request::getSubmit());

        // $name = Session::instance()->uniqid('-');
        // echo "  $name  ";

        // if (Session::instance()->exist('POST')) {
        //     $posts = Session::instance()->get('POST');
        //     echo " post ";
        //     print_r($posts);
        //     // self::$submit = isset($posts[$name]) ? strtoupper($posts[$name]) : null;
        // } else {
        //     echo " _REQUEST ";
        //     print_r($_REQUEST);
        //     // self::$submit = isset($_REQUEST[$name]) ? strtoupper($_REQUEST[$name]) : null;
        // }

        // if (Request::getSubmit()) {
        //     exit(Request::getSubmit());
        // }
        // exit('asdasdasd');
    }

    function UPDATE1_change()
    {
        exit('867878978');
    }

    function index()
    {
    
        // if (session()->exist('message')) {
        //     $message = session()->message;
        //     session()->delete('message');
        //     var_dump($message);exit();
        //     return view('user/password', $message);
        // }
        return view('user/password', array('message' => $this->message()));
    }

    function save(Request $request)
    {
        // exit('545454564654');
        // var_dump($this->auth->verifyCurrentPassword($request->currentPassword));exit;
        $this->message('current password invalid', 'error');
        // if (!$this->auth->verifyCurrentPassword($request->currentPassword)) {
        //     session()->message = array('type' => 'error', 'message' => 'current password invalid');
        // } elseif (!$request->newPassword) {
        //     session()->message = array('type' => 'error', 'message' => 'new password is required');
        // } elseif ($request->newPassword != $request->confirmPassword) {
        //     session()->message = array('type' => 'error', 'message' => 'confirm password is invalid');
        // } elseif ($this->auth->updatePassword($request->newPassword)) {
        //     session()->message = array('type' => 'success', 'message' => 'change password success');
        // }

        redirect('/password');
    }
}