<?php 
/**
 * 
 */
class Module_Admin_Controller_Password extends Module_Mvc_AdminController
{
    function change(Request $request, Module_Admin_Process_Login $process)
    {
        if (!$process->verifyCurrentPassword($this->auth->id, $request->currentPassword)) {
            $this->message('current password invalid', 'error');
            // echo ('current password invalid');
            // session()->message = array('type' => 'error', 'message' => 'current password invalid');
        } elseif (!$request->newPassword) {
            $this->message('new password is required', 'error');
            // exit('new password is required');
            // session()->message = array('type' => 'error', 'message' => 'new password is required');
        } elseif ($request->newPassword != $request->confirmPassword) {
            $this->message('confirm password is invalid', 'error');
            // exit('confirm password is invalid');
            // session()->message = array('type' => 'error', 'message' => 'confirm password is invalid');
        } elseif ($process->updatePassword($this->auth->id, $request->newPassword)) {
            $this->message('change password success');
            echo 'change password success';
            // session()->message = array('type' => 'success', 'message' => 'change password success');
        }

        // redirect('/password');
    }

    function index()
    {
        return view('user/password');
    }
}