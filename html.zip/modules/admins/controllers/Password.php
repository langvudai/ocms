<?php 
/**
 * 
 */
class Module_Admin_Controller_Password extends Module_Admin_Controller
{
    
    function index()
    {
        // die('111');
        return view('user/password');
    }

    function save()
    {
        die('111');
        // return view('user/password');
    }
}