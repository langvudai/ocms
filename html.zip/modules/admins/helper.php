<?php 

if (!function_exists('redirect')) {
    function redirect($url)
    {
        $anti_request_forgery = session()->uniqueValue(true);
        header('location: '.config('app.base_url').$anti_request_forgery.'/admin/'.trim($url, '/'));
    }
}

if (!function_exists('url')) {
    function url($url)
    {
        $anti_request_forgery = session()->uniqueValue(true);
        return config('app.base_url').$anti_request_forgery.'/admin/'.trim($url, '/');
    }
}

if (!function_exists('view')) {
    /**
     * [view description]
     * @param  string     $template [description]
     * @param  array|null $data     [description]
     * @return Module_Mvc_View
     */
    function view($template, array $data = null)
    {
        return new Module_Mvc_View($template, $data);
    }
}

if (!function_exists('app_log')) {
    function app_log()
    {
        return Log::open('app');
    }
}

if (!function_exists('submitName')) {
    function submitName()
    {
        return implode('-', Session::instance()->uniqueValue());
    }
}