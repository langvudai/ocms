<?php 

if (!function_exists('redirect')) {
    function redirect($url)
    {
        header('location: '.config('app.base_url').session()->uniqid().'/admin/'.trim($url, '/'));
    }
}

if (!function_exists('url')) {
    function url($url)
    {
        return config('app.base_url').session()->uniqid().'/admin/'.trim($url, '/');
    }
}
