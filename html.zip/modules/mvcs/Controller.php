<?php 

/**
 * 
 */
class Module_Mvc_Controller extends Base
{
    /**
     * run
     * @return void
     */
    public final function run()
    {
        $app = new App();
        $time = $app->microtime === null ? 1 : $app->microtime;
        Log::open('app')->info('start app', $time);
        $method = $app->method;
        $result = $this->invokeMethod($method);
        
        if ($result === false) {
            return false;
        }

        if (is_object($result)) {
            try {
                $render = $this->getReflectionMethod($result, 'render');
                if ($render->isPublic()) {
                    $render->invoke($result);
                }
            } catch (Exception $e) {
                Log::open('app')->error($e->getMessage());
            }
        }

        $end_time = function_exists('microtime') ? microtime(true) : 0;
        Log::open('app')->info('end app', $end_time - $time);
    }
}