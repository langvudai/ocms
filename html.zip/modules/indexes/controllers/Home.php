<?php 

class Module_Index_Controller_Home extends Module_Mvc_Controller
{
    public function index()
    {
        return new Module_Mvc_View('home');
    }
}