<?php 

class Session
{
    private static $ss;
    private $ssid, $path, $value=array(), $timeout;

    public static function instance($path='', $timeout = 3600, $id='')
    {
        if (!self::$ss) {
            self::$ss = new Session($path, $timeout, $id);
        }
        return self::$ss;
    }

    public function __construct($path='', $timeout = 3600, $id='')
    {
        ini_set('session.cookie_lifetime', 86400);
        ini_set('session.gc_maxlifetime', 86400);
        session_name('_ss_'.dechex(filemtime(__FILE__)));
        @session_start();
        $this->ssid = $id ? $id : session_id();
        if (empty($path)) {
            $path_config = Configuration::get('app.paths.sessiond');
            if (is_string($path_config)) {
                $path = $path_config;
            }
        }
        ($path && !file_exists($path)) && @mkdir($path);
        if ($path && @is_dir($path)) {
            $this->path = $path;
        } else {
            @is_dir(dirname(__FILE__).'/sesiond'.filemtime(__FILE__)) || mkdir(dirname(__FILE__).'/sesiond'.filemtime(__FILE__));
            $this->path = dirname(__FILE__).'/sesiond'.filemtime(__FILE__);
        }
        $this->timeout = $timeout;
        $this->read_session();
        count($this->value) && $this->write_session();
    }

    public function __destruct()
    {
        $this->write_session();
    }

    public function exist($id)
    {
        return $this->is_life_session() && isset($this->value[$id]);
    }

    public function isEmpty($id)
    {
        return !$this->is_life_session() || !isset($this->value[$id]) || empty($this->value[$id]);
    }

    public function delete($id){
        if ($this->is_life_session()) {
            unset($this->value[$id]);
            $this->write_session();
        }
    }
    
    public function destroy()
    {
        $file = $this->path ? ($this->path . '/' .$this->ssid) : $this->ssid;
        if (file_exists($file) && is_writable($file)) {
            unlink($file);
        }
        $this->value = array();
        $this->write_session();
        session_destroy();
    }

    public function __set($name, $value)
    {
        $this->set($name, $value);
    }

    public function set($id, $value)
    {
        $this->value[$id] = $value;
        $this->write_session();
    }

    public function __get($name){
        return $this->get($name);
    }

    public function get($id)
    {
        if ($this->is_life_session()) {
            return isset($this->value[$id]) ? $this->value[$id] : NULL;
        }
        return NULL;
    }

    public function uniqueValue($join = false)
    {
        $id = $this->ssid;

        if (!$this->exist($id)) {
            $this->set($id, array(chr(rand(119, 122)), base_convert(rand(111111, 999999), 10, 32), base_convert(uniqid(), 16, 32), base_convert(time(), 10, 32)));
        }
        
        $a = $this->get($id);

        if (!is_array($a)) {
            return null;
        }

        return $join ? ('0'.implode('', $a)) : $a;
    }

    private function fwrite_stream($fp, $string) 
    {
        for ($written = 0; $written < strlen($string); $written += $fwrite) {
            $fwrite = fwrite($fp, substr($string, $written));
            if ($fwrite === false) {
                return $written;
            }
        }
        return $written;
    }

    private function write_session()
    {
        $file = $this->path ? ($this->path . '/' .$this->ssid) : $this->ssid;
        $s = serialize($this->value);
        $i = rand(strpos($s, '{') , strrpos($s, ';'));
        $i = strpos($s, ';', $i);
        $s = substr($s, 0, $i).';s:5:""'.substr($s, $i);
        if (@is_writable($file)) {
            $fp = fopen ( $file , 'wb' );
            $this->fwrite_stream ( $fp, $s);
            fclose($fp);
        } else {
            $fp = fopen ( $file , 'wb' );
            $this->fwrite_stream ( $fp, $s);
            fclose($fp);
            chmod($file, 0600);
        }
    }

    private function read_session()
    {
        $file = $this->path ? ($this->path . '/' .$this->ssid) : $this->ssid;
        if (@is_readable($file) && filesize($file)) {
            $filetime = filemtime($file) ? filemtime($file) : filectime($file);
            if ($filetime + $this->timeout > time()) {
                $fp = fopen ( $file , 'rb' );
                $contents = fread($fp, filesize($file));
                fclose($fp);
                @$res = unserialize(str_ireplace(';s:5:""', '', trim($contents)));
                if ($res !== false) {
                    $this->value = $res;
                } else {
                    $this->value = array();
                }
            } else {
                $this->value = array();
            }
        } else {
            $this->value = array();
        }
    }

    private function is_life_session()
    {
        $file = $this->path ? ($this->path . '/' .$this->ssid) : $this->ssid;
        if (@is_readable($file)) {
            $filetime = filemtime($file) ? filemtime($file) : filectime($file);
            if ($filetime + $this->timeout > time()) {
                $fp = fopen($file, 'a');
                fwrite($fp, ' ');
                fclose($fp);
                return true;
            }
        }
        return false;
    }
    
    
}
