<?php 

class Header 
{
    public static function text()
    {
        header('Content-Type: text/plain');
    }

    public static function json()
    {
        header('Content-type: application/json');
    }

    public static function xml()
    {
        header("Content-Type: application/xml; charset=utf-8");
    }

    public static function download($attachFileName, $fileSize=0)
    {
        header("Content-Disposition: attachment; filename=" . $attachFileName);
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Description: File Transfer");
        ($fileSize>0) && header("Content-Length: " . $fileSize);
    }

    /**
     * 
     * set header 403
     * @param $html_or_path 
     */
    public static function err403($html_or_path='')
    {
        header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden', true, 403);
        is_readable($html_or_path) && is_file($html_or_path) ? exit(include $html_or_path) : exit($html_or_path);
    }

    /**
     * 
     * set header 404
     * @param $html_or_path 
     */
    public static function err404($html_or_path='')
    {
        header($_SERVER['SERVER_PROTOCOL'] . ' 404 Page not found', true, 404);
        is_readable($html_or_path) && is_file($html_or_path) ? exit(include $html_or_path) : exit($html_or_path);
    }

    /**
     * 
     * set header 500
     * @param $html_or_path 
     */
    public static function err500($html_or_path='')
    {
        header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);
        is_readable($html_or_path) && is_file($html_or_path) ? exit(include $html_or_path) : exit($html_or_path);
    }

    public static function redirect($url)
    {
        header('location:'.$url);
    }
}