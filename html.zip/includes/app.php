<?php 
version_compare(PHP_VERSION, '5.3.3', '>=') || exit('requires PHP version >= 5.3.3');
final class App {
    private static $x = array('i'=>array()), $m = null, $p = array('/([_]+)/', '/[^_]*$/'), $r = array('_', '');
    public function __construct ($o = null) {
        isset(App::$x['start']) ? ((isset(App::$x['o']) && is_object(App::$x['o'])) || App::setX($o, 'o')) : App::setX($o, 'start');
    }
    public function __call ($n, $v) {
        try {
            $ref = new ReflectionClass(App::$x['o']);
            $ref->hasMethod($n) && $ref->getMethod($n)->invokeArgs(App::$x['o'], $v);
        } catch (Exception $e) {
            exit($e->getMessage()); 
        }
    }
    public function __isset ($n) {
        return isset(App::$x[$n]) || isset(App::$x['i'][$n]);
    }
    public function __get ($n) {
        return isset(App::$x[$n]) ? App::$x[$n] : (isset(App::$x['i'][$n]) ? (is_scalar(App::$x['i'][$n]) ? App::$x['i'][$n] : (object)App::$x['i'][$n]) : null);
    }
    public static function autoload ($class) {
        $fn = preg_replace('/^.*_([A-Z][a-zA-Z0-9]*)$/', '\\1', $class).'.php';
        $cls = preg_replace(App::$p, App::$r, $class);
        $p = implode(DIRECTORY_SEPARATOR, array_map(array('App', 'plural'), explode('_', $cls)));
        $a = file_exists($f = __DIR__.DIRECTORY_SEPARATOR.$p.$fn) ? $f : (file_exists($f = __DIR__.DIRECTORY_SEPARATOR. $p.strtolower($fn)) ? $f : null);
        $b = $a === null ? (file_exists($f = __DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR. $p.$fn) ? $f : (file_exists($f = __DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR. $p.strtolower($fn)) ? $f : null)) : null;
        $f = $a !== null ? realpath($a) : ($b !== null ? realpath($b) : null);
        $f !== null && is_file($f) && is_readable($f) && (include_once $f);
    }
    public static function mapAutoload ($array) {
        App::$p = array_merge(App::$p, array_map(function($p) {
            return '/^'. $p .'/';
        }, array_keys($array)));
        App::$r = array_merge(App::$r, array_map(function($r) {
            return trim($r, '/') . DIRECTORY_SEPARATOR;
        } ,array_values($array)));
    }
    private static function plural ($v) {
        $a = file_exists($f = __DIR__ .DIRECTORY_SEPARATOR. 'nouns') && is_file($f) && is_readable($f) ? array_filter(array_map(function($v) {return trim($v); }, file($f))) : array('audio', 'audio', 'bison', 'bison', 'cattle', 'cattle', 'chassis', 'chassis', 'chef', 'chefs', 'chief', 'chiefs', 'child', 'children', 'compensation', 'compensation', 'coreopsis', 'coreopsis', 'data', 'data', 'deer', 'deer', 'education', 'education', 'emoji', 'emoji', 'equipment', 'equipment', 'evidence', 'evidence', 'feedback', 'feedback', 'firmware', 'firmware', 'fish', 'fish', 'foot', 'feet', 'furniture', 'furniture', 'gold', 'gold', 'goose', 'geese', 'hardware', 'hardware', 'hero', 'heroes', 'information', 'information', 'jedi', 'jedi', 'kin', 'kin', 'knowledge', 'knowledge', 'louse', 'lice', 'love', 'love', 'man', 'men', 'means', 'means', 'metadata', 'metadata', 'money', 'money', 'moose', 'moose', 'mouse', 'mice', 'news', 'news', 'nutrition', 'nutrition', 'offspring', 'offspring', 'ox', 'oxen', 'person', 'people', 'plankton', 'plankton', 'pokemon', 'pokemon', 'police', 'police', 'potato', 'potatoes', 'rain', 'rain', 'recommended', 'recommended', 'related', 'related', 'rice', 'rice', 'roof', 'roofs', 'series', 'series', 'sheep', 'sheep', 'software', 'software', 'species', 'species', 'stomach', 'stomachs', 'swine', 'swine', 'tomato', 'tomatoes', 'tooth', 'teeth', 'traffic', 'traffic', 'wheat', 'wheat', 'woman', 'women');
        return false !== ($i = array_search($v, $a)) ? $a[$i+1] : preg_replace(array('/^(.*([sxz]|ch|sh))$/', '/^(.*[^aeiou])y$/', '/^(.*)(f|fe)$/', '/^.((?!ing$|s$|\/$).)*$/'), array('\\1es', '\\1ies', '\\1ves', '\\0s'), strtolower($v));
    }
    public static function boot ($URI = null) {
        $df = defined('index') ? index : 'index';
        $uri = empty($URI) ? preg_replace('/^(\/?index\.php\/?|\/)?([^\?]+)[\/\?]*.*$/i', '\\2', $_SERVER['REQUEST_URI']) : trim($URI);
        $URI = preg_match('/^(0[wxyz][\da-v]+)\/?([^\?]+)/i', $uri, $t) && App::setX($t[1], 'uniqid') ? $t[2] : $uri;
        $p = count($a = explode('/', $URI, 2)) && file_exists($f = __DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.App::plural(strtolower(defined('module') ? module : 'module')).DIRECTORY_SEPARATOR.App::plural($a[0]).DIRECTORY_SEPARATOR.$a[0].'.php') && App::setX($a[0], 'module') ? App::load($f, trim(@$a[1], '/'), array_values(array_filter(explode('/', @$a[1])))) : App::load(__DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.App::plural(strtolower(defined('module') ? module : 'module')).DIRECTORY_SEPARATOR.App::plural($df).DIRECTORY_SEPARATOR."$df.php", $URI, array_values(array_filter(explode('/', $URI))));
        return is_array($p) && App::setX($p) ? (new App(call_user_func_array(function ($file, $call, $args, $class) {
            try {
                include_once !empty($file) && file_exists($file) && is_file($file) && is_readable($file) ? $file : __FILE__;
                return is_object($result = is_callable($call) ? call_user_func_array($call, array($args)) : null) ? $result : (is_scalar($class) ? (new ReflectionClass($class))->newInstance() : null);
            } catch (Exception $e) {
                exit($e->getMessage());
            }
        }, $p))) : exit;
    }
    private static function load ($p, $f, $a) {
        is_array($s = file_exists($p) && is_readable($p) && is_file($p) ? include($p) : null) || exit(';');
        $g = is_array($s) && count($s) > 0 ? array_pop($s) : null;
        $s['routes'] = is_array($s) && count($s) > 0 ? array_shift($s) : (is_array($g) ? $g : null);
        $s = (object)$s;
        !is_callable($g) || ((@call_user_func_array($g, App::args($g, array_merge(array($s), $a))) === false) && exit('.'));
        $r = !is_array($s->routes) ? exit('...') : (empty($a) ? (isset($s->routes['/']) ? $s->routes['/'] : array()) : (isset($a[1])&&isset($s->routes[$a[0].'/'.$a[1]]) ? $s->routes[$a[0].'/'.$a[1]] : (isset($a[0])&&isset($s->routes[$a[0]]) ? $s->routes[$a[0]] : App::regexModule($s->routes, $f, isset($s->routes['!']) ? $s->routes['!'] : null))));
        $a = is_array($r) && isset($r['args']) ? (is_callable($r['args']) ? call_user_func_array($r['args'], is_array(App::$m) ? App::$m : $a) : $r['args']) : array();
        $i = !is_array($r) || !isset($r['class']) || empty($r['class']) ? false : preg_match('/^([^\:]+)(\:\:([a-z][a-zA-Z0-9]+))?$/', $r['class'], $j);
        return is_array($r) && !empty($r) ? array(isset($r['file']) ? $r['file'] : '', isset($r['call']) ? $r['call'] : null, $a, $i ? @$j[1] : '', $i && !empty($j[3]) ? $j[3] : '') : (is_callable($r) ? call_user_func_array($r, is_array(App::$m) ? App::$m : array()): exit('!'));
    }
    private static function args ($f, $p) {
        return array_replace(array_map(function($param) {
            return $param->isOptional() ? $param->getDefaultValue() : null;
        }, (new ReflectionFunction($f))->getParameters()), $p);
    }
    private static function setX ($v, $k='i') {
        return (bool)(App::$x[$k] = $k !== 'i' ? $v : (is_array($v[2]) ? array_merge(array('method' => $v[4], 'x' => App::$m), $v[2]) : array('method' => $v[4], 'x' => App::$m)));
    }
    private static function regexModule ($array, $string, $default) {
        $array_keys = is_array($array) ? preg_grep('~^/.+/[a-z]*$~', array_keys($array)) : $array();
        while (($key = array_shift($array_keys)) && !preg_match(preg_replace('~^/\^?(.+)\$?/([a-z]*)$~', '~^\\1$~\\2', $key), $string, $matches)) ;
        App::$m = !empty($matches) ? $matches : null;
        $r = $key !== null && isset($array[$key]) ? (is_callable($array[$key]) ? call_user_func_array($array[$key], $matches) : $array[$key]) : null;
        return is_array($r) ? $r : $default;
    }
}
new App(function_exists('microtime') ? microtime(true) : null);
spl_autoload_register(array('App', 'autoload'), true, true);