<?php

class Log
{
    public static $logs = array();
    private $fo;

    /**
     * @param $name
     * @return Log
     * @throws Exception
     */
    public static function open ($name)
    {
        if (!is_scalar($name)) {
            throw new Exception('error: invalid type $name', 1);
        }

        $log_name = $name.date('-dmY');

        if (isset(self::$logs[$log_name])) {
            return self::$logs[$log_name];
        }
    
        $filename = null;
        $path = Configuration::get('app.paths.log_dir');
        if ($path !== null) {
            if (file_exists($path) && is_file($path)) {
                throw new Exception("Error $path exist and is file", 1);
            }

            if (!file_exists($path) || !is_dir($path)) {
                $dirs = explode('/', $path);
                $dir = '';
                for ($i = 0; $i < count($dirs); $i++) {
                    $dir .= '/' . $dirs[$i];
                    is_dir($dir) || mkdir($dir, 0775);
                }
                chmod($dir, 0775);
            }

            if (file_exists($path) && is_dir($path)) {
                $filename = $path .'/'. $log_name.'.log';
            }
        }
        

        if (!$filename) {
            return new Log(null);
        }

        self::$logs[$log_name] = new Log($filename);
        return self::$logs[$log_name];
    }

    /**
     * Log constructor.
     * @param string $filename
     */
    public function __construct ($filename)
    {
        if ($filename) {
            $fopen = fopen($filename,'a');
            if ($fopen) {
                $this->fo = $fopen;            
            }
        }
    }

    /**
     * @param $name
     * @param $arguments
     */
    public function __call ($name, $arguments)
    {
        if ($this->fo && $arguments) {
            $type = strtoupper($name);
            $content = trim(array_shift($arguments));

            if ($arguments) {
                $option = array_map('json_encode', $arguments);
            } else {
                $option = '';
            }
            
            @fwrite($this->fo, '['.date(DATE_RFC822)."] $type: $content ".implode(' ', $option).PHP_EOL);
        }
    }

    /**
     *
     */
    public function __destruct ()
    {
        @fclose($this->fo);
        $this->fo = null;
    }
}

if (!function_exists('logger')) {
    /**
     * @param string $name
     * @return [type] [description]
     */
    function logger($name = 'app')
    {
        return Log::open($name);
    }
}
