<?php 
if(!function_exists('str_slug'))
{
    /**
     * @param string $str
     */
    function str_slug($str)
    {
        $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
        $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
        $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
        $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
        $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
        $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
        $str = preg_replace("/(đ)/", 'd', $str);
        $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
        $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
        $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
        $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $str);
        $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
        $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
        $str = preg_replace("/(Đ)/", 'D', $str);
        $str = preg_replace('/[^a-z0-9\-]+/i','-',$str);
        return $str;
    }
}

if(!function_exists('pagination'))
{
    /**
     * 
     * @param int $total
     * @param int $per_page
     * @param int $current
     * @param int $diameter
     * @return array [first, prev, from, to, next, last, total, current]
     */
    function pagination($total = 0, $per_page = 10, $current = 1, $diameter = 10)
    {
        if ($total < $per_page) {
            return null;
        }

        $total_page = ceil($total/$per_page);
        $from = round($current - $diameter/2);
        if ($from < 1) {
            $from = 1;
        }

        $to = $from + $diameter - 1;
        if ($to > $diameter) {
            $to = $diameter;
        }


        return array(
            'first'=> 1,
            'prev' => $current > 1 ? ($current - 1) : 1,
            'from' => $from,
            'to'   => $to,
            'next' => $current < $total_page ? ($current + 1) : $total_page,
            'last' => $total_page,
            'total'=> $total_page,
            'current' => $current
        );
    }
}

if(!function_exists('get_func_info'))
{
    /**
     * @return array
     */
    function get_func_info($function) 
    {
        $f = new ReflectionFunction($function);
        $result['name'] = $f->name;
        $result['parameters'] = array();
        foreach ($f->getParameters() as $param) {
            $result['parameters'][$param->name] = $param->isOptional() ? $param->getDefaultValue() : '';
        }
        return $result;
    }
}

if(!function_exists('truncate'))
{
    /**
     * @param string $text
     * @param int $length
     * @return string
     */
    function truncate($text, $length = 25) 
    {
        $text = substr(trim($text).' ', 0, $length);
        return substr($text, 0, strrpos($text,' ')).'...';
    }
}

if(!function_exists('convert_str'))
{
    /**
     * @param string $text
     * @return string
     */
    function convert_str($text) 
    {
        return implode(' ',array_map(function($word) {
            return strtoupper(substr($word, 0, 1)).substr($word, 1);
        }, array_filter(explode(' ', strtolower($text)))));
    }
}

if (!function_exists('camel_to_snake_case')) {
	/**
     * [camel_to_snake_case description]
     * @param  [type] $string [description]
     * @return [type]         [description]
     */
    function camel_to_snake_case($string)
    {
        return preg_replace_callback('/(([a-z0-9])([A-Z]))/', function ($matches) {
            return $matches[2].'_'.strtolower($matches[3]);
        }, $string);
    }
}

if (!function_exists('to_camel_case')) {
    /**
     * [to_camel_case description]
     * @param  [type] $string [description]
     * @return [type]         [description]
     */
    function to_camel_case($string)
    {
        return preg_replace_callback('/([^a-z0-9]+([a-z0-9]))/', function ($matches) {
            return strtoupper($matches[2]);
        }, strtolower(preg_replace('/^[^a-z0-9]+|[^a-z0-9]+$/', '', $string)));
    }
}

if (!function_exists('get_interface')) {
	/**
     * [get_interface description]
     * @param  [type] $string [description]
     * @return array
     */
	function get_interface($object)
	{
	    $reflection_class = new ReflectionClass(get_class($object));
	    return $reflection_class ? $reflection_class->getInterfaceNames() : array();
	}
}

if (!function_exists('submitName')) {
    /**
     * @return string
     */
    function submitName()
    {
        return Request::submitName();
    }
}

if (!function_exists('session')) {
    /**
     * @return object
     */
    function session()
    {
        return Session::instance();
    }
}

if (!function_exists('config')) {

    /**
     * config('app.db.gido') return value
     * 
     * @param  string $key
     * @return mixed
     */
    function config($key)
    {
        return Configuration::get($key);
    }
}
