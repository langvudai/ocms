<?php 

/**
 * <!-- [nominify] -->
 * {?php}               <?php 
 * {/php}               ?>
 * {?layout [a-zA-Z0-9_-/]}
 * {?:label}
 * {?include [a-zA-Z0-9_-/]+}
 * 
 * {?content [a-zA-Z0-9-_]}
 * {/content}
 * {?mix [a-zA-Z0-9-_]} or
 * 
 * {?if\s ...}          <?php if(...): ?>
 * {?else\s ...}        <?php elseif(...): ?>
 * {?else} else:        <?php else: ?>
 * {/if}                <?php endif; >
 * {?foreach\s ...}     <?php foreach(...): ?>
 * {/foreach}           <?php endforeach; ?>
 * {?for\s ...}         <?php for(...): ?>
 * {/for}               <?php endfor; ?>
 * {?while\s ...}       <?php while(...): ?>
 * {/while} endwhile; 
 * 
 * {$[a-z_][^\{\r\s\n\}]+} echo $[a-z_][^\{\r\s\n\}]+ 
 * {$function([^\{\r\n\}]*)} echo function(...) if function exist, function: [a-z_][a-zA-Z0-9_]*
 * 
 */
class Template
{
    private static $DATA=array(), $setting=array();
    private static $e=array();
    private $templateView, $templateLayout;
    protected $_id, $_;

    /**
     * @param string $name
     * @param mixed $value
     * @return mixed
     */
    public static function __callStatic($name, $value)
    {
        if (preg_match('/^(set|get)([A-Z])([a-zA-Z0-9]*)$/', $name, $matches)) {
            $key = strtolower($matches[2]).$matches[3];
            if ($matches[1] === 'set') {
                if ($key === 'label' || $key === 'labelTime') {
                    $path = array_shift($value);
                    if (!$path) {
                        $path = Configuration::get('view.lang');
                    }

                    if (file_exists($path) && is_readable($path) && is_file($path)) {
                        $lang = include_once $path;
                        if (is_array($lang)) {
                            self::$setting['label'] = $lang;
                            self::$setting['labelTime'] = filemtime($path);
                        }
                    }
                } else {
                    self::$setting[$key] = array_shift($value);
                }
            } else {
                if (self::$setting[$key]) {
                    return self::$setting[$key];
                }

                if ($key === 'label' || $key === 'labelTime') {
                    $path = Configuration::get('view.lang');
                    if (file_exists($path) && is_readable($path) && is_file($path)) {
                        $lang = include_once $path;
                        if (is_array($lang)) {
                            self::$setting['label'] = $lang;
                            self::$setting['labelTime'] = filemtime($path);
                        }
                    }

                    return isset(self::$setting[$key]) ? self::$setting[$key] : null;
                }

                $snake = preg_replace_callback('/(([a-z0-9])([A-Z]))/', function ($matches) {
                    return $matches[2].'_'.strtolower($matches[3]);
                }, $key);
                
                return Configuration::get('view.'.$snake);
            }
        }
    }

    /**
     * @param string $template
     * @param array|null $data
     */
    public function __construct($template, array $data = null)
    {
        $this->_id = uniqid();
        self::$DATA[$this->_id] = $data ? $data : array();
        self::$e[$this->_id] = array();
        $this->_ = array();
        // $this->___ = ''; 
        $file = self::getViewDir() .DIRECTORY_SEPARATOR. $template;
        $file = file_exists("$file.php") ? "$file.php" : (file_exists("$file.html") ? "$file.html" : null);
        $this->templateView = $file && is_readable($file) && is_file($file) ? $file : null;
    }

    public function render()
    {
        if ($this->templateView) {
            self::getLabel();
            if (!self::getCompilerDir() || !is_dir(self::getCompilerDir())) {
                extract(self::$DATA[$this->_id]);
                include_once $this->templateView;
            } else {
                $file_compiler=$this->templateEngine($this->templateView);
                if (!empty($file_compiler) && is_readable($file_compiler) && is_file($file_compiler)) {
                    extract(self::$DATA[$this->_id]);
                    include_once $file_compiler;
                }
            }
        }
    }

    /**
     * @param  string $path 
     */
    private function loadLayout($path)
    {
        if (file_exists($path)) {
            $filename = $path;
        } else {
            $filename = self::getViewDir() .DIRECTORY_SEPARATOR. $path.'.html';
        }

        if (file_exists($filename) && is_file($filename) && is_readable($filename)) {
            $filename = $this->templateEngine($filename, '0');
            extract(self::$DATA[$this->_id]);
            if (!empty($filename) && file_exists($filename)) {
                include_once $filename;
            }
        }
    }

    private function loadContent($path)
    {
        $k = $m[1];
        $f = isset($m[2]) && $m[2] ? substr($m[2], 1) : null;
        if (isset($this->_[$k])) {
            if ($f) {
                return "<?php function_exists('$f') ? $f(include '".$this->_[$k]."') : (include '".$this->_[$k]."')";
            }
            return "<?php include '".$this->_[$k]."' ?>";
        }
        return '';
    }

    /**
     * @param  string $path 
     */
    private function includeEngine($path)
    {
        if (file_exists($path)) {
            $filename = $path;
        } else {
            $filename = self::getViewDir() .DIRECTORY_SEPARATOR. $path.'.html';
        }
        if (file_exists($filename) && is_file($filename) && is_readable($filename)) {
            $filename = $this->templateEngine($filename, '2');
            extract(self::$DATA[$this->_id]);
            if (!empty($filename) && file_exists($filename)) {
                include $filename;
            }
        }
    }

    /**
     * @param string $filename
     * @param string $prefix
     * @return string
     */
    private function templateEngine($filename, $prefix='1')
    {
        $compiler_dir = realpath(self::getCompilerDir());
        @chmod($compiler_dir, 0775);
        $mtime = file_exists($filename)&&is_file($filename) ? dechex(filemtime($filename)) : '';
        $base_compiler = $compiler_dir.DIRECTORY_SEPARATOR.$prefix.md5(self::getLabelTime().str_replace('/', '', $filename));
        $file_compiler = $base_compiler.$mtime.'_tpl.php';
        if (!file_exists($file_compiler)) {
            $pattern = $base_compiler.'*_tpl.php';
            $old_files = glob($pattern);
            foreach ($old_files as $file) {
                @unlink($file);
            }

            if ($prefix==0) {
                $this->createEngineerLayout($filename, $file_compiler);
            } else {
                $this->createEngineer($filename, $file_compiler);
            }
        }
        
        return empty($file_compiler) ? $filename : $file_compiler;
    }

    /**
     * @param  string $filename       
     * @param  string &$file_compiler 
     */
    private function createEngineer($filename, &$file_compiler)
    {
        $fw = fopen($file_compiler, 'w');
        $content = $fw ? file_get_contents($filename) : '';
        empty($content) && exit('!compile'.self::getCompilerDir());
        $nominify = false;
        $content = preg_replace(array('/\\\\{/s', '/\\\\}/s'), array('&#123;', '&#125;'), $content);
        if (preg_match('/\<\!\-\-\s*\[nominify\]\s*\-\-\>/s', $content)) {
            $nominify = true;
            $content = preg_replace('/\<\!\-\-\s*\[nominify\]\s*\-\-\>/s', '', $content);
        }
        
        if (preg_match('/^\{\?layout\s+([a-zA-Z0-9_\-\/]+)\}/', $content, $matches)) {
            $path = $matches[1];
            $content = str_ireplace($matches[0], '', $content);
        }
        $content = $this->engineContent($content);
        if ($path) {
            $content .= '<?php $this->loadLayout( \''.addcslashes($path, "'").'\' ); ?>';
        }
        $content = $this->enginePartition($content, $nominify);
        $content = preg_replace('/\{\/content\}/s', '', $content); 
        
        if (preg_match_all('/\{\?mix\s+([a-z0-9_\-]+)\}/is', $content, $m)) {
            $compiler_dir = realpath(self::getCompilerDir());
            foreach($m[1] as $k => $v) {
                $p = $compiler_dir.DIRECTORY_SEPARATOR.md5($v).'_tpl.php';
                $content = str_replace($m[0][$k], "<?php include file_exists('$p') ? '$p' : __FILE ?>", $content);
            }
        }

        $content = preg_replace(array('/&#123;/s', '/&#125;/s'), array('{', '}'), $content);
        $result_write = fwrite($fw, trim($nominify ? $content : preg_replace('/([\s\t]+)/', ' ', str_replace(PHP_EOL, '', $content)) ));
        fclose($fw);
        chmod($file_compiler, 0644);
        $result_write || ($file_compiler='');
    }

    /**
     * @param  string $filename 
     * @param  string &$file_compiler 
     */
    private function createEngineerLayout($filename, &$file_compiler)
    {
        $fw = fopen($file_compiler, 'w');
        $content = $fw ? file_get_contents($filename) : '';
        empty($content) && exit('!compile'.self::getCompilerDir());
        $content = preg_replace(array('/\\\\{/s', '/\\\\}/s'), array('&#123;', '&#125;'), $content);
        $nominify = false;
        if (preg_match('/\<\!\-\-\s*(\[nominify\]|{@nominify})\s*\-\-\>/s', $content)) {
            $nominify = true;
            $content = preg_replace('/\<\!\-\-\s*(\[nominify\]|{@nominify})\s*\-\-\>/s', '', $content);
        }

        $content = preg_replace('/\{\?layout\s+[a-zA-Z0-9_\-\/]+\}/s', '', $content);
        $content = $this->engineContent($content);
        $content = $this->enginePartition($content, $nominify);
        $content = preg_replace('/\{\/content\}/s', '', $content); 
        
        if (preg_match_all('/\{\?mix\s+([a-z0-9_\-]+)\}/is', $content, $m)) {
            $compiler_dir = realpath(self::getCompilerDir());
            foreach($m[1] as $k => $v) {
                $p = $compiler_dir.DIRECTORY_SEPARATOR.md5($v).'_tpl.php';
                $content = str_replace($m[0][$k], "<?php include file_exists('$p') ? '$p' : __FILE ?>", $content);
            }
        }

        $content = preg_replace(array('/&#123;/s', '/&#125;/s'), array('{', '}'), $content);
        $result_write = fwrite( $fw, trim($nominify ? $content : preg_replace('/([\s\t]+)/', ' ', str_replace(PHP_EOL, '', $content)) ));
        fclose($fw);
        chmod($file_compiler, 0644);
        $result_write || ($file_compiler='');
    }

    /**
     * @param  string $content
     * @return string
     */
    private function enginePartition ( $content, $nominify ) 
    {
        $i = stripos($content, '{?content ');
        $j = stripos($content, '{/content}', $i);
        while ($i>-1 && $j>$i) {
            $partition = substr($content, $i, $j-$i);
            preg_match('/\{\?content\s+([a-zA-Z0-9_\-]+)\}/s', $partition, $matches);
            $partition = preg_replace('/\{\?content\s+([a-zA-Z0-9_\-]+)\}/s', '', $partition); 
            $path = realpath(self::getCompilerDir()).DIRECTORY_SEPARATOR.md5($matches[1]).'_tpl.php';
            $fw = fopen($path, 'w');
            $result_write = fwrite( $fw, trim($nominify ? $partition : preg_replace('/([\s\t]+)/', ' ', str_replace(PHP_EOL, '', $partition)) ));
            fclose($fw);
            if ($result_write) {
                chmod($path, 0644);
                $this->_[$matches[1]] = $path;
            }
            $content = substr($content, 0, $i).substr($content, $j);
            $i = stripos($content, '{?content ', $j);
            $j = stripos($content, '{/content}', $i);
        }
        return $content;
    }

    /**
     * @param  string $content
     * @return string
     */
    private function engineLabel( $matches )
    {
        $label = self::getLabel();
        $key = trim($matches[1]);
        return (isset($label[$key]) && !empty($label[$key])) ? $label[$key] : $matches[1];
    }

    /**
     * @param  string $content
     * @return string
     */
    private function engineContent( $content )
    {
        $content = preg_replace_callback('/\{\?:([\wàáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ][^\{\}]+)\s*\}/s', array($this, 'engineLabel'), $content);
        $content = preg_replace(array(
            '/\<\?php([\s\n\r])/is', 
            '/\{\?php\}/is', 
            '/\{\/php\}/is', 
        ), array(
            '&lt;?php\\1', 
            '<?php ', 
            ' ?>', 
        ), $content);
        
        $content = preg_replace(array(
            '/(\{\?if\s([^\{\r\n\}]+)\})/is', 
            '/(\{\?else\s([^\{\r\n\}]+)\})/is', 
            '/(\{\?else\})/is', 
            '/(\{\/if\})/is', 
            '/(\{\?foreach\s([^\{\r\n\}]+)\})/is', 
            '/(\{\/foreach\})/is', 
            '/(\{\?for\s([^\{\r\n\}]+)\})/is', 
            '/(\{\/for\})/is', 
            '/(\{\?while\s([^\{\r\n\}]+)\})/is', 
            '/(\{\/while\})/is', 
        ), array(
            '<?php if( \\2 ): ?>', 
            '<?php elseif( \\2 ): ?>', 
            '<?php else: ?>', 
            '<?php endif; ?>', 
            '<?php foreach( \\2 ): ?>', 
            '<?php endforeach; ?>', 
            '<?php for( \\2 ): ?>', 
            '<?php endfor; ?>', 
            '<?php while( \\2 ): ?>', 
            '<?php endwhile; ?>', 
        ), $content);

        $content = preg_replace('/\{\?include\s+([a-zA-Z0-9\-\.\/_]+)\s*(,[^\r\n]+)?\}/s', '<?php $this->includeEngine(\'\\1\'\\2); ?>', $content);
        /*engine_echo*/
        $content = preg_replace_callback('/\{\$([a-z_][a-zA-Z0-9_]*)?\(([^\r\n\{\}]*)\)\}/is', function($m){
            if (!isset($m[1]) || !$m[1]) {
                return '<?php echo ( '.$m[2].' ); ?>';
            }
            if (function_exists($m[1])) {
                return '<?php echo '.$m[1].'( '.$m[2].' ); ?>';
            }
            return $m[0];
        }, $content);
        $content = preg_replace('/\{(\$[a-z_][^\{\r\s\n\}]*)\}/is', '<?php echo \\1; ?>', $content);
        return $content;
    }
}
