<?php

class Configuration
{
    private static $configs = array();
    private $config;

    /**
     * @param  string $dir_path
     */
    public static function load($dir_path)
    {
        if (count(self::$configs)) {
            return;
        }

        $list = glob($dir_path.DIRECTORY_SEPARATOR.'*.php');
        foreach ($list as $file) {
            $name = str_replace('.php', '', substr($file, strrpos($file, DIRECTORY_SEPARATOR) + 1));
            $array = include_once $file;
            self::$configs[$name] = new Configuration($array);
        }
    }

    /**
     * @param  string $key
     * @return mixed
     */
    public static function get($key)
    {
        // echo "$key";exit('8888888');
        $key = explode('.', $key, 2);
        $value = isset(self::$configs[$key[0]]) ? self::$configs[$key[0]] : new Configuration();
        
        if (isset($key[1]) && $key[1]) {
            return self::recursive($value, $key[1]);
        }

        return $value;
    }

    /**
     * @param  Configuration $config
     * @param  string $key
     * @return mixed
     */
    private static function recursive($config, $key)
    {
        if (!preg_match('/^([_a-z]\w*)(\.(\w+))?$/i', $key, $matches)) {
            return null;
        }

        $value = $config->{$matches[1]};

        if (isset($matches[2]) && is_object($value) && 'Configuration' === get_class($value)) {
            return self::recursive($value, $matches[3]);
        }

        return $value;
    }

    /**
     * @param  array|null $array
     */
    public function __construct($array = null)
    {
        $this->config = array();

        if (is_array($array)) {
            foreach ($array as $key => $value) {
                if (is_scalar($value) || is_object($value)) {
                    $this->config[$key] = $value;
                }
                if (is_array($value)) {
                    $this->config[$key] = new Configuration($value);
                }
            }
        }
    }

    /**
     * @param  string $name
     * @return object|null
     */
    public function __get($name)
    {
        return isset($this->config[$name]) ? $this->config[$name] : null;
    }
}

if (!function_exists('config')) {

    /**
     * config('app.db.gido') return value
     * 
     * @param  string $key
     * @return mixed
     */
    function config($key)
    {
        return Configuration::get($key);
    }
}