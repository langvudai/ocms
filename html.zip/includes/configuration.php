<?php
/**
 * @copyright tam-chan.com
 */
final class Configuration
{
    private static $configs = array();
    private $config;

    /**
     * @param  string $key
     * @return mixed
     */
    public static function get($key)
    {
        $key = explode('.', $key, 2);
        $value = isset(self::$configs[$key[0]]) ? self::$configs[$key[0]] : new Configuration();
        
        return isset($key[1]) && $key[1] ? self::recursive($value, $key[1]) : $value;
    }

    /**
     * @param  string $dir_path
     */
    public static function load($dir_path)
    {
        count(self::$configs) || self::loadConfig($dir_path);
    }

    private static function loadConfig($dir_path)
    {
        $d = dir($dir_path);
        $entry = $d->read();
        (false !== $entry) && self::readDir($d, $dir_path, $entry);
        $d->close();
    }

    private static function readDir($d, $dir_path, $entry)
    {
        is_file($dir_path.DIRECTORY_SEPARATOR.$entry) && self::loadFile($d, $dir_path, $entry);
        $entry = $d->read();
        (false !== $entry) && self::readDir($d, $dir_path, $entry);
    }

    private static function loadFile($d, $dir_path, $entry)
    {
        $name = str_replace('.php', '', $entry);
        $array = self::incOnce($dir_path.DIRECTORY_SEPARATOR.$entry);
        is_null($name) || is_null($array) || self::addConfigs($name, $array);
    }

    private static function incOnce($path)
    {
        return include_once $path;
    }

    private static function addConfigs($name, $array)
    {
        self::$configs[$name] = new Configuration($array);
    }

    /**
     * @param  Configuration $config
     * @param  string $key
     * @return mixed
     */
    private static function recursive($config, $key)
    {
        return preg_match('/^([_a-z]\w*)(\.(\w+))?$/i', $key, $matches) ? self::getValue($config, $matches) : null;
    }

    private static function getValue($config, $matches)
    {
        $value = $config->{$matches[1]};
        return (isset($matches[2]) && is_object($value) && 'Configuration' === get_class($value)) ? self::recursive($value, $matches[3]) : $value;
    }

    /**
     * @param  array|null $array
     */
    public function __construct($array = null)
    {
        $this->config = array();
        is_array($array) && count($array) && $this->readA($array);
    }

    /**
     * @param  string $name
     * @return object|null
     */
    public function __get($name)
    {
        return isset($this->config[$name]) ? $this->config[$name] : null;
    }

    private function readA($array)
    {
        $key = key($array);
        $value = $array[$key];
        (is_scalar($value) || is_object($value)) && $this->assignConfig($key, $value);
        is_array($value) && $this->assignConfig($key, new Configuration($value));
        unset($array[$key]);
        count($array) && $this->readA($array);
    }

    private function assignConfig($key, $value)
    {
        $this->config[$key] = $value;
    }
}
