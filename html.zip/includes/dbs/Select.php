<?php 

defined('PREFIX')||define('PREFIX', '');

class Db_Select
{
    private 
        $field=array(), 
        $table='', 
        $_distinct='', 
        $_sqlCache='', 
        $_select='', 
        $_SQL_CALC_FOUND_ROWS='',
        $_from_enable=false;

    /**
     * @param  string $table [description]
     * @return object(alias, table)
     */
    private function getTable($table)
    {
        if (is_array($table)) {
            $key = key($table);
            $value = $table[$key];
            if (preg_match('/^([a-z_][a-z0-9_]*)$/i', $key) && is_a($value, get_class($this))) {
                return (object)array('alias'=>"`$key`", 'table'=>'('.$value.')');
            } elseif (preg_match('/^([a-z_][a-z0-9_]*)$/i', $key) && is_string($value) && preg_match('/^([a-z_][a-z0-9_]*)$/i', $value)) {
                return (object)array('alias'=>"`$key`", 'table'=>"`".PREFIX.$value."`");
            }
        } elseif (is_string($table)) {
            $table = trim($table);
            if (preg_match('/^([a-z][a-z0-9_]*)\s+([a-z][a-z0-9_]*)$/i', $table, $array)) {
                return (object)array('alias'=>"`".$array[2]."`", 'table'=>"`".PREFIX.$array[1]."`");
            } else {
                if (preg_match('/^([a-z][a-z0-9_]*)$/i', $table)) {
                    return (object)array('alias'=>"`".PREFIX.$table."`", 'table'=>"`".PREFIX.$table."`");
                }
            }
        }

        return null;
    }

    /**
     * @param  string|array $field [description]
     * @param  string $table [description]
     * @return array
     */
    private function getFeild($field, $table)
    {
        if ($field=='*') {
            return array("$table.$field");
        }
        if (is_string($field) && preg_match('/^[a-z0-9_\s,]+$/i', $field)) {
            $field = preg_replace('/([ ]*,[ ]*)/', ',', $field);
            $field = array_map('trim', explode(',', $field));
        }
        $array=array();
        if (is_array($field)) {
            foreach ($field as $key => $value) {
                if (is_string($value) && preg_match('/^[a-z_][a-z0-9_]*$/i', trim($value))) {
                    $value = $table.'.`'.str_ireplace('`', '', trim($value)).'`';
                } elseif (is_object($value)) {
                    $value = $value->scalar;
                } else {
                    return array();
                }

                if (preg_match('/^[a-z][a-z0-9_]*$/i', $key)) {
                    $array[] = "$value AS `$key`";
                } else {
                    $array[] = $value;
                }
            }
            return is_array($array) ? $array : array();
        }
        return array();
    }

    private function getOn($on)
    {
        if (is_object($on)) {
            return $on->scalar;
        }
        if (is_string($on)) {
            $on = preg_replace(
                array(
                    '/\s+/',
                    '/\s+=\s+/',
                    '/([a-z][a-z0-9_]*)(\.)?([a-z][a-z0-9_]*)?/i',
                    '/[`]+/', 
                    '/(\s`(and|or)`\s)/i', 
                    '/(=[^`])`([^`]*)`/i', 
                    '/`([^`]*)`([^`]=)/i'
                    ),
                array(
                    ' ',
                    '=', 
                    "`$1`$2`$3`", 
                    '`', 
                    " $2 ", 
                    "$1$2", 
                    "$1$2"
                    ),

                trim($on));
            return $on;
        }
        return null;
    }

    function __construct()
    {
        $this->_select = array(
                'HIGH_PRIORITY'=>0, 
                'STRAIGHT_JOIN'=>0,
                'SQL_SMALL_RESULT'=>0,
                'SQL_BIG_RESULT'=>0,
                'SQL_BUFFER_RESULT'=>0,
            );
        if (func_num_args()==2) {
            $field = func_get_arg(0);
            $table = func_get_arg(1);
            $tb = $this->getTable($table);
            if ($tb) {
                $this->table = $tb->table . ($tb->alias!=$tb->table ? (' AS '.$tb->alias) : '');
                $tb = $tb->alias;
                $this->field = array_merge($this->field, $this->getFeild($field, $tb));
            } else {
                die('Error: '.$table);
            }
        } else {
            $this->_from_enable = true;
        }
    }

    function from($table, $field)
    {
        if ($this->_from_enable ) {
            $tb = $this->getTable($table);
            if ($tb) {
                $this->table = $tb->table . ($tb->alias!=$tb->table ? (' AS '.$tb->alias) : '');
                $tb = $tb->alias;
                $this->field = array_merge($this->field, $this->getFeild($field, $tb));
            } else {
                die('Error: '.$table);
            }
        }
        return $this;
    }

    /**
     * ALL | DISTINCT | DISTINCTROW
     */
    function distinct($distinct='DISTINCT')
    {
        $this->_distinct = $distinct;
        return $this;
    }

    /**
     * SQL_CACHE | SQL_NO_CACHE
     */
    function sqlCache($status=true)
    {
        $this->_sqlCache = $status ? 'SQL_CACHE' : 'SQL_NO_CACHE';
        return $this;
    }

    function HIGH_PRIORITY()
    {
        $this->_select['HIGH_PRIORITY'] = 1;
        return $this;
    }

    function STRAIGHT_JOIN()
    {
        $this->_select['STRAIGHT_JOIN'] = 1;
        return $this;
    }

    function SQL_SMALL_RESULT()
    {
        $this->_select['SQL_SMALL_RESULT'] = 1;
        return $this;
    }

    function SQL_BIG_RESULT()
    {
        $this->_select['SQL_BIG_RESULT'] = 1;
        return $this;
    }

    function SQL_BUFFER_RESULT()
    {
        $this->_select['SQL_BUFFER_RESULT'] = 1;
        return $this;
    }

    function SQL_CALC_FOUND_ROWS()
    {
        $this->_SQL_CALC_FOUND_ROWS = 'SQL_CALC_FOUND_ROWS';
        return $this;
    }

    private $join;
    function join($query_string, $field=null)
    {
        $this->join[].= $query_string;
        if (!is_null($field)) {
            if (is_string($field) && preg_match('/^([a-z0-9_ ,])+$/i', $field)) {
                $field = preg_replace('/([ ]*,[ ]*)/', ',', $field);
                $field = explode(',', $field);
            }
            $array=array();
            if (is_array($field)) {
                foreach ($field as $key => $value) {
                    if (preg_match('/^[a-z][a-z0-9_]*$/i', $key)) {
                        $array[] = "$value AS `$key`";
                    } else {
                        $array[] = $value;
                    }
                }
            }
            $this->field = array_merge($this->field, $array);
        }
        return $this;
    }

    function innerJoin($table, $on, $field=null)
    {
        $tb = $this->getTable($table);
        if ($tb) {
            $on = $this->getOn($on);
            $this->join[].= "INNER JOIN ".$tb->table
                .($tb->alias!=$tb->table ? (" AS ".$tb->alias):'')
                ." ON $on";
            $tb = $tb->alias;
            if (!is_null($field)) {
                $this->field = array_merge($this->field, $this->getFeild($field, $tb));
            }
        }
        return $this;
    }

    function leftJoin($table, $on, $field=null)
    {
        $tb = $this->getTable($table);
        if ($tb) {
            $on = $this->getOn($on);
            $this->join[].= "LEFT JOIN ".$tb->table
                .($tb->alias!=$tb->table ? (" AS ".$tb->alias):'')
                ." ON $on";
            $tb = $tb->alias;
            if (!is_null($field)) {
                $this->field = array_merge($this->field, $this->getFeild($field, $tb));
            }
        }
        return $this;
    }

    function rightJoin($table, $on, $field=null)
    {
        $tb = $this->getTable($table);
        if ($tb) {
            $on = $this->getOn($on);
            $this->join[].= "RIGHT JOIN ".$tb->table
                .($tb->alias!=$tb->table ? (" AS ".$tb->alias):'')
                ." ON $on";
            $tb = $tb->alias;
            if (!is_null($field)) {
                $this->field = array_merge($this->field, $this->getFeild($field, $tb));
            }
        }
        return $this;
    }

    private $where;

    function where($condition, $value = null, $operator = '=')
    {
        $this->where[] = new Db_Where($condition, $value, $operator, 1);
        return $this;
    }

    function orWhere($condition, $value = null, $operator = '=')
    {
        $this->where[] = new Db_Where($condition, $value, $operator, -1);
        return $this;
    }

    private $groups;

    function group($spec)
    {
        $this->groups[] = $spec;
        return $this;
    }

    private $having_str='';

    function having($condition)
    {
        $this->having_str = " HAVING $condition";
        return $this;
    }

    private $orders;

    function order($field)
    {
        if (is_object($field) && isset($field->scalar)) {
            $this->orders[] = $field->scalar;
        } else {
            $field = preg_replace('/[ ]+/', ' ',str_ireplace('`', '', $field));
            $this->orders[] = preg_replace('/([a-z0-9_\-]+)( asc| desc)?/i', "`$1`$2", $field);
        }
        return $this;
    }

    private $limitoffset;

    function limit($limit, $page=0)
    {
        $limit = (int)$limit;
        $page = (int)$page;
        if ($limit) {
            $this->limitoffset = " LIMIT $limit";
        }
        if ($page>0) {
            $this->limitoffset.= " OFFSET ".(($page-1)*$limit);
        }
        return $this;
    }

    private function toSqlWhereCmd($conditions)
    {
        $sql = '';

        for ($i=0; $i<count($conditions); $i++) {
            $sql.= $i ? ($conditions[$i][1] ? " AND " : " OR ") : "";
            if (is_array($conditions[$i][0])) {
                $sql.= '(';
                $sql.= $this->toSqlWhereCmd($conditions[$i][0]);
                $sql.= ')';
            } else {
                $sql.= '('.$conditions[$i][0].')';
            }
        }

        return $sql;
    }

    function toSQLcmd()
    {
        $sql = "SELECT ".$this->_distinct;

        foreach ($this->_select as $key => $value) {
            $sql.= $value ? " $key" : '';
        }
        $sql.= $this->_sqlCache;
        $sql.= $this->_SQL_CALC_FOUND_ROWS;
        
        $sql.= " ".implode(', ', $this->field);
        $sql.= " FROM ".$this->table;
        $sql.= $this->join ? (" ".implode(' ', $this->join)) : '';

        if ($this->where) {
            $sql.= " WHERE ".preg_replace('/^\s*(or|and)\s*/i', '', implode('', array_map(function($item) {
                return $item->__toString();
            }, $this->where)));
        }
        if ($this->groups) {
            $sql.= " GROUP BY ".implode(', ', $this->groups);
            $sql.= $this->having_str;
        }
        $sql.= $this->orders ? (" ORDER BY ".implode(', ', $this->orders)) : "";
        
        return $sql. $this->limitoffset;
    }

    function __toString()
    {
        $sql = 'SELECT '.$this->_distinct;
        
        $sql.= " ".implode(', ', $this->field);
        $sql.= " FROM ".$this->table;
        $sql.= $this->join ? (" ".implode(' ', $this->join)) : '';
        if ($this->where) {
            $sql.= " WHERE ";
            for ($i=0; $i<count($this->where); $i++) {
                $sql.= $i ? ($this->where[$i][1] ? " AND " : " OR ") : "";
                $sql.= '('.$this->where[$i][0].')';
            }
        }
        if ($this->groups) {
            $sql.= " GROUP BY ".implode(', ', $this->groups);
            $sql.= $this->having_str;
        }
        $sql.= $this->orders ? (" ORDER BY ".implode(', ', $this->orders)) : "";
        return $sql. $this->limitoffset;
    }

    function getCount(){
        if (ini_get('mysql.trace_mode')) {
            return (object)array('calc_rows' => _connect_::$calc_rows);
        }
        $sql = "SELECT COUNT(*) `counter` FROM ( ";
        $sql.= "SELECT ".$this->_distinct;
        /**/
        foreach ($this->_select as $key => $value) {
            $sql.= $value ? " $key" : '';
        }
        $sql.= $this->_sqlCache;
        $sql.= $this->_SQL_CALC_FOUND_ROWS;
        $sql.= " ".implode(', ', $this->field);
        $sql.= " FROM ".$this->table;
        $sql.= $this->join ? (" ".implode(' ', $this->join)) : '';
        if ($this->where) {
            $sql.= " WHERE ";
            for ($i=0; $i<count($this->where); $i++) {
                $sql.= $i ? ($this->where[$i][1] ? " AND " : " OR ") : "";
                $sql.= '('.$this->where[$i][0].')';
            }
        }
        if ($this->groups) {
            $sql.= " GROUP BY ".implode(', ', $this->groups);
            $sql.= $this->having_str;
        }
        $sql.= ") tb".time();
        return (object)array('counter' => $sql." LIMIT 1");
    }

    public function query()
    {
        return new Db_SqlAdapter($this->toSQLcmd());
    }
}