<?php 
defined('PREFIX')||define('PREFIX', '');

class Db_SqlAdapter
{
    private 
        $SQLcmd = '', 
        $target,
        $data,
        $resource,
        $publisher;
    
    function __construct($sqlcmd)
    {
        if (!is_scalar($sqlcmd)) {
            $this->error = 'SQL command must is string';
            return;
        }

        $this->SQLcmd = preg_replace('/\{\$prefix\}/i', PREFIX, trim($sqlcmd));
        $is_save_log = config('app.sql_log');
        
        if (preg_match('/^select/i',$this->SQLcmd)) {
            $rs = Db_Connection_MySql::get()->query($this->SQLcmd);
            if (Db_Connection_MySql::get()->getNumRows() > 0) {
                $this->data = array();
                $this->resource = $rs;
            }
        } else {
            $this->execute();
        }
    }
    
    private function execute()
    {
        $rs = Db_Connection_MySql::get()->query($this->SQLcmd);
        if ($rs) {
            $this->publisher = array(
                'affectedRows' => Db_Connection_MySql::get()->getAffectedRows(),
                'lastid' => Db_Connection_MySql::get()->getInsertId(),
                'error' => null,
            );
        }

        return $this;
    }

    function __get($name)
    {
        return isset($this->publisher[$name]) ? $this->publisher[$name] : null;
    }

    function __set($name, $value)
    {
    }
    
    /**
     * @return array|null
     */
    function fetchRow(){
        if ($this->resource) {
            $row = Db_Connection_MySql::get()->fetchAssoc($this->resource);
            if ($row) {
                $this->data[] = array_map('stripcslashes', $row);
            }
            return $this->data[0];
        }
        return null;
    }

    /**
     * 
     * @param string $field_key 
     * @param boolean $group
     * @return array|null
     */
    function fetch($field_key='', $group=false){
        if ($this->resource) {
            while ($row = Db_Connection_MySql::get()->fetchAssoc($this->resource)) {
                $this->data[] = array_map('stripcslashes', $row);
            }

            if (!is_null($field_key) && isset($this->data[0]) && isset($this->data[0][$field_key]) && $this->data[0][$field_key]!='') {
                $rt = array();
                if ($group) {
                    $rt[$this->data[0][$field_key]][] = $this->data[0];
                    for($i = 1; isset($this->data[$i]); $i++) {
                        $rt[$this->data[$i][$field_key]][] = $this->data[$i];
                    }
                } else {
                    $rt[$this->data[0][$field_key]] = $this->data[0];
                    for($i = 1; isset($this->data[$i]); $i++) {
                        $rt[$this->data[$i][$field_key]] = $this->data[$i];
                    }
                }

                return $rt;
            }

            return $this->data;
        }

        return null;
    }

    /**
     * @param  string $field_value
     * @param  string $field_keys
     * @return array|null
     */
    function fetchArrayKey($field_value='', $field_keys='')
    {
        if ($this->resource) {
            while ($row = Db_Connection_MySql::get()->fetchAssoc($this->resource)) {
                $this->data[] = array_map('stripcslashes', $row);
            }

            if (empty($field_keys)) {
                $rt = array();
                $point = NULL;
                for($j = 0; isset($this->data[$j]); $j++) {
                    $row = $this->data[$j];
                    $i = 1;
                    if (!empty($field_value) && isset($row[$field_value])) {
                        $value = $row[$field_value];
                        unset($row[$field_value]);
                    } else {
                        $value = 1;
                    }
                    $cn = count($row);
                    foreach ($row as $k=>$v) {
                        if (is_null($point) || $i==1) {
                            if (!isset($rt["$v"])) {
                                $rt["$v"] = $i==$cn ? $value : array();
                            }
                            $point = &$rt[$v];
                        } else {
                            if (!isset($point["$v"])) {
                                $point["$v"] = $i==$cn ? $value : array();
                            }
                            $point = &$point[$v];
                        }
                        $i++;
                    }
                }

                return $rt;
            } else {
                $col = array_diff(array_map('trim', explode(',', $field_key)), array($field_value));
                $rt = array();
                $p = null;
                for($j = 0; isset($this->data[$j]); $j++) {
                    $r = $this->data[$j];
                    foreach ($col as $i => $c) {
                        if ($i == 0) {
                            if (!isset($rt[$r[$c]])) {
                                $rt[$r[$c]] = array();
                            }
                            $p = &$rt[$r[$c]];
                        } else {
                            if (!isset($p[$r[$c]])) {
                                $p[$r[$c]] = array();
                            }
                            $p = &$p[$r[$c]];
                        }
                    }
                    $p = $r[$field_value];
                }

                return $rt;
            }
        }

        return null;
    }
    
    /**
     * [fetchColumn description]
     * @param  string  $column [description]
     * @param  string  $key    [description]
     * @param  boolean $group  [description]
     * @return array|null
     */
    function fetchColumn($column, $key='', $group=false)
    {
        if ($this->resource) {
            while ($row = Db_Connection_MySql::get()->fetchAssoc($this->resource)) {
                $this->data[] = array_map('stripcslashes', $row);
            }

            $rt = array();
            if ($key) {
                if ($group) {
                    for($j = 0; isset($this->data[$j]); $j++) {
                        $this->data[$j] = array_map('stripcslashes', $this->data[$j]);
                        if (isset($this->data[$j][$column]) && isset($this->data[$j][$key])) {
                            $rt[$this->data[$j][$key]][] = $this->data[$j][$column];
                        }
                    }
                } else {
                    for($j = 0; isset($this->data[$j]); $j++) {
                        if (isset($this->data[$j][$column]) && isset($this->data[$j][$key])) {
                            $rt[$this->data[$j][$key]] = $this->data[$j][$column];
                        }
                    }
                }
            } else {
                for($j = 0; isset($this->data[$j]); $j++) {
                    if (isset($this->data[$j][$column])) {
                        $rt[] = $this->data[$j][$column];
                    }
                }
            }
           
            return $rt;
        }

        return null;
    }
}