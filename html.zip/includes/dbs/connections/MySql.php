<?php 

final class Db_Connection_MySql
{
    private static 
        $connection,
        $config;

    private 
        $mysql,
        $close,
        $transaction,
        $result_query,
        $error;

    public static function get()
    {
        if (!self::$connection) {
            self::$connection = new Db_Connection_MySql();
        }
        return self::$connection;
    }

    public static function escapeString($string)
    {
        return addcslashes($string, "'".'"'."\0"."\n"."\r");
    }
    
    public static function set($host, $user, $pass, $name)
    {
        self::$config['host'] = $host;
        self::$config['user'] = $user;
        self::$config['pass'] = $pass;
        self::$config['name'] = $name;
        if (self::$connection) {
            self::$connection->rollback();
            self::$connection->endTransaction();
            self::$connection = null;
        }
        self::$connection = new Db_Connection_MySql();
    }

    public function __construct()
    {
        if (!self::$config) {
            self::$config['host'] = config('app.mysql.host');
            self::$config['user'] = config('app.mysql.username');
            self::$config['pass'] = config('app.mysql.password');
            self::$config['name'] = config('app.mysql.database');
        }
        $this->mysql = new mysqli(self::$config['host'], self::$config['user'], self::$config['pass'], self::$config['name']);
        if (!$this->mysql->connect_error) {
            mysqli_set_charset($this->mysql,"utf8");
        }
    }

    public function __destruct()
    {
        if ($this->transaction) {
            $this->mysql->query('ROLLBACK');
        }
    }

    public function close()
    {
        if (!$this->transaction) {
            $this->mysql->close();
            $this->close = true;
        }
    }

    public function connect()
    {
        if ($this->close) {
            @$this->mysql->connect(self::$config['host'], self::$config['user'], self::$config['pass'], self::$config['name']);
            if ($this->mysql->connect_error) {
                die('Mysqli Connect Error ' . $this->mysql->connect_errno .':'. $this->mysql->connect_error); 
            }
            if (!$this->mysql->connect_error) {
                mysqli_set_charset($this->mysql,"utf8");
            }
            $this->close = false;
        }
    }

    public function transaction()
    {
        if (!$this->transaction) {
            $is_save_log = Configuration::get('app.sql_log');
            if ($is_save_log) {
                $time = function_exists('microtime') ? microtime(true) : 1;
                $rs = $this->mysql->query('START TRANSACTION');
                $end_time = function_exists('microtime') ? microtime(true) : 0;
                Log::open('sql')->info('START TRANSACTION', $end_time - $time);
            } else {
                $rs = $this->mysql->query('START TRANSACTION');
            }
            $this->transaction = 1;
        }
    }

    public function rollback()
    {
        if ($this->transaction) {
            $this->transaction = -1;
        }
    }

    public function endTransaction()
    {
        if ($this->transaction) {
            $sql = $this->transaction > 0 ? 'COMMIT' : 'ROLLBACK';
            $is_save_log = Configuration::get('app.sql_log');
            if ($is_save_log) {
                $time = function_exists('microtime') ? microtime(true) : 1;
                $rs = $this->mysql->query($sql);
                $end_time = function_exists('microtime') ? microtime(true) : 0;
                Log::open('sql')->info($sql, $end_time - $time);
            } else {
                $rs = $this->mysql->query($sql);
            }
        }
        $this->transaction = 0;
    }
           
    public function query($sql)
    {
        if ($this->mysql->connect_error) {
            return false;
        }
        if ($this->close) {
            $this->connect();
        }
        $is_save_log = Configuration::get('app.sql_log');
        if ($is_save_log) {
            $time = function_exists('microtime') ? microtime(true) : 1;
            $rs = $this->mysql->query($sql);
            $end_time = function_exists('microtime') ? microtime(true) : 0;
            Log::open('sql')->info($sql, $end_time - $time);
        } else {
            $rs = $this->mysql->query($sql);
        }
        if ($rs) {
            if (preg_match('/^\s*select\s+/i', $sql)) {
                $this->result_query = array('numRows' => $rs->num_rows);
            } elseif (preg_match('/^\s*(insert|update|delete)\s+/i', $sql)) {
                $this->result_query = array(
                    'insertId' => @$this->mysql->insert_id,
                    'affectedRows' => @$this->mysql->affected_rows,
                );
            }
            return $rs;
        } else {
            $this->error = $this->mysql->errno . ": " . $this->mysql->error;
            if ($is_save_log) {
                Log::open('sql')->error($this->error);
            }
            return false;
        }
    }

    public function fetchAssoc($result_query){
        return $result_query ? $result_query->fetch_assoc() : NULL;
    }

    public function getError()
    {
        return $this->error;
    }

    public function getNumRows()
    {
        return isset($this->result_query['numRows']) ? $this->result_query['numRows'] : 0;
    }

    public function getInsertId()
    {
        return isset($this->result_query['insertId']) ? $this->result_query['insertId'] : 0;
    }

    public function getAffectedRows()
    {
        return isset($this->result_query['affectedRows']) ? $this->result_query['affectedRows'] : 0;
    }
}