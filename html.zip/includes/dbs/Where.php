<?php 

/**
 * 
 */
class Db_Where
{
    private $where;

    function __construct($condition, $value, $operator = '=', $and = 1)
    {
        if (is_object($condition) && get_class($condition) == 'Db_Where') {
            $this->where[] = array($condition->__toString(), $and);
        } elseif (is_array($condition)) {
            $this->where[] = array('('.preg_replace('/^\s*(or|and)\s*/i', '', implode('', array_map(function($item) {
                if (is_object($item) && get_class($item) == 'Db_Where') {
                    return $item->__toString();
                }
                return $item;
            }, $condition))).')', $and);
        } elseif (is_string($condition) && $value) {
            $field = preg_replace('/([a-z][a-z0-9_]*)/i', "`$1`", str_ireplace('`', '', trim($condition)));
            if (is_object($value) && get_class($value) == 'Db_Select') {
                $this->where[] = array("($field IN(".$value->__toString()."))", $and);
            } elseif (is_array($value)) {
                $value = implode(', ', array_map(function($v) {
                    return is_numeric($v) ? "'$v'" : ("'".Db_Connection_MySql::escapeString($v)."'");
                }, $value));
                if ($operator === '=') {
                    $operator = 'IN';
                }
                $this->where[] = array("($field $operator ($value))", $and);
            } else {
                $value = is_numeric($value) ? "'$value'" : ("'".Db_Connection_MySql::escapeString($value)."'");
                $this->where[] = array("($field $operator $value)", $and);
            }
        } elseif (is_string($condition) && !$value) {
            $this->where[] = array($condition, $and);
        }
    }

    private function toSql($conditions)
    {
        $sql = '';

        for ($i=0; $i<count($conditions); $i++) {
            if ($conditions[$i][1] > 0) {
                $sql.= ' AND ';
            }
            if ($conditions[$i][1] < 0) {
                $sql.= ' OR ';
            }
            
            if (is_array($conditions[$i][0])) {
                $sql.= $this->toSql($conditions[$i][0]);
            } else {
                $sql.= $conditions[$i][0];
            }
        }

        return $sql;
    }

    function __toString()
    {
        return $this->toSql($this->where);
    }

    public static function isNull($field)
    {
        $field = preg_replace('/([a-z][a-z0-9_]*)/i', "`$1`", str_ireplace('`', '', trim($field)));
        return new Db_Where("($field IS NULL)", null, null, null);
    }

    public static function isNotNull($field)
    {
        $field = preg_replace('/([a-z][a-z0-9_]*)/i', "`$1`", str_ireplace('`', '', trim($field)));
        return new Db_Where("($field IS NOT NULL)", null, null, null);
    }
}