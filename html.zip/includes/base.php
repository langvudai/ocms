<?php 

abstract class Base
{
    /**
     * invokeMethod: invoke if method is public
     * @param $method
     * @param $app
     * @return bool|mixed
     * @throws Exception
     */
    public final function invokeMethod($method)
    {
        try {
            $app = new App();
            $reflection_method = $this->getReflectionMethod($this, $method);
            $is = $reflection_method instanceof ReflectionMethod;
            $parameters = $is ? $reflection_method->getParameters() : array();
            $arguments = array();
            foreach ($parameters as $parameter) {
                $name = $parameter->getName();
                $arguments[] = isset($app->$name) ? $app->$name : $this->getValueParameter($parameter);
            }
            return $is ? ($reflection_method->isPublic() ? $reflection_method->invokeArgs($this, $arguments) : false) : false;
        } catch (Exception $e) {
            Log::open('app')->error($e->getMessage());
        }

        return false;
    }

    /**
     * [includeTemplate description]
     * @param  string $template
     * @param  mixed $data
     * @return void
     */
    protected final function includeTemplate($template, $data)
    {
        include_once $template;
    }

    /**
     * @param $object
     * @param $method_name
     * @return null|ReflectionMethod
     * @throws Exception
     */
    protected final function getReflectionMethod($object, $method_name)
    {
        try {
            $request_submit = Request::getSubmit();
            return new ReflectionMethod(get_class($object), $request_submit.'_'.$method_name);
        } catch (Exception $e) {
            try {
                return new ReflectionMethod(get_class($object), $method_name);
            } catch (Exception $ex) {
                Log::open('app')->error($e->getMessage() .' '. $ex->getMessage());
            }
        }
        return null;
    }

    private final function getValueParameter($parameter)
    {
        try {
            $reflection = $parameter->getClass();
            return $reflection instanceof ReflectionClass ? $this->getReflectionClass($reflection) : ($parameter->isDefaultValueAvailable() ? $parameter->getDefaultValue() : null);
        } catch (Exception $e) {
            Log::open('app')->warning($e->getMessage());
            return null;
        }
    }

    private final function getReflectionClass($reflector_class)
    {
        $constructor = $reflector_class->getConstructor();
        $parameters = is_null($constructor) ? null : $constructor->getParameters();
        return empty($parameters) ? $reflector_class->newInstance() : $reflector_class->newInstanceArgs($this->getArguments($parameters));
    }

    private final function getArguments($parameters)
    {
        $arguments = array();
        foreach ($parameters as $parameter) {
            $arguments[] = $this->getValueParameter($parameter);
        }
        return $arguments;
    }
}
