<?php 

abstract class Initialization
{
    protected $app;

    /**
     * run
     * @return void
     */
    public function run()
    {
        $time = microtime(true);
        Log::open('app')->info('start app');

        if (!$this->app) {
            $this->app = new App();
        }
        $method = $this->app->method;
        
        if (!defined('DEBUG') || !DEBUG) {
            ini_set('display_startup_errors',1);
            ini_set('display_errors',1);
            error_reporting(-1);
            ob_start();
        }

        $result = $this->invokeMethod($method, $this->app);
        
        if (!defined('DEBUG') || !DEBUG) {
            ini_set('display_startup_errors',0);
            ini_set('display_errors',0);
            error_reporting(0);
        }
        
        if ($result === false) {
            return false;
        }

        if (is_object($result)) {
            try {
                $render = $this->getReflectionMethod($result, 'render');
                if ($render->isPublic()) {
                    $render->invoke($result);
                }
            } catch (Exception $e) {
                Log::open('app')->error($e->getMessage());
            }            
        } else {
            $data = is_array($result) && isset($result[1]) ? $result[1] : null;
            $template = is_string($result) ? $result : (is_array($result) && isset($result[0]) && is_string($result[0]) ? $result[0] : null);
            if (file_exists($template) && is_readable($template) && is_file($template)) {
                $this->includeTemplate($template, $data);
            } else {
                $template = Configuration::get('app.paths.view_dir') .'/'. $template .'.php';
                if (file_exists($template) && is_readable($template) && is_file($template)) {
                    $this->includeTemplate($template, $data);
                }
            }
        }
        Log::open('app')->info('end app', microtime(true) - $time);
    }

    /**
     * invokeMethod: invoke if method is public
     * @param $method
     * @param $tc
     * @return bool|mixed
     * @throws Exception
     */
    public function invokeMethod($method, $tc)
    {
        try {
            $reflection_method = $this->getReflectionMethod($this, $method);
            $is = $reflection_method instanceof ReflectionMethod;
            $parameters = $is ? $reflection_method->getParameters() : array();
            $arguments = array();
            foreach ($parameters as $parameter) {
                $name = $parameter->getName();
                $arguments[] = isset($tc->$name) ? $tc->$name : $this->getValueParameter($parameter);
            }
            return $is ? ($reflection_method->isPublic() ? $reflection_method->invokeArgs($this, $arguments) : false) : false;
        } catch (Exception $e) {
            Log::open('app')->error($e->getMessage());
        }

        return false;
    }

    /**
     * [includeTemplate description]
     * @param  [type] $template [description]
     * @param  [type] $data     [description]
     * @return [type]           [description]
     */
    private function includeTemplate($template, $data)
    {
        include_once $template;
    }

    /**
     * @param $object
     * @param $method_name
     * @return null|ReflectionMethod
     * @throws Exception
     */
    private function getReflectionMethod($object, $method_name)
    {
        try {
            $request_method = Request::getMethod();
            return new ReflectionMethod(get_class($object), $request_method.'_'.$method_name);
        } catch (Exception $e) {
            try {
                return new ReflectionMethod(get_class($object), $method_name);
            } catch (Exception $ex) {
                Log::open('app')->error($e->getMessage() .' '. $ex->getMessage());
            }
        }
        return null;
    }

    private function getValueParameter($parameter)
    {
        try {
            $reflection = $parameter->getClass();
            return $reflection instanceof ReflectionClass ? $this->getReflectionClass($reflection) : ($parameter->isDefaultValueAvailable() ? $parameter->getDefaultValue() : null);
        } catch (Exception $e) {
            Log::open('app')->warning($e->getMessage());
            return null;
        }
    }

    private function getReflectionClass($reflector_class)
    {
        $constructor = $reflector_class->getConstructor();
        $parameters = is_null($constructor) ? null : $constructor->getParameters();
        return empty($parameters) ? $reflector_class->newInstance() : $reflector_class->newInstanceArgs($this->getArguments($parameters));
    }

    private function getArguments($parameters)
    {
        $arguments = array();
        foreach ($parameters as $parameter) {
            $arguments[] = $this->getValueParameter($parameter);
        }
        return $arguments;
    }
}
