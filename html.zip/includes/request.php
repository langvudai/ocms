<?php 

class Request
{
    private static $method = null;
    protected static $request = array();
    protected $validities;

    /**
     * recommend only used in <form></form>
     * @return [type] [description]
     */
    public static final function methodReplaceName()
    {
        $arr = Session::instance()->uniqueValue();
        return 'replace_method'.$arr[2];
    }

    /**
     * [getMethod description]
     * @return string
     */
    public static final function getMethod()
    {
        if (self::ajax() && isset($_SERVER['REQUEST_METHOD'])) {
            return $_SERVER['REQUEST_METHOD'];
        }

        if (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
            $replace_method = self::methodReplaceName();
            return isset($_REQUEST[$replace_method]) ? strtoupper($_REQUEST[$replace_method]) : 'POST';
        }

        if (self::$method) {
            return self::$method;
        }

        return 'GET';
    }

    /**
     * [ajax description]
     * @return string|boolean
     */
    public static final function ajax() 
    {
        $key = Configuration::get('app.ajax.key');
        $prefix_value = Configuration::get('app.ajax.prefix_value');

        if (!$key || !is_string($key)) {
            $key = 'HTTP_X_REQUESTED_WITH';
        }

        if (!$prefix_value || !is_string($prefix_value)) {
            $prefix_value = 'XMLHttpRequest';
        }

        if (isset($_SERVER[$key])) {
            preg_match('/^'.$prefix_value.'(\w+)?$/', $_SERVER[$key], $matches);
            return isset($matches[1]) ? strtoupper($matches[1]) : true;
        }

        return false;
    }

    public final static function instance()
    {
        if (!self::$instance) {
            self::$instance = new Request();
        }

        return self::$instance;
    }

    public final function __construct() 
    {
        if (empty(self::$request)) {
            if (self::ajax() || (defined('DEBUG') && DEBUG)) {
                self::$request = $_REQUEST;
            } else {
                if (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
                    Session::instance()->set('POST', $_REQUEST);
                    header('Location: '.$_SERVER['REQUEST_URI']);
                    exit();
                }

                if (Session::instance()->exist('POST')) {
                    $posts = Session::instance()->get('POST');
                    Session::instance()->delete('POST');
                    if (is_array($posts)) {
                        $replace_method = self::methodReplaceName();
                        self::$method = isset($posts[$replace_method]) ? $posts[$replace_method] : null;
                        unset($posts[$replace_method]);
                        self::$request = $posts;
                    } else {
                        self::$request = array();
                    }
                } else {
                    self::$request = $_REQUEST;
                }
            }
        }

        if (self::$request) {
            $ref = new ReflectionClass($this);
            if ($ref->hasMethod('validate')) {
                $rules = $ref->getMethod('validate')->invoke($this);
                if (is_array($rules)) {
                    $invalid_keys = $this->validation($rules);
                    if ($ref->hasMethod('onInvalid')) {
                        $ref->getMethod('onInvalid')->invokeArgs($this, array($invalid_keys));
                    }
                }
            }
        }
    }

    public function __get($name)
    {
        $values = is_array($this->validities) ? $this->validities : self::$request;
        if (isset($values[$name])) {
            return $values[$name];
        }
        $name = preg_replace_callback('/([a-z0-9])([A-Z])/', function($matches) {
            return $matches[1] .'-'. strtolower($matches[2]);
        }, $name);
        if (isset($values[$name])) {
            return $values[$name];
        }
        return null;
    }

    public function __set($name, $value)
    {
        return false;
    }

    private function validation($rules)
    {
        $this->validities = array();
        $invalid_keys = array();

        foreach ($rules as $key => $pattern) {
            if (is_array($pattern)) {
                $invalid = array();
                foreach ($pattern as $child_key => $child_pattern) {
                    if (isset(self::$request[$key]) && !preg_match($child_pattern, self::$request[$key])) {
                        $invalid[] = $child_key;
                    }
                }
                if ($invalid) {
                    $invalid_keys[$key] = $invalid;
                } else {
                    $this->validities[$key] = self::$request[$key];
                }
            } elseif (is_string($pattern)) {
                if (isset(self::$request[$key]) && preg_match($pattern, self::$request[$key])) {
                    $this->validities[$key] = self::$request[$key];
                } else {
                    $invalid_keys[$key] = $key;
                }
            }
        }

        return $invalid_keys;
    }
}
