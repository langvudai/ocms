<?php 

class Request
{
    private static $submit = null;
    protected static $request = array();
    protected $validities;

    /**
     * recommend only used in <form></form>
     * @return [type] [description]
     */
    public final static function submitName()
    {
        return Session::instance()->uniqid('-');
    }

    /**
     * [getMethod description]
     * @return string|null
     */
    public final static function getSubmit()
    {
        if (self::$submit) {
            return self::$submit;
        }

        $name = Session::instance()->uniqid('-');

        if (Session::instance()->exist('SUBMIT')) {
            self::$submit = Session::instance()->get('SUBMIT');
        } elseif (Session::instance()->exist('POST')) {
            $posts = Session::instance()->get('POST');
            self::$submit = isset($posts[$name]) ? strtoupper($posts[$name]) : null;
        } else {
            self::$submit = isset($_REQUEST[$name]) ? strtoupper($_REQUEST[$name]) : null;
        }

        return self::$submit;
    }

    /**
     * [ajax description]
     * @return string|false
     */
    public final static function ajax() 
    {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && preg_match('/^XMLHttpRequest(\w+)?$/', $_SERVER['HTTP_X_REQUESTED_WITH'], $matches)) {
            return isset($matches[1]) ? strtoupper($matches[1]) : true;
        }
        return false;
    }

    public final static function instance()
    {
        if (!self::$instance) {
            self::$instance = new Request();
        }

        return self::$instance;
    }

    public function __construct() 
    {
        if (empty(self::$request)) {
            if (defined('DEBUG') && DEBUG) {
                self::$request = $_REQUEST;
            } else {
                if (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
                    Session::instance()->set('POST', $_REQUEST);
                    header('Location: '.$_SERVER['REQUEST_URI']);
                    exit();
                }

                if (Session::instance()->exist('POST')) {
                    $posts = Session::instance()->get('POST');
                    Session::instance()->delete('POST');
                    self::$request = is_array($posts) ? $posts : array();
                } else {
                    self::$request = $_REQUEST;
                }
            }
        }

        if (self::$request) {
            $name = Session::instance()->uniqid('-');
            if (isset(self::$request[$name])) {
                Session::instance()->set('SUBMIT', strtoupper(self::$request[$name]));
            }

            $ref = new ReflectionClass($this);
            if ($ref->hasMethod('validate')) {
                $rules = $ref->getMethod('validate')->invoke($this);
                if (is_array($rules)) {
                    $invalid_keys = $this->validation($rules);
                    if ($ref->hasMethod('onInvalid')) {
                        $ref->getMethod('onInvalid')->invokeArgs($this, array($invalid_keys));
                    }
                }
            }
        }
    }

    public function __get($name)
    {
        $values = is_array($this->validities) ? $this->validities : self::$request;
        if (isset($values[$name])) {
            return $values[$name];
        }
        $name = preg_replace_callback('/([a-z0-9])([A-Z])/', function($matches) {
            return $matches[1] .'-'. strtolower($matches[2]);
        }, $name);
        if (isset($values[$name])) {
            return $values[$name];
        }
        return null;
    }

    public function __set($name, $value)
    {
        return false;
    }

    private function validation($rules)
    {
        $this->validities = array();
        $invalid_keys = array();

        foreach ($rules as $key => $pattern) {
            if (is_array($pattern)) {
                $invalid = array();
                foreach ($pattern as $child_key => $child_pattern) {
                    if (isset(self::$request[$key]) && !preg_match($child_pattern, self::$request[$key])) {
                        $invalid[] = $child_key;
                    }
                }
                if ($invalid) {
                    $invalid_keys[$key] = $invalid;
                } else {
                    $this->validities[$key] = self::$request[$key];
                }
            } elseif (is_string($pattern)) {
                if (isset(self::$request[$key]) && preg_match($pattern, self::$request[$key])) {
                    $this->validities[$key] = self::$request[$key];
                } else {
                    $invalid_keys[$key] = $key;
                }
            }
        }

        return $invalid_keys;
    }
}
