<?php 

defined('PREFIX')||define('PREFIX', '');

class Db_Sql
{
    private $_cmd;
    private static $_tableSchema;
    protected $_name = '', $lastId, $affectedRows, $_fields;
    public $error;

    /**
     * @param  string $name
     * @param  mixed $arguments
     * @return mixed
     */
    public function __call($name, $arguments)
    {
        $method = 'transaction'.strtoupper(substr($name, 0, 1)).substr($name, 1);
        $ref = new ReflectionClass($this);
        if ($ref->hasMethod($method)) {
            $this->transaction();
            $result = $ref->getMethod($method)->invokeArgs($this, $arguments);
            $this->endTransaction();
            return $result;
        } else {

        }
    }
    
    /**
     * @param  array $fields
     * @return void
     */
    final function filterField($fields)
    {
        $this->_fields = $fields;
    }

    /**
     * @param  string $db_name
     * @return void
     */
    final function getTableSchema($db_name)
    {
        $tbname = PREFIX.$this->_name;

        if (!isset(self::$_tableSchema[$tbname])) {
            $rs = Db_Connection_MySql::get()->query("SELECT `COLUMN_NAME`, `COLUMN_TYPE`, `COLUMN_DEFAULT`, `COLUMN_KEY` FROM information_schema.columns WHERE table_schema = '$db_name' AND table_name = '$tbname'");
            while ($r = Db_Connection_MySql::get()->fetchAssoc($rs)) {
                self::$_tableSchema[$tbname][$r['COLUMN_NAME']] = array('type'=>$r['COLUMN_TYPE'], 'default'=>$r['COLUMN_DEFAULT'], 'key'=>$r['COLUMN_KEY']);
            }
        }

        return isset(self::$_tableSchema[$tbname]) ? self::$_tableSchema[$tbname] : array();
    }

    /**
     * @param  string $sql
     * @param  array|null $param
     * @return Db_SqlAdapter
     */
    final function query($sql, $param=NULL)
    {
        if (is_array($param) && !is_object($sql) && !is_array($sql)) {
            foreach ($param as $key => $value) {
                if (is_object($value) && isset($value->scalar)) {
                    $sql = str_ireplace('{$'.$key.'}', $value->scalar, $sql);
                } elseif (!is_null($value) && is_scalar($value)) {
                    $value = is_numeric($value) ? $value :("'".Db_Connection_MySql::escapeString($value)."'");
                    $sql = str_ireplace('{$'.$key.'}', $value, $sql);
                } elseif (is_null($value)) {
                    $sql = str_ireplace('{$'.$key.'}', 'NULL', $sql);
                }
            }
        }
        return new Db_SqlAdapter($sql);
    }
    
    /**
     * @return string
     */
    public function __toString()
    {
        return is_string($this->_cmd) ? $this->_cmd : '';
    }

    /**
     * @param  string $value
     * @return string
     */
    public function escapeString($value)
    {
        return Db_Connection_MySql::escapeString($value);
    }

    /**
     * @return Db_Table
     */
    final function transaction() {
        Db_Connection_MySql::get()->transaction();
        return $this;
    }

    /**
     * @return Db_Table
     */
    final function rollback() {
        Db_Connection_MySql::get()->rollback();
        return $this;
    }

    /**
     * @return Db_Table
     */
    final function endTransaction() {
        Db_Connection_MySql::get()->endTransaction();
        return $this;
    }

    /**
     * @param  array $data
     * @param  array|null $data_update_if_duplicate_key
     * @return boolean
     */
    final function insert($data, $data_update_if_duplicate_key=NULL) {
        if (is_scalar($this->_name) && is_array($data) && $data) {
            $table = PREFIX.$this->_name;
            $this->_cmd = "INSERT INTO `$table`";
            $field = $value = array();
            foreach ($data as $f=>$v) {
                if (is_object($v) && isset($v->scalar)) {
                    $field[] = "`$f`";
                    $value[] = $v->scalar;  
                } elseif (!is_null($v) && !is_array($v) && !is_object($v) && trim($v)!='') {
                    $field[] = "`$f`";
                    $value[] = is_numeric($v)? $v : ("N'".Db_Connection_MySql::escapeString($v)."'");
                }
            }

            $this->_cmd.= " (".implode(', ', $field).") VALUES (".implode(", ", $value).")";
            if ($data_update_if_duplicate_key && is_array($data_update_if_duplicate_key)) {
                $upd = array();
                foreach ($data_update_if_duplicate_key as $f=>$v) {
                    if (is_object($v) && isset($v->scalar)) {
                        $upd[] = "`$f`=" . $v->scalar; 
                    } elseif (!is_null($v) && !is_array($v) && !is_object($v)) {
                        $upd[] = "`$f`=" . (is_numeric($v)? $v : ("N'".Db_Connection_MySql::escapeString($v)."'"));
                    }
                }

                $this->_cmd.= " ON DUPLICATE KEY UPDATE ".implode(', ', $upd);
            }

            $result = Db_Connection_MySql::get()->query($this->_cmd);
            $this->error = Db_Connection_MySql::get()->getError();
            $this->lastId = Db_Connection_MySql::get()->getInsertId();

            if (!$result) {
                Db_Connection_MySql::get()->rollback();
            }
            
            return $result;
        } else {
            /*throw new Exception("No table insert OR no data insert", 1);*/
        }
        return false;
    }
    
    /**
     * @param  array $data
     * @param  string|Db_Where $where
     * @return boolean
     */
    final function update($data, $where) {
        if (is_scalar($this->_name) && is_array($data) && $data) {
            $table = PREFIX.$this->_name;
            $this->_cmd = "UPDATE `$table` SET ";
            $set = array();
            foreach ($data as $f=>$v) {
                if (is_object($v) && isset($v->scalar)) {
                    $set[] = "`$f`=".$v->scalar;
                } elseif (!is_null($v) && !is_array($v) && !is_object($v)) {
                    $set[] = "`$f`=".(is_numeric($v) ? $v :("N'".Db_Connection_MySql::escapeString($v)."'"));
                }
            }
            if (is_object($where) && get_class($where) == 'Db_Where') {
                $where = preg_replace('/\s*(AND|OR)\s*/i', '', $where->__toString());
            } else {
                $where = preg_replace('/\{\$prefix\}/i', PREFIX, trim($where));
            }
            $this->_cmd.= implode(', ', $set)." WHERE $where";
            /* */
            $result = Db_Connection_MySql::get()->query($this->_cmd);
            $this->error = Db_Connection_MySql::get()->getError();
            $this->affectedRows = Db_Connection_MySql::get()->getAffectedRows();

            if (!$result) {
                Db_Connection_MySql::get()->rollback();
            }
            
            return $result;
        } else {
            /*throw new Exception("No table update OR no data update", 1);*/
            
        }
        return false;
    }

    /**
     * @param  string|Db_Where $where
     * @return boolean
     */
    final function delete($where) {
        if (is_scalar($this->_name)) {
            $table = PREFIX.$this->_name;
            if (is_object($where) && get_class($where) == 'Db_Where') {
                $where = preg_replace('/\s*(AND|OR)\s*/i', '', $where->__toString());
            } else {
                $where = preg_replace('/\{\$prefix\}/i', PREFIX, trim($where));
            }
            $this->_cmd = "DELETE FROM `$table` WHERE $where";
            $result = Db_Connection_MySql::get()->query($this->_cmd);
            $this->error = Db_Connection_MySql::get()->getError();
            $this->affectedRows = Db_Connection_MySql::get()->getAffectedRows();

            if (!$result) {
                Db_Connection_MySql::get()->rollback();
            }
            
            return $result;
        } else {
            /*throw new Exception("No table delete", 1);*/
            
        }
        return false;
    }

    final function where($condition, $value = null, $operator = '=')
    {
        new Db_Where($condition, $value, $operator, 1);
    }

    final function orWhere($condition, $value = null, $operator = '=')
    {
        new Db_Where($condition, $value, $operator, -1);
    }
    
    /**
     * @return Db_Select
     */
    final function select()
    {
        return new Db_Select();
    }
}   
?>