<?php 

class Request
{
    private static $method = null;
    protected static $request = array();

    /**
     * [getMethod description]
     * @return string|null
     */
    public static function getMethod()
    {
        if (self::$method) {
            return self::$method;
        }

        if (Session::instance()->exist('METHOD')) {
            self::$method = Session::instance()->get('METHOD');
            Session::instance()->delete('METHOD');
        } else {
            $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : null;
            $verification = Session::instance()->get('_token');
            $token = isset($_REQUEST['_token']) ? $_REQUEST['_token'] : null;
            if ($token && $token === $verification) {
                Session::instance()->delete('_token');
                self::$method = isset($_REQUEST['_method']) ? strtoupper($_REQUEST['_method']) : $method;
            } elseif (!$verification) {
                self::$method = $method;
            }
        }

        return self::$method;
    }

    /**
     * [ajax description]
     * @return string|false
     */
    public static function ajax() 
    {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && preg_match('/^XMLHttpRequest(\w+)?$/', $_SERVER['HTTP_X_REQUESTED_WITH'], $matches)) {
            return isset($matches[1]) ? strtoupper($matches[1]) : true;
        }
        return false;
    }

    public static function instance()
    {
        if (!self::$instance) {
            self::$instance = new Request();
        }
        return self::$instance;
    }

    // public static function getInstance()
    // {
    //     return self::$instance;
    // }

    // public static function getRequest()
    // {
    //     return self::$instance;
    // }

    public function __construct() 
    {
        if (empty(self::$request)) {
            if (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
                $method = self::getMethod();
                unset($_REQUEST['_token']);
                unset($_REQUEST['_method']);
                Session::instance()->set('POST', $_REQUEST);
                Session::instance()->set('METHOD', $method);
                header('Location: '.$_SERVER['REQUEST_URI']);
                exit();
            }

            if (Session::instance()->exist('POST')) {
                $posts = Session::instance()->get('POST');
                self::$request = is_array($posts) ? $posts : array();
                Session::instance()->delete('POST');
            } else {
                self::$request = $_REQUEST;
            }
        }
    }

    public function __get($name)
    {
        return isset(self::$request[$name]) ? self::$request[$name] : null;
    }

    public function __set($name, $value)
    {
        return false;
    }
}
