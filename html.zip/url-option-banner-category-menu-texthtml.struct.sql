CREATE TABLE `url_alias` (
  `url_alias_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `type` varchar(10) NOT NULL,
  `id` bigint(20) unsigned NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `target` varchar(20) DEFAULT '',
  PRIMARY KEY (`url_alias_id`),
  UNIQUE KEY `id_type_uk` (`type`,`id`) USING BTREE,
  UNIQUE KEY `url_uk` (`url`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `define_options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type`  varchar(20) CHARACTER SET latin1 NOT NULL,
  `keyword` varchar(50) CHARACTER SET latin1 NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyword` (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `position` int(11) unsigned NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `target` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `click` bigint(20) DEFAULT '0',
  `filename` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `descrption` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `display` tinyint(1) NOT NULL DEFAULT '1',
  `order` int(11) DEFAULT '1',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `time_create` int(11) DEFAULT '0',
  `time_update` int(11) DEFAULT '0',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_create` bigint(20) unsigned DEFAULT NULL,
  `usage` tinyint(1) DEFAULT '1',
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_type` int(11) unsigned NOT NULL DEFAULT '0',
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order` int(11) unsigned NOT NULL DEFAULT '10',
  `display` tinyint(1) NOT NULL DEFAULT '0',
  `zone`  varchar(20) DEFAULT NULL,
  `appearance` varchar(20) DEFAULT NULL,
  `thumbnail` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `time_create` int(11) DEFAULT '0',
  `time_update` int(11) DEFAULT '0',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_create` bigint(20) unsigned DEFAULT NULL,
  `usage`  tinyint(1) NULL DEFAULT 1,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `category_lang` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'vi',
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_lang_uk` (`category_id`,`lang`) USING BTREE,
  CONSTRAINT `fk_category_lang_categories ` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `banner_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `banner_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `banner_category_uk` (`banner_id`,`category_id`) USING BTREE,
  KEY `category_id` (`category_id`),
  CONSTRAINT `fk_banner_category_banners` FOREIGN KEY (`banner_id`) REFERENCES `banners` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_banner_category_categories` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `category_option` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `option_id` bigint(20) unsigned NOT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'vi',
  `value` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_option_uk` (`category_id`,`option_id`,`lang`) USING BTREE,
  CONSTRAINT `fk_category_option_categories ` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

CREATE TABLE `menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `menu_type` int(11) NOT NULL DEFAULT '0',
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `target` varchar(20) DEFAULT '_top',
  `url_id` bigint(20) unsigned DEFAULT NULL,
  `display` tinyint(1) DEFAULT '0',
  `order` int(11) DEFAULT '1',
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_create` int(11) DEFAULT NULL,
  `time_update` int(11) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_create` bigint(20) DEFAULT '0',
  `usage`  tinyint(1) NULL DEFAULT 1,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `menus_uk` USING BTREE (`url`),
  INDEX `menu_type` USING BTREE (`menu_type`),
  INDEX `url_id` USING BTREE (`url_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `menu_lang` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` bigint(20) unsigned NOT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'vi',
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_lang_uk` (`menu_id`,`lang`) USING BTREE,
  CONSTRAINT `fk_menu_lang_menus` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `texthtml` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) unsigned NOT NULL DEFAULT '0',
  `name`  varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `data_type`  tinyint(4) NOT NULL DEFAULT 1,
  `order`  int(11) NULL,
  `description`  varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `usage`  tinyint(1) NULL DEFAULT 1,
  `time_create` int(11) NULL,
  `time_update` int(11) NULL,
  `user_id` bigint(20) unsigned NULL,
  `user_create` bigint(20) NULL,
  `timestamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `texthtml_name_uk` (`name`,`usage`,`type`) USING BTREE
) ENGINE=InnoDB;

CREATE TABLE `texthtml_content` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `texthtml_id` bigint(20) unsigned NOT NULL,
  `lang`  varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'vi',
  `value` text CHARACTER SET utf8,
  PRIMARY KEY (`id`),
  UNIQUE KEY `texthtml_id` (`texthtml_id`, `lang`),
  CONSTRAINT `texthtml_content_ibfk_1` FOREIGN KEY (`texthtml_id`) REFERENCES `texthtml` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB;




CREATE TABLE `forms` (
`id`  bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
`name`  varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ,
`header`  varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL ,
`caption`  text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL ,
`footer`  varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL ,
`usage`  tinyint(1) NULL DEFAULT 1 ,
`time_create`  int(11) NULL ,
`time_update`  int(11) NULL ,
`user_id`  bigint(20) NULL ,
`user_create`  bigint(20) NULL ,
`timestamp`  timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP ,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `form_fields` (
`id`  bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
`form_id`  bigint(20) UNSIGNED NOT NULL ,
`field_name`  varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ,
`label`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`description`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`required`  tinyint(1) NULL DEFAULT NULL ,
`validate`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`filter`  tinyint(1) NULL DEFAULT 1 ,
`usage`  tinyint(1) NULL DEFAULT 1 ,
`time_create`  int(11) NULL ,
`time_update`  int(11) NULL ,
`user_id`  bigint(20) NULL ,
`user_create`  bigint(20) NULL ,
`timestamp`  timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP ,
PRIMARY KEY (`id`),
FOREIGN KEY (`form_id`) REFERENCES `forms` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
UNIQUE INDEX `element_name` USING BTREE (`field_name`, `usage`, `form_id`) ,
INDEX `field_name` USING BTREE (`field_name`) ,
INDEX `form_id` USING BTREE (`form_id`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `form_posts` (
`id`  bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
`form_id`  bigint(20) UNSIGNED NOT NULL ,
`ip`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`utm`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`refer`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`create_time`  bigint(20) NULL ,
`timestamp`  timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ,
PRIMARY KEY (`id`),
FOREIGN KEY (`form_id`) REFERENCES `forms` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
INDEX `form_post_ibfk_1` USING BTREE (`form_id`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `form_post_values` (
`id`  bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
`post_id`  bigint(20) UNSIGNED NULL ,
`field_id`  bigint(20) UNSIGNED NULL ,
`value`  text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`field_id`) REFERENCES `form_fields` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
FOREIGN KEY (`post_id`) REFERENCES `form_posts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
UNIQUE INDEX `post_id` USING BTREE (`post_id`, `field_id`) ,
INDEX `field_id` USING BTREE (`field_id`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8;





