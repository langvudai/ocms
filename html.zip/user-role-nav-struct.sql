CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(220) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `password` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `salt` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `actived` tinyint(1) unsigned DEFAULT 1,
  `last_access` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_time` int(10) unsigned DEFAULT NULL,
  `updated_time` int(10) unsigned DEFAULT NULL,
  `deleted_time` int(10) unsigned DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `users_username_unique` (`username`,`deleted_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `actived` tinyint(1) DEFAULT 1,
  `usage` tinyint(1) DEFAULT 1,
  `timestamp` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name_uk` (`name`,`usage`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) NOT NULL DEFAULT 0,
  `name` varchar(100) CHARACTER SET latin1 NOT NULL,
  `guard` varchar(20) CHARACTER SET latin1 NOT NULL,
  `path` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `description` text DEFAULT NULL,
  `usage` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`,`parent_id`,`usage`) USING BTREE,
  UNIQUE KEY `path` (`path`,`usage`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `navigations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `url` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `permission_id` int(10) unsigned DEFAULT NULL,
  `display` tinyint(1) DEFAULT 1,
  `icon` varchar(50) DEFAULT '',
  `order` int(10) DEFAULT 1,
  `usage` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`usage`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `user_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(21) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iplogin` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timelogin` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `user_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `role_uk` (`role_id`,`user_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  CONSTRAINT `fk_user_role_roles` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_user_role_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `profile_uk` (`user_id`,`name`) USING BTREE,
  CONSTRAINT `fk_profiles_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `permission_role` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `role_id` (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `permission_role_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `permission_role_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `user_group` (
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`),
  UNIQUE KEY `username_uk` (`group_id`) USING BTREE,
  CONSTRAINT `user_group_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_group_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
	 
INSERT INTO `users` VALUES ('1', 'admin', '8a7275e378aa320e1ff798010e929e946c93575d', 'b#{#wtaU-t{$-KHLz[}/', '1', null, null, null, null, null);
INSERT INTO `user_group` VALUES ('1', '1');
INSERT INTO `roles` VALUES ('1', 'administrator', 'administrator', '1', '1', null);
INSERT INTO `permissions` VALUES ('1', '0', 'dashboard', 'mod', 'dashboard/', null, '1');
INSERT INTO `permissions` VALUES ('2', '0', 'user', 'mod', 'user/', null, '1');
INSERT INTO `permissions` VALUES ('3', '0', 'user_history', 'mod', 'user/history/', null, '1');
INSERT INTO `permissions` VALUES ('4', '0', 'role', 'mod', 'role/', null, '1');
INSERT INTO `permissions` VALUES ('5', '1', 'all', 'act', null, null, 1);
INSERT INTO `permissions` VALUES ('6', '2', 'add', 'act', null, null, 1);
INSERT INTO `permissions` VALUES ('7', '2', 'edit', 'act', null, null, 1);
INSERT INTO `permissions` VALUES ('8', '2', 'del', 'act', null, null, 1);
INSERT INTO `permissions` VALUES ('9', '3', 'del', 'act', null, null, 1);
INSERT INTO `permissions` VALUES ('10', '4', 'add', 'act', null, null, 1);
INSERT INTO `permissions` VALUES ('11', '4', 'edit', 'act', null, null, 1);
INSERT INTO `permissions` VALUES ('12', '4', 'del', 'act', null, null, 1);
INSERT INTO `navigations` VALUES ('1', '0', 'Dashboard', '#dashboard', 'dashboard', '1', '1', null, '1', '1');
INSERT INTO `navigations` VALUES ('2', '0', 'Chung', '', null, null, '1', 'globe', '1', '1');
INSERT INTO `navigations` VALUES ('3', '2', 'Quản lý tài khoản', '#user', 'user', '2', '1', 'user', '1', '1');
INSERT INTO `navigations` VALUES ('4', '2', 'Lịch sử đăng nhập', '#user/history', 'user_history', '3', '1', 'history', '1', '1');
INSERT INTO `navigations` VALUES ('5', '2', 'Role', '#role', 'role', '4', '1', 'users', '1', '1');
INSERT INTO `user_role` VALUES ('1', '1', '1');
INSERT INTO `permission_role` VALUES ('1', '1');
INSERT INTO `permission_role` VALUES ('1', '2');
INSERT INTO `permission_role` VALUES ('1', '3');
INSERT INTO `permission_role` VALUES ('1', '4');