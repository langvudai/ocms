<?php 
use Htlib\Mvc\View;
use Htlib\Gf;

/**
 * landing page mangaer
 */
class Page extends AdminController
{
	
	function index()
	{
		Gf::urlMatch('/dir/module/action/pagename');
		$navChild = array('name'=>'Page', 'list'=>array());
		Gf::args('pagename')=='about' ? array_push($navChild['list'], array(
			'url'=>Gf::url(array('action'=>'builder', 'pagename'=>'about')), 
			'text'=>'Gioi thieu',
			'active'=>1
		)):array_push($navChild['list'], array(
			'url'=>Gf::url(array('action'=>'builder', 'pagename'=>'about')), 
			'text'=>'Gioi thieu'
		));
		Gf::args('pagename')=='contact' ? array_push($navChild['list'], array(
			'url'=>Gf::url(array('action'=>'builder', 'pagename'=>'contact')), 
			'text'=>'Lien he',
			'active'=>1
		)):array_push($navChild['list'], array(
			'url'=>Gf::url(array('action'=>'builder', 'pagename'=>'contact')), 
			'text'=>'Lien he'
		));
		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
			return $this->viewJson(array(
				'breadcrumb' => array(
		            array('mod'=>'dashboard', 'text'=>''),
		            array('text'=>'Page'),
		        ),
		        'navChild'=>$navChild
			));
		    // return $this->viewJson();
		}
		if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
		    return new View('');
		}
		return new View('layouts/admin');
	}

	private function builder()
	{
		return $this->viewJson(array(
			'breadcrumb' => array(
	            array('mod'=>'dashboard', 'text'=>''),
	            array('mod'=>'page', 'text'=>'Page'),
	            array('text'=>'Builder'),
	        ),
		));
	}

	function set()
	{
		return $this->viewJson(array(
			'breadcrumb' => array(
	            array('mod'=>'dashboard', 'text'=>''),
	            array('mod'=>'page', 'text'=>'Page'),
	            array('mod'=>'page', 'act'=>'index', 'text'=>'Builder'),
	            array('text'=>'Setting'),
	        ),
		));
	}
}