<?php 
use Htlib\Mvc\View;
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;

/**
 * 
 */
class Upload extends AdminController
{
	function init()
	{
		/*echo $this->_module;
		parent::init();*/
		if (in_array($this->_action, array('summernote'))) {
			//return true;
		} /*else {
			return parent::init();
		}*/
	}
	function index()
	{

	}
	function image()
	{
		if ($this->views->allow_add||$this->views->allow_edit) {
			$file = array_shift($_FILES);
			$type = $file['type'];
			if (in_array($type, array('image/jpeg', 'image/png', 'image/jpg', 'image/gif'))) {
				$cfg = new Configuration();
				$request = $this->_post();
				/*$folderUpload = $cfg->upload['dir'];*/
				$dir = $request->dir;
				$month = date('m-Y');
				$day = date('d');
				$path = $cfg->upload['dir'].'/'.$dir;
				is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
				$path.= '/'.$month;
				is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
				$path.= '/'.$day;
				is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
				$info = pathinfo($file['name']);
				$filename = $info['filename'].'-'.time().'.'.$info['extension'];
				$result = move_uploaded_file($file["tmp_name"], $path.'/'.$filename);
				if ($result) {
					$this->printJson((object)array(
						'status' => 1,
						'filename'=>$dir.'/'.$month.'/'.$day.'/'.$filename,
						'src' => $cfg->upload['url'].'/'.$dir.'/'.$month.'/'.$day.'/'.$filename,
						'message' => Gf::L('upload image success'),
					));
				}
			}
		}
	}
	function POST_summernote()
	{
		if ($this->views->allow_add||$this->views->allow_edit) {
			$file = array_shift($_FILES);
			$type = $file['type'];
			if (in_array($type, array('image/jpeg', 'image/png', 'image/jpg', 'image/gif'))) {
				$cfg = new Configuration();
				$request = $this->_post();
				/*$folderUpload = $cfg->upload['dir'];*/
				$dir = 'files';
				$month = date('m-Y');
				$day = date('d');
				$path = $cfg->upload['dir'].'/'.$dir;
				is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
				$path.= '/'.$month;
				is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
				$path.= '/'.$day;
				is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
				$info = pathinfo($file['name']);
				$filename = $info['filename'].'-'.time().'.'.$info['extension'];
				$result = move_uploaded_file($file["tmp_name"], $path.'/'.$filename);
				if ($result) {
					$this->printJson((object)array(
						'status' => 1,
						'filename'=>$dir.'/'.$month.'/'.$day.'/'.$filename,
						'src' => $cfg->upload['url'].'/'.$dir.'/'.$month.'/'.$day.'/'.$filename,
						'message' => Gf::L('upload image success'),
					));
				}
			}
		}
		exit();
	}
	function summernote() {return new View('layouts/summernote');}
	function summernotequick()
	{
		// if ($this->views->allow_add||$this->views->allow_edit) {
		// 	$file = array_shift($_FILES);
		// 	$type = $file['type'];
		// 	if (in_array($type, array('image/jpeg', 'image/png', 'image/jpg', 'image/gif'))) {
		// 		$cfg = new Configuration();
		// 		$request = $this->_post();
		// 		/*$folderUpload = $cfg->upload['dir'];*/
		// 		$dir = 'files';
		// 		$month = date('m-Y');
		// 		$day = date('d');
		// 		$path = $cfg->upload['dir'].'/'.$dir;
		// 		is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
		// 		$path.= '/'.$month;
		// 		is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
		// 		$path.= '/'.$day;
		// 		is_dir($path) ? @chmod($path, 0775) : @mkdir($path, 0775);
		// 		$info = pathinfo($file['name']);
		// 		$filename = $info['filename'].'-'.time().'.'.$info['extension'];
		// 		$result = move_uploaded_file($file["tmp_name"], $path.'/'.$filename);
		// 		if ($result) {
		// 			$this->printJson((object)array('status'=>1, 'src'=>$cfg->upload['url'].'/'.$dir.'/'.$month.'/'.$day.'/'.$filename));
		// 		}
		// 	}
		// }
		// return false;
		//return new View('layouts/summernote');
	}
}