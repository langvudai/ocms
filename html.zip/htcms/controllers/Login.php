<?php 
use Htlib\Mvc\Controller;
use Htlib\Mvc\View;
//use Htlib\Mvc\Role;
use Htlib\Gf;
use Htlib\Log;
use Htlib\Configuration;
use Htlib\Session;
use Model\User;
/*use Model\Permission;*/

class Login extends Controller
{
    private $timeLineRSPWD = 1000;
    function __construct($argument)
    {
        parent::__construct($argument);
        /*if (!in_array($this->_action, array('logout')) && !method_exists($this, $this->_action.'_action')) {
            //$this->_action = '';
        }*/
        Gf::urlMatch('/dir/module/action');
    }

    function googleoauth()
    {
        /*$client = new \Google_Client();
        $cfg = new Configuration();
        $cfg = $cfg->google_plus;
        $client->setClientId($cfg['client_id']);
        $client->setClientSecret($cfg['client_secret']);
        $client->setRedirectUri($cfg['redirect_uri']);
        $client->setScopes(array('https://www.googleapis.com/auth/userinfo.email', 'https://www.googleapis.com/auth/userinfo.profile'));
        if(!empty($_GET['code']))
        {
            try
            {
                $client->authenticate($_GET['code']);
                $googleService = new \Google_Service_Oauth2($client);
                $userinfo = $googleService->userinfo->get();
                $USER = new User();
                if($id = $USER->confirmEmail($userinfo->email))
                {
                    Session::set('user_id', $id);
                    Session::set('g+', $id);
                    $info = $USER->info($id);
                    Session::set('user_role', $info->role_name);
                    Session::set('display_name', $info->fullname ? $info->fullname : $info->username);
                    $USER->addLog($info->username);
                    header('location: /'.$this->moduleDir.'/');
                }
                else
                {
                    header('location: '.Gf::url(array('action'=>'-', 'email'=>'-1'))); 
                }
            }
            catch(Exception $e)
            {
                header('location: '.Gf::url(array('action'=>'-'))); 
            }
            
        }
        else
        {
            $authUrl = $client->createAuthUrl();
            if ($this->request_POST()) {
                header('location: '.$authUrl);
            } else {
                echo $authUrl;
            }
        }
        return false;*/
    }

    function facebookoauth()
    {
        /* v2.9 */
        /*$cfg = new Configuration();
        $fb_cfg = $cfg->facebook;
        if (empty($_GET['access_token']) && empty($_GET['code'])) {
            $url_redirect = 'https://www.facebook.com/v2.9/dialog/oauth?client_id='.$fb_cfg['client_id'].'&redirect_uri='.$fb_cfg['redirect_uri'].'&response_type=token&scopes=email';
            $state = uniqid();
            $url_redirect .= '&state='.$state;
            echo($url_redirect);
            //header('location:'.$url_redirect);
        } else {
            $code = $_GET['code'];
            $access_token = $_GET['access_token'];
            $url = 'https://graph.facebook.com/v2.9/me/?fields=email&access_token='.$access_token;
            $json_str = file_get_contents($url);
            if ($object = json_decode($json_str)) {
                print_r($object);
            }
        }
        exit();*/
    }

    function index()
    {
        if (Session::get('user_id')) {
            header('location: /'.$this->_moduleDir.'/');
            exit();
        }
        $cfg = new Configuration();
        $USER = new User();
        $data = array();
        $data['title'] = 'Login';
        $data['actionUrl'] = Gf::url(array('action' => 'index'));
        if ($this->request_POST()=='$checklogin') {
            // exit('jhhkhkjhjkh');
            $request = $this->_post();
            if ($id = $USER->confirmUserPass($request->username, $request->password)) {
                Session::set('user_id', $id);
                $USER->addLog($request->username);
                header('location: /'.$this->_moduleDir.'/');
                exit();
                /*$info = $USER->info($id);
                $p = new Permission();
                $data['status'] = 1;
                $data['message'] = '';
                $data['userId'] = $id;
                $data['navigation'] = $p->getNav();
                $data['displayname'] = $info->fullname;*/
            } else {
                $USER->addLog($request->username, $request->password);
                Session::destroy();
                $data['status'] = 0;
                $data['message'] = '';
                $data['error'] = 'fail';
            }
        }
        if ($cfg->admin_restore_password) {
            $data['adminRestorePassword'] = $cfg->admin_restore_password;
            $data['urlRestorePassword'] = Gf::url(array('action' => 'forgotpassword'));
        }
        $data['thisUrl'] = 'http'.(@$_SERVER['HTTPS']=='on'?'s':'').'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        // if (@file_get_contents('https://www.google.com/images/nav_logo225.png')) {
        //     $data['loginGoogle'] = Gf::url(array('action'=>'googleoauth'));
        // }
        // exit('888888888888');
        return new View('login/index', $data);
    }

    function forgotpassword()
    {
        $cfg = new Configuration();
        $USER = new User();
        if ($this->request_POST()=='$FORGOTPWD') {
            if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) && $cfg->admin_restore_password==$_POST['email']) {
                $a = explode('@', $_POST['email']);
                $b = md5($a[1]);
                preg_match('/^([\d]*\D+\d)?(.*)$/', $b, $m);
                $time = dechex(time());
                $len = strlen($time);
                if ($id = $USER->confirmEmail($cfg->admin_restore_password)) {
                    if ($token = $USER->createDToken($id)) {
                        @$code = urlencode($token.'-'.$m[1].($len<10?'0':'').$len.$time.$m[2]);
                        $url = 'http'.(isset($_SERVER['HTTPS'])&&($_SERVER['HTTPS']=='on')?'s':'').'://'.$_SERVER['HTTP_HOST']. Gf::url(array('code'=>$code));
                        if ($code) {
                            ob_start();
                            $mail = new PHPMailer();
                            $mail->charSet = "UTF-8";
                            $mail->IsSMTP();
                            $mail->SMTPDebug  = 2;
                            $mail->Debugoutput = "html";
                            $mail->Host       = $cfg->PHPMailer['host'];
                            $mail->Port       = $cfg->PHPMailer['port'];
                            $mail->SMTPSecure = $cfg->PHPMailer['SMTPSecure'];
                            $mail->SMTPAuth   = true;
                            $mail->Username   = $cfg->PHPMailer['username'];
                            $mail->Password   = $cfg->PHPMailer['password'];
                            $mail->SetFrom($cfg->PHPMailer['emailFrom'], '');
                            $mail->AddAddress($cfg->admin_restore_password, '');
                            $mail->Subject = '[No-reply] - Reset password '.@$_SERVER['HTTP_HOST'];
                            $mail->MsgHTML('<a href="'.$url.'">'.$url.'</a>. <p>This link is valid for '.floor($this->timeLineRSPWD/60).' minutes</p>');
                            if($mail->Send()) {
                                $this->printJson(array(
                                    'status'  => 1, 
                                    'message' => Gf::L('An email has been sent to your email'),
                                ));
                            } else {
                                
                            }
                        }
                    }
                }               
            } else {
            }
        } elseif (filter_var($cfg->admin_restore_password, FILTER_VALIDATE_EMAIL) && Gf::args('code')) {
            $a = explode('@', $cfg->admin_restore_password);
            $b = @md5($a[1]);
            preg_match('/^([\d]*\D+\d)?(.*)$/', $b, $m);
            $a = Gf::args('code');
            $a = explode('-', $a);
            $token = $a[0];
            $a = $a[1];
            $a = substr($a, strlen($m[1]));
            $len = (int)substr($a, 0, 2);
            $time = hexdec(substr($a, 2, $len)) + $this->timeLineRSPWD;
            if (substr($a, 2 + $len) == $m[2] && $time > time()) {
                if ($a = $USER->resetPassword($token)) {
                    echo Gf::L('Username:').$a['username'].' '.Gf::L('Password:').$a['password'];
                }
            }
        }
    }
    
    function POST_checkpassword()
    {
        $this->request_POST();
        $USER = new User();
        //if ($this->request_POST()) 
        {
            $request = $this->_post();
            /*$request = (object)array('username'=>"admin",'password'=>"admin");*/
            if ($id = $USER->confirmUserPass($request->username, $request->password)) {
                Session::set('user_id', $id);
                $USER->addLog($request->username);
                $info = $USER->info($id);
                /*$p = new Permission();*/
                $this->printJson(array(
                                    'status' => 1,
                                    'message'=> '',
                                    'userId'=> $id,
                                    /*'navigation'=> $p->getNav(),*/
                                    'redirect'=>Gf::url(array('module'=>'', 'action'=>''), 1),
                                    'displayname' => $info->fullname,
                                ));
            } else {
                $USER->addLog($request->username, $request->password);
                Session::destroy();
                $this->printJson(array(
                                    'status' => 0,
                                    'message'=> '',
                                    'error' => 'fail',
                                    'msg' => $USER->error
                                ));
            }
        }
        $this->printJson('');
    }

    function logout()
    {
        //$this->view->headerJson();
        Session::destroy();
        $this->redirect('');
        $this->printJson(array(
            'status' => 1,
        ));
    }

    function GET_getpassword()
    {
        $USER = new User();
        if (Gf::args('password')) {
            $password = Gf::args('password');
        } else {
            $a = array_merge(range(1, 9), range('a', 'z'), range('A', 'Z'));
            shuffle($a);
            $password = implode('', array_slice($a, 5, 8));
        }
        $confirm = $USER->generatorSalt();
        $passwordEn = $USER->getPassword($password, $confirm);
        View::headerText();
        echo $password.PHP_EOL.$confirm.PHP_EOL.$passwordEn;
        exit();
    }
}