<?php 
use Htlib\Mvc\View;
use Htlib\Mvc\Controller;
use Htlib\Db\Expr;
use Model\User;
use Model\Permission;
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;

/**
* 
*/
class Index extends AdminController
{
	function _index()
	{
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson();
        }
        return $this->view('dashboard/index');
        /*if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
            return new View('dashboard/index');
        }
        return new View('layouts/admin');*/
	}

    function template($argument)
    {
        @$mod = $argument['mod']; 
        @$act = $argument['act']; 
        $user_id = (int)Session::get('user_id');
        if ($user_id) {
            $conf = new Configuration();
            $user = new User();
            $user->update(array('last_access'=>$this->_module.'/'.$this->_action), 'id='.$user_id);
            $this->addView('user_id', $user_id);
            $this->addView('user', $user->info($user_id));
            $this->addView('last_access', $this->_module.'/'.$this->_action);
            $this->addView('issa', $user_id==1 ? 1:0);
            if (empty($mod) && empty($act)) {
                return new View('layouts/layout');
            } else {
                $path = empty($act)||preg_match('/^(all|add|edit|del|index)$/i', $act, $matches) ? "$mod/":"$mod/$act/";
                if ($user_id==1) {
                    $this->addView('allow_add', 1);
                    $this->addView('allow_edit', 1);
                    $this->addView('allow_del', 1);
                } else {
                    $query_act = $user->select('name, parent_id', 'permissions')
                    ->innerJoin('permission_role', 'permissions.id=permission_role.permission_id', 'role_id');
                    $query = $user->select('id, name, path', 'permissions p')
                    ->innerJoin('permission_role pr', 'p.id=pr.permission_id')
                    ->innerJoin('user_role ur', 'pr.role_id=ur.role_id')
                    ->innerJoin('roles r', 'r.id=ur.role_id')
                    ->leftJoin(array('b'=> $query_act), 'b.parent_id=p.id AND b.role_id=ur.role_id', array('act'=>new Expr('GROUP_CONCAT','b.name')))
                    ->where('p.path=', $path)
                    ->where('ur.user_id=', $user_id)
                    ->group('p.id'); 
                    $per = $query->fetchRow(); 
                    empty($per) && exit();
                    $this->addView('permission', empty($per['act'])?'':$per['act']);
                    $a = explode(',', @$per['act']);
                    empty($matches[1]) || in_array('all', $a) || in_array($matches[1], $a) || exit();
                    $this->addView('allow_add', in_array('all', $a) || in_array('add', $a));
                    $this->addView('allow_edit', in_array('all', $a) || in_array('edit', $a));
                    $this->addView('allow_del', in_array('all', $a) || in_array('del', $a));
                }

                $this->addView('actionUrl', str_ireplace('index/index/', '', $_SERVER['REQUEST_URI']));
                /*if (!empty($conf->modConfig->disableFeild) && $conf->modConfig->disableFeild) {
                    $this->addView('disable', (object)array_fill_keys(array_values($conf->modConfig->disableFeild), 1));
                } else {
                    $this->addView('disable', new stdClass());
                }*/
                $view_path = empty($act) ? ($mod.'/index') : ($mod.'/'.$act);
                @$route = include $conf->config_route_path;
                if (is_array($route)) {
                    $route = empty($act)||in_array($act, array('index', '-'))||!isset($route[$mod.'/'.$act]) ? (isset($route[$mod]) ? $route[$mod] : NULL) : (isset($route[$mod.'/'.$act]) ? $route[$mod.'/'.$act] : NULL);
                    if (is_array($route)) {
                        $x = strtolower(key($route));
                        $x = explode('::', $x);
                        $view_path = empty($x[1]) ? (empty($act) ? ($x[0].'/index') : ($x[0].'/'.$act)) : ($x[0].'/'.$x[1]);
                        $setting = array_shift($route);
                        if (isset($setting['label']) && is_array($setting['label'])) {
                            isset($conf->lang) ? View::setLang(key($conf->lang), $setting['label']) : View::setLang('', $setting['label']);
                            unset($setting['label']);
                        }
                        foreach ($setting as $key => $value) {
                            is_scalar($value) ? $this->addView($key, $value) : $this->addView($key, (object)$value);
                        }
                    }

                    // $value = $route[$mod];
                    // if (is_array($value)) {
                    //     $value = key($value);
                    // }
                    // $value = explode('::', $value);
                    // $mod = strtolower($value[0]);
                    // if (@$value[1]) {
                    //     $act = strtolower($value[1]);
                    // }
                }
                //echo($view_path);exit();
                $this->addView('uploadDir', $conf->upload['dir']);
                $this->addView('uploadUrl', $conf->upload['url']);
                return new View($view_path);
            }
        } else {
            return new View('layouts/layout');
        }
    }

    function POST_navigation()
    {
        $user_id = (int)Session::get('user_id');
        $is_post = $this->request_POST();
        if ($user_id!=1 || empty($is_post)) {
            $this->printJson(array('status'=>0, 'message'=>'Not permission or logout'));
            exit();
        }
        $db = new \Htlib\Db\DbTable();
        $status = 0;
        if ($is_post=='$DELETE') {
            $result = $db->update('navigations', array('usage'=>(object)'NULL'), 'id='.Gf::request()->id);
            if ($result) {
                $status = 1;
                $message = Gf::L('Navigation is deleted');
            } else {
                $message = $db->error();
            }
        } elseif ($is_post) {
            $data = array(
                'parent_id' => Gf::request()->parent_id,
                'title' => Gf::request()->title,
                'url' => Gf::request()->url,
                'permission_id' => Gf::request()->permission_id,
                'display' => Gf::request()->display,
                'icon' => Gf::request()->icon,
                'order' => Gf::request()->order,
            );
            if (Gf::request()->name && $is_post=='$ADD') {
                $data['name'] = Gf::request()->name;
            }
            if ($is_post=='$ADD') {
                $db->insert('navigations', $data);
                if ($db->lastId()) {
                    $status = 1;
                    $message = Gf::L('Addnew success');
                } else {
                    $message = $db->error();
                }
            } elseif ($is_post=='$EDIT') {
                $data['display'] = (int)$data['display'];
                $result = $db->update('navigations', $data, 'id='.Gf::request()->id);
                if ($result) {
                    $status = 1;
                    $message = Gf::L('Edit success');
                } else {
                    $message = $db->error();
                }
            }
        }
        if ($status>0) {
            $query = $db->select('*', 'navigations nav')
                ->leftJoin('permissions per', 'nav.permission_id=per.id', array('permission'=>'name', 'path'))
                ->order('parent_id, nav.order, nav.id')
                ->where(not_null('nav.usage'));
            
            $query = $query->fetch('parent_id', true);
            $rows = array();
            if (isset($query[0]) && is_array($query[0])) {
                foreach ($query[0] as $value) {
                    $o = (object)$value;
                    if (empty($value['icon'])) {
                        unset($o->icon);
                    }
                    if (isset($query[$value['id']]) && is_array($query[$value['id']])) {
                        $o->childs = array();
                        $o->treecount = 0;
                        foreach ($query[$value['id']] as $child) {
                            $o_child = (object)$child;
                            if (empty($child['icon'])) {
                                unset($o_child->icon);
                            }
                            if ($o_child->display) {
                                $o->treecount++;
                            }
                            if (isset($query[$child['id']]) && is_array($query[$child['id']])) {
                                $o_child->childs = array();
                                foreach ($query[$child['id']] as $v) {
                                    $o_child->childs[] = (object)$v;
                                    if (@$v['display']) {
                                        $o->treecount++;
                                    }
                                }
                            }
                            $o->childs[] = $o_child;
                        }
                    }
                    $rows[] = $o;
                }
            }
        }
        $this->printJson(compact('status', 'message', 'rows'));
    }

    function navigation()
    {
        $user_id = (int)Session::get('user_id');
        if ($user_id!=1) {
            header('location: /'.$this->_moduleDir.'/');
            exit();
        }
        $user = new User();
        $user->update(array('last_access'=>$this->_module.'/'.$this->_action), 'id='.$user_id);
        $query = $user->select('*', 'navigations nav')
            ->leftJoin('permissions per', 'nav.permission_id=per.id', array('permission'=>'name', 'path'))
            ->order('parent_id, nav.order, nav.id')
            ->where(not_null('nav.usage'));
        /*echo  $query;exit();*/
        $query = $query->fetch('parent_id', true);
        $nav = array();
        if (isset($query[0]) && is_array($query[0])) {
            foreach ($query[0] as $value) {
                $o = (object)$value;
                if (empty($value['icon'])) {
                    unset($o->icon);
                }
                if (isset($query[$value['id']]) && is_array($query[$value['id']])) {
                    $o->childs = array();
                    $o->treecount = 0;
                    foreach ($query[$value['id']] as $child) {
                        $o_child = (object)$child;
                        if (empty($child['icon'])) {
                            unset($o_child->icon);
                        }
                        if ($o_child->display) {
                            $o->treecount++;
                        }
                        if (isset($query[$child['id']]) && is_array($query[$child['id']])) {
                            $o_child->childs = array();
                            foreach ($query[$child['id']] as $v) {
                                $o_child->childs[] = (object)$v;
                                if (@$v['display']) {
                                    $o->treecount++;
                                }
                            }
                        }
                        $o->childs[] = $o_child;
                    }
                }
                $nav[] = $o;
            }
        }
        
        $query = $user->select('name, id, parent_id, path', 'permissions')
        ->where('guard IN (\'mod\', \'act\')')
        ->where(not_null('usage'))
        ->order('parent_id, name')
        ->fetch('parent_id', true)
        ;
        $permissions = array();
        $paths = array();
        if (isset($query[0]) && is_array($query[0])) {
            foreach ($query[0] as $value) {
                if (isset($query[$value['id']]) && is_array($query[$value['id']])) {
                    $value['childs'] = array();
                    foreach ($query[$value['id']] as $v) {
                        array_push($value['childs'], array('id'=>$v['id'], 'childname'=>$v['name']));
                        $paths[$v['id']] = $value['path'];
                    }
                }
                $paths[$value['id']] = $value['path'];
                array_push($permissions, $value);
            }
        }
        
        return new View('layouts/navigation', array(
            'nav' => json_encode($nav), 
            'permissions'=>json_encode($permissions),
            'paths'=> json_encode($paths),
            'user_id'=> $user_id,
            'user'=> $user->info($user_id),
            'last_access'=>$this->_module.'/'.$this->_action,
            'issa'=>1
        ));
    }

    function POST_permission()
    {
        $user_id = (int)Session::get('user_id');
        $is_post = $this->request_POST();
        $request = $this->_post();
        if ($user_id!=1 || empty($is_post)) {
            $this->printJson(array('status'=>0, 'message'=>'Not permission or logout'));
            exit();
        }
        $status = 0;
        if ($is_post=='$ADD') {
            $permission = new Permission();
            if ($permission->insert(array(
                'parent_id' => 0,
                'name' => $request->name,
                'guard' => 'mod',
                'path' => $request->path,
                'description' => $request->description,
            ))) {
                $id = $permission->lastId();
                if ($id) {
                    if (is_scalar($request->act)) {
                        $permission->insert(array('parent_id' => $id, 'name' => $request->act, 'guard' => 'act'));
                    } elseif (is_array($request->act)) {
                        foreach ($request->act as $act) {
                            $permission->insert(array('parent_id' => $id, 'name' => $act, 'guard' => 'act'));
                        }
                    }
                    $query = $permission->select('name, id, parent_id, path, description', 'permissions')
                    ->where('guard IN (\'mod\', \'act\')')
                    ->where(not_null('usage'))
                    ->where('id='.$id.' OR parent_id='.$id)
                    ->order('parent_id, id')
                    ->fetch('parent_id', true)
                    ;
                    if (is_array($query[0][0]) && isset($query[$id]) && is_array($query[$id])) {
                        $per = $query[0][0];
                        $per['actions'] = array();
                        foreach ($query[$id] as $v) {
                            array_push($per['actions'], array('id'=>$v['id'], 'act'=>$v['name']));
                        }
                    }
                    $this->printJson(array('status'=>1, 'message'=>Gf::L('Add permission success'), 'add'=>$per ));
                } else {
                    $this->printJson(array('status'=>0, 'message'=>$permission->error()));
                }
            } else {
                $this->printJson(array('status'=>0, 'message'=>$permission->error()));
            }
        }
        if ($is_post=='$EDIT') {
            $permission = new Permission();
            $id = $request->id;
            if ($permission->update(array(
                'name' => $request->name,
                'guard' => 'mod',
                'path' => $request->path,
                'description' => $request->description,
            ), 'id='.$id)) {
                $permission->delete('permission_role', 'permission_id IN (SELECT  id FROM permissions WHERE parent_id='.$id.')');
                $permission->delete('guard= \'act\' AND parent_id='.$id);
                if (is_scalar($request->act)) {
                    $permission->insert(array('parent_id' => $id, 'name' => $request->act, 'guard' => 'act'));
                } elseif (is_array($request->act)) {
                    foreach ($request->act as $act) {
                        $permission->insert(array('parent_id' => $id, 'name' => $act, 'guard' => 'act'));
                    }
                }
                $query = $permission->select('name, id, parent_id, path, description', 'permissions')
                ->where('guard IN (\'mod\', \'act\')')
                ->where(not_null('usage'))
                ->where('id='.$id.' OR parent_id='.$id)
                ->order('parent_id, id')
                ->fetch('parent_id', true)
                ;
                if (is_array($query[0][0]) && isset($query[$id]) && is_array($query[$id])) {
                    $per = $query[0][0];
                    $per['actions'] = array();
                    foreach ($query[$id] as $v) {
                        array_push($per['actions'], array('id'=>$v['id'], 'act'=>$v['name']));
                    }
                }

                $this->printJson(array('status'=>1, 'message'=>Gf::L('Edit permission success'), 'edit'=>$per ));
            } else {
                $this->printJson(array('status'=>0, 'message'=>$permission->error()));
            }
        }
        if ($is_post=='$DELETE') {
            $permission = new Permission();
            if ($permission->update(array('usage'=>new Expr('NULL')), 'id='.$request->id)) {
                $this->printJson(array('status'=>1, 'message'=>Gf::L('Delete permission success'), 'delid'=>$request->id));
            } else {
                $this->printJson(array('status'=>0, 'message'=>$permission->error()));
            }
        }
    }

    function permission()
    {
        $user_id = (int)Session::get('user_id');
        if ($user_id!=1) {
            header('location: /'.$this->_moduleDir.'/');
            exit();
        }
        $user = new User();
        $user->update(array('last_access'=>$this->_module.'/'.$this->_action), 'id='.$user_id);
        $query = $user->select('id, parent_id, title, url, display, icon', 'navigations')
        ->order('parent_id, order, id')
        ->where(not_null('display'))
        ->where(not_null('usage'));
        
        $query = $query->fetch('parent_id', true);
        $nav = array();
        if (isset($query[0]) && is_array($query[0])) {
            foreach ($query[0] as $value) {
                $o = (object)$value;
                if (empty($value['icon'])) {
                    unset($o->icon);
                }
                if (isset($query[$value['id']]) && is_array($query[$value['id']])) {
                    $o->childs = array();
                    $o->treecount = count($query[$value['id']]);
                    foreach ($query[$value['id']] as $child) {
                        $o_child = (object)$child;
                        if (empty($child['icon'])) {
                            unset($o_child->icon);
                        }
                        if (isset($query[$child['id']]) && is_array($query[$child['id']])) {
                            $o_child->childs = array();
                            $o->treecount += count($query[$child['id']]);
                            foreach ($query[$child['id']] as $v) {
                                array_push($o_child->childs, (object)$v);
                            }
                        }
                        array_push($o->childs, $o_child);
                    }
                }
                array_push($nav, $o);
            }
        }

        $query = $user->select('name, id, parent_id, path, description', 'permissions')
        ->where('guard IN (\'mod\', \'act\')')
        ->where(not_null('usage'))
        ->order('parent_id, id')
        ->fetch('parent_id', true)
        ;
        $permissions = array();
        if (isset($query[0]) && is_array($query[0])) {
            foreach ($query[0] as $value) {
                if (isset($query[$value['id']]) && is_array($query[$value['id']])) {
                    $value['actions'] = array();
                    foreach ($query[$value['id']] as $v) {
                        array_push($value['actions'], array('id'=>$v['id'], 'act'=>$v['name']));
                    }
                }
                array_push($permissions, $value);
            }
        }

        $listpath = array();
        $d = dir(__DIR__);
        while (false !== ($entry = $d->read())) {
            if (preg_match('/^([A-Z]\w*)\.php$/', $entry, $m) && $m[1]!='Index') {
                $c = file_get_contents(__DIR__.'/'.$entry);
                preg_match_all('/\n[\s\t]*(public)?[\s\t]*function\s(([A-Z]+_)?[a-z][Z-Za-z0-9]*)/', $c, $matches);
                $f = preg_grep('/^(([A-Z]+_)?(init|index|add|edit|del))|(([A-Z]+_).+)$/', $matches[2], PREG_GREP_INVERT);
                $listpath[strtolower($m[1])] = array_values($f);
            };
        }
        $array = include Configuration::getConfig_route_path();
        if (!empty($array)&&is_array($array)) {
            $listpath['/'] = preg_grep('/^[a-z]/', array_keys($array));
        }
        ksort($listpath);
        return new View('layouts/permission', array(
            'nav' => json_encode($nav), 
            'permissions'=>json_encode($permissions),
            'user_id'=> $user_id,
            'user'=> $user->info($user_id),
            'last_access'=>$this->_module.'/'.$this->_action,
            'listpath'=>json_encode($listpath),
            'issa'=>2
        ));
    }

    function navbar()
    {
        $user_id = (int)Session::get('user_id');
        $user = new User();
        $query = $user->select('id, parent_id, name, url, icon, permission_id, title', 'navigations')
            ->where(not_null('usage'))
            ->where('parent_id>0')
            ->where('display>0')
            ->order('order, id')
            ;
        $root = $user->select('id, parent_id, name, url, icon, permission_id, title', 'navigations n')
            ->leftJoin('permissions p', 'permission_id=p.id', array('pname'=>'name'))
            ->where(not_null('n.usage'))
            ->where('n.parent_id=0')
            ->where('n.display>0')
            ->order('n.order, n.id')
            ;
        // d($root);
        
        if ($user_id>1) {
            $permission = $user->select('permission_id', 'permission_role pr')->distinct()
                ->innerJoin('permissions p', 'p.id=pr.permission_id')
                ->innerJoin('user_role ur', 'pr.role_id=ur.role_id')
                ->innerJoin('users u', 'u.id=ur.user_id')
                ->where(not_null('u.usage'))
                ->where(not_null('p.usage'))
                ->where('u.id=', $user_id)
                ;
            $permission = $permission->fetchOnce('permission_id');
            $query->where('permission_id IN ('.implode(', ', $permission).')');
            $query = $query->fetch('parent_id', true);
            $root->where('permission_id IN ('.implode(', ', $permission).') OR n.id IN ('.implode(', ', is_array($query)?array_keys($query):array(0)).')');
            // d($root);
            $root = $root->fetch();
        } else {
            $root = $root->fetch();
            $query = $query->fetch('parent_id', true);
        }
        $nav = array();
        $path = preg_match('/^(all|add|edit|del|index)?$/i', Gf::args('act'), $matches) ? Gf::args('mod'):(Gf::args('mod').'/'.Gf::args('act'));
        if (!empty($root) && is_array($root)) {
            foreach ($root as $value) {
                $o = (object)array('text' => Gf::L($value['title']), 'name' => $value['name'], 'url' => $value['url'], 'pname'=>$value['pname']);
                if ($value['icon']) {
                    $o->icon = $value['icon'];
                }
                $l0e = false;
                if (isset($query[$value['id']]) && is_array($query[$value['id']])) {
                    $o->childs = array();
                    $o->treecount = 0;
                    foreach ($query[$value['id']] as $child) {
                        $o->treecount ++;
                        $o_child = (object)array('text' => Gf::L($child['title']), 'name' => $child['name'], 'url' => $child['url'], 'active'=>$child['url']==$path ? 'class=active' : '');
                        if ($child['icon']) {
                            $o_child->icon = $child['icon'];
                        }
                        if ($child['url']==$path) {
                            $l0e = $l0e || true;
                        }
                        if (isset($query[$child['id']]) && is_array($query[$child['id']])) {
                            $o_child->childs = array();
                            foreach ($query[$child['id']] as $v) {
                                $o->treecount ++;
                                array_push($o_child->childs, (object)array('text' => Gf::L($v['title']), 'name' => $v['name'], 'url' => $v['url'], 'active'=>$v['url']==$path ? 'class=active' : ''));
                                if ($v['url']==$path) {
                                    $l0e = $l0e || true;
                                }
                            }
                        }
                        array_push($o->childs, $o_child);
                    }
                } else {
                    if ($value['url']==$path) {
                        $l0e = $l0e || true;
                    }
                }
                $o->rootexpand = $l0e ? '1' : '';
                array_push($nav, $o);
            }
        }
        $this->printJson((object)array('status'=>1, 'data'=>$nav));
    }

    function POST_createurl()
    {
        $urlalias = new Model\Urlalias();
        $request = $this->_post();
        
        $value = trim($request->value);
        if (empty($value)) {
            
        } else {
            $url = $request->prefix.strtolower(toSlug($value));
            if ($url) {
                if ($urlalias->checkExist($url)) {
                    $this->printJson((object)array('status'=>1, 'url' => $url.'-'.uniqid()));
                } else {
                    $this->printJson((object)array('status'=>1, 'url' => $url));
                }
            }
        }
    }

    function POST_uploadimage()
    {
        return '';
        if ($u = Session::get('user_id')) {
            $cfg = new Configuration('config');
            $FileUpload = '';
            $image_url = '';
            $Max_Size_Upload = 2*1024*1024;
            $name = @$_GET['name'];
            $dir = rtrim(@$_GET['dir'], '/'); 
            /*$baseUrl = trim($_GET['baseurl']);*/
            $multi = (int)@$_GET['m'];
            $isday = (int)@$_GET['d'];
            if ($dir && file_exists($dir) && is_dir($dir)) {
                $folderUpload = $dir;
                chmod($folderUpload, 0775);
            } else {
                $folderUpload = $cfg->upload['dir'].'/'.$dir;
                $folderUpload = rtrim($folderUpload, '/'); 
                if (is_dir($folderUpload)) {
                    chmod($folderUpload, 0775);
                } else {
                    mkdir($folderUpload, 0777);
                }
                $baseUrl = $cfg->upload['url'].'/'.$dir;
            }
            if ($file = @$_FILES["file"]) {
                if ($file['error']==0) {
                    if ($file['size']>0 && $file['size'] < $Max_Size_Upload && strlen($dir) && strlen($name)) {
                        $month = date('m-Y');
                        is_dir("$folderUpload/$month") ? chmod("$folderUpload/$month", 0775) : mkdir("$folderUpload/$month", 0775);
                        if ($isday) {
                            $day = date('d');
                            is_dir("$folderUpload/$month/$day") ? @chmod("$folderUpload/$month/$day", 0775) : @mkdir("$folderUpload/$month/$day", 0775);
                            $month = $month.'/'.$day;
                        }
                        $pathinfo = pathinfo($file['name']);
                        $file_name = $pathinfo['filename'].'-'.time().'.'.$pathinfo['extension'];
                        $result = move_uploaded_file($file["tmp_name"], "$folderUpload/$month/$file_name");
                        if($result)
                        {
                            $FileUpload = "$month/$file_name";
                            $image_url = "$baseUrl/$month/$file_name";
                        }
                    }
                }
            }
            if (@$_GET['rt'] == 'json') {
                $this->printJson(array(
                    'image_url' => $image_url, 
                    'Filename' => $FileUpload, 
                    'input_name' => $name, 
                    'status' => 1
                ));
            } else {
                $this->view->return_type = @$_GET['rt'];
                $this->view->multi_upload = "$multi";
                $this->view->image_url = "$image_url";
                $this->view->Filename = "$FileUpload";
                $this->view->input_name = "$name";
                $this->view->setLayoutOff(true);
            }
        } else {
            return false;
            exit();
        }
    }
}
