<?php 
use Htlib\Mvc\View;
use Htlib\G;
use Htlib\Gf;
use Htlib\Configuration;
use Htlib\Session;
use Model\User;
use Model\Permission;
use Model\Log;

class Role extends AdminController 
{
    function index()
    {
        if (Gf::args('rolepermission')) {
            $permission = new Permission();
            $this->printJson(array('permission'=>$permission->getPermission($_GET['roleid'])));
        } else {
            $header = array(
                'h1' => 'Role',
            );
            $breadcrumb = array(
                array('mod'=>'dashboard', 'text'=>''),
                array('text'=>'Role'),
            );
            $status = 1;
            $permission = new Permission();
            $roleName = $permission->getRole();
            array_unshift($roleName, array('id'=>0, 'name'=>'&mdash;', 'description'=>'', 'actived'=>1));
            $permission = $permission->getAllPermission();
            if (Session::get('message')) {
                $this->addView('message', Session::get('message'));
                Session::delete('message');
            }
            if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
                return $this->viewJson(compact(['header', 'breadcrumb', 'status', 'roleName', 'permission']));
            }
            return $this->view('role/index');
            // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
            //     return new View('role/index');
            // }
            // return new View('layouts/admin');
        }
    }

    function permission()
    {
        if (Gf::args('tmpl')) {
            /*$this->view->headerText();*/
            $this->addView('role', (object)array(
                'edit' => 1,
                'del' => 1,
            ));
            return new View('user_permission');
        } else {
            if ($this->request_POST()=='$DELETE') {
                $this->delUser();
            }

            $this->printJson(array(
                'header' => array(
                    'h1' => 'User permission',
                    'breadcrumb'=>array(
                        array('mod'=>'dashboard', 'text'=>''),
                        array('mod'=>'role', 'text'=>'Role'),
                        array('text'=>'User permission'),
                    ),
                    'actions' => array(
                        array(
                            'text' =>'Role permission', 
                            'url'  => '#'.$this->_module, 
                            'class'=>'btn-primary',
                        ),
                    )
                ),
                'status' => 1,
                /*'data' => NULL,
                'rows' => $data['rows'],
                'pagination' => $data['pagination'],
                'role' => $data['role'],
                'offsetRow' => $data['offsetRow'],
                'search' => $data['search'],
                'mtime' => $this->getMview() + $this->getMlayout(),*/
                
            ));
        }
    }

    function POST_edit()
    {
        $status = 0;
        $request_POST = $this->request_POST();
        $request = $this->_post();
        if ($request_POST=='$SavePermission') {
            if ($request->role_id && $request->permissions && is_array($request->permissions)) {
                $permission = new Permission();
                if ($permission->savePermission($request->role_id, $request->permissions)) {
                    Session::set('message', 'Update permission success');
                    return $this->viewJson(array(
                        'status' => 1,
                        // 'redirect'=>Gf::url(array('action'=>'')),
                        'message'=>Gf::L('Update permission success'),
                    ),1);
                    $message = Gf::L('Update permission success');
                }
            } elseif ($request->role_id) {
                $permission = new Permission();
                if ($permission->savePermission($request->role_id, array())) {
                    Session::set('message', 'Update permission success');
                    return $this->viewJson(array(
                        'status' => 1,
                        // 'redirect'=>Gf::url(array('action'=>'')),
                        'message'=>Gf::L('Update permission success'),
                    ),1);
                    $status = 1;
                    $message = Gf::L('Update permission success');
                }
            }
        }
        if ($request_POST=='$ADDNEWROLE') {
            $permission = new Permission();
            if ($permission->addRole($_POST)) {
                $roleName = $permission->getRole();
                $status = 1;
                $message = Gf::L('Add new role success');
            }
        }
        if ($request_POST=='$EDIT') {
            $permission = new Permission();
            if ($permission->editRole($request->id, $_POST)) {
                $roleName = $permission->getRole();
                $status = 1;
                $message = Gf::L('Update role success');
            }
        }
        if ($request_POST=='$DELETE') {
            $permission = new Permission();
            if ($permission->delRole($request->id)) {
                $roleName = $permission->getRole();
                $status = 1;
                $message = Gf::L('Delete role success');
            }
        }
        $this->printJson((object)compact(['status', 'message', 'roleName']));
    }

    function POST_del()
    {

    }
    function POST_add()
    {

    }
}