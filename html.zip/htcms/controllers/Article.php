<?php 
use Htlib\Mvc\View;
use Htlib\Mvc\Controller;
use Htlib\Mvc\Role;
use Htlib\Configuration;
use Htlib\Session;
use Htlib\G;
use Htlib\Gf;
use Model\Article as Model_Article;
/**
 * 
 */
class Article extends AdminController
{
	
	function index()
	{
		
	}

	function POST_index(){}
	function POST_add(){}
	function add(){}
	function edit(){}
	function POST_edit(){}
}