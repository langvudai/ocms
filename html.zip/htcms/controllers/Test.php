<?php 
use Htlib\Mvc\Controller;

/**
* 
*/
class Test extends Controller 
{
	function index()
	{
		/*echo "string";
		$this->view->setLayoutOff(true);
		echo 121113;
		exit();*/
		return 'test/_action.phtml';
	}

	function compile()
	{
		$this->addView('fullWidthChecked', 1);
	}
}