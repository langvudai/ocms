<?php 
use Htlib\Mvc\View;
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;
use Model\Urlalias;
use Model\Category as Categories;

/**
 * 
 */
class Category extends AdminController
{
	
	function index()
	{
		$cfg = new Configuration();
		$categories = new Categories();
		$categories->type = self::getCategoryType();
		$categories->level = self::getMaxLevel();
		if ($cfg->lang) {
		    $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : key($cfg->lang));
		    $selected['name'] = $cfg->lang[$selected['lang']];
		    $language = array_map(function($k, $v) { 
		        return array('lang'=>$k, 'name'=>$v, 'href'=>$k);
		    }, array_keys($cfg->lang), array_values($cfg->lang));
		    $this->addView('language', array(
		        'selected' => $selected,
		        'list' => $language
		    ));
		} else {
			$selected = array('lang'=> 'vi');
		}
		$categories->lang = $selected['lang'];
		$rows = $categories->get();
		$zones = self::getZone();
		foreach ($rows as $key => $value) {
			if (isset($value['zone']) && isset($zones[$value['zone']])) {
				$rows[$key]['zone'] = $zones[$value['zone']];
			} else {
				$rows[$key]['zone'] = '';
			}
		}
		if (Session::get('message')) {
		    $this->addView('message', Session::get('message'));
		    Session::delete('message');
		}
		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
			return $this->viewJson(array(
				'breadcrumb' => array(
		            array('mod'=>'dashboard', 'text'=>''),
		            array('text'=>Gf::L('Category')),
		        ),
		        'rows' => $rows,
		        'data'=>array(
		        	'btn_url_add'=>Gf::url(array('action'=>'add')),

		        ),
			));
		}
		return $this->view('category/index');
		// if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
		//     return new View('category/index');
		// }
		// return new View('layouts/admin');
	}

	function POST_index()
	{
		$categories = new Categories();
		$request = $this->_post();
		/*echo $this->request_POST();
		print_r($request->inlineEdit);
		print_r($_POST);exit();*/
		if ($this->request_POST()=='$DELETE' &&$categories->del($request->category_id)) {
		    Session::set('message', Gf::L('Delete success'));
		    return $this->viewJson(array(
		        'status'=>1,
		    ), 1);
		}
		if ($this->request_POST()=='$UPDATE' && is_array($request->inlineEdit)) {
			//print_r($request->inlineEdit);
			$result = true;
			foreach ($request->inlineEdit as $id) {
				//print_r($request->inlineData[$id]);
				$result = $result && $categories->save($id, $request->inlineData[$id]);
			}
			if ($result) {
				Session::set('message', Gf::L('Update success'));
				return $this->viewJson(array(
				    'status'=>1,
				    'redirect'=>Gf::url(array()),
				), 1);
			}
		}
	}

	function POST_add()
	{
	    $categories = new Categories();
	    $categories->type = self::getCategoryType();
		$categories->level = self::getMaxLevel();
	    Gf::validate(array(
	        'name' => Gf::NOTNULL,
	    ));
	    $id = $categories->add(@$_POST);
	    if ($id) {
	    	if (isset($_POST['url']) && $_POST['url']) {
	    		$urlalias = new Urlalias();
	    	    $urlalias->add($_POST['url'], 'C', $id, $categories->type);
	    	}
	        Session::set('message', Gf::L('add new success'));
	        return $this->viewJson(array(
	            'status'=>1,
	            'redirect'=>Gf::url(array('module'=>$this->_module, 'action'=>''), false)
	        ), 1);
	    }
	}

	function add()
	{
		$cfg = new Configuration();
		if ($cfg->lang) {
		    $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : key($cfg->lang));
		    $selected['name'] = $cfg->lang[$selected['lang']];
		    $language = array_map(function($k, $v, $l) { 
		        return array('lang'=>$k, 'name'=>$v, 'active'=>$l==$k?'active':'');
		    }, array_keys($cfg->lang), 
		    array_values($cfg->lang), 
		    array_fill(0, count($cfg->lang), $selected['lang']));
		    $this->addView('language', array(
		        'selected' => $selected,
		        'list' => $language
		    ));
		} else {
			$selected = array('lang'=>'vi');
		}
		$category_type = self::getCategoryType();
		$category_level = self::getMaxLevel();
		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
			return $this->viewJson(array(
				'breadcrumb' => array(
		            array('mod'=>'dashboard', 'text'=>''),
		            array('mod'=>$this->_module, 'text'=>Gf::L('Category')),
		            array('text'=>Gf::L('Add new')),
		        ),
		        'data' => array(
		        	'btn_url_add' => Gf::url(array('action'=>'add')),
		        	'category_type' => $category_type,
		        	'language' => $language,
		        	'language_selected' => $selected,
		        	'zones' => self::getZone(),
		        )
			));
		}
		return $this->view('category/add');
		// if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
		//     return new View('category/add');
		// }
		// return new View('layouts/admin');
	}

	function edit()
	{
		$cfg = new Configuration();
		$category_type = self::getCategoryType();
		$category_level = self::getMaxLevel();
		$categories = new Categories();
		$category_id = Gf::args('id');
		$data = $categories->getOnce($category_id);

		if ($cfg->lang) {
		    $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : key($cfg->lang));
		    $selected['name'] = $cfg->lang[$selected['lang']];
		    $language = $name = $title = $keyword = $description = array();
		    foreach ($cfg->lang as $key => $value) {
		    	$language[] = array(
		    	    'lang'   => $key, 
		    	    'name'   => $value, 
		    	    'active' => $selected['name']==$key ? 'active' : ''
		    	);
		    	$name = array(
		    	    'lang' => $key, 
		    	    'value' => @$data['name'][$key], 
		    	    'active'=>$selected['lang']==$key?'active':''
		    	);
		    	$title = array(
		    	    'lang' => $key, 
		    	    'value' => @$data['title'][$key], 
		    	    'active'=>$selected['lang']==$key?'active':''
		    	);
		    	$keyword = array(
		    	    'lang' => $key, 
		    	    'value' => @$data['keyword'][$key], 
		    	    'active'=>$selected['lang']==$key?'active':''
		    	);
		    	$description = array(
		    	    'lang' => $key, 
		    	    'value' => @$data['description'][$key], 
		    	    'active'=>$selected['lang']==$key?'active':''
		    	);
		    }
            $data['name'] = $name;
            $data['title'] = $title;
            $data['keyword'] = $keyword;
            $data['description'] = $description;
            //print_r($data);exit();
		    /*
		    if (!empty($data['name']) && is_array($data['name'])) { 
            }
            if (!empty($data['title']) && is_array($data['title'])) { 
            }
            if (!empty($data['keyword']) && is_array($data['keyword'])) { 
            }
            if (!empty($data['description']) && is_array($data['description'])) { 
            }*/

		    // $language = array_map(function($k, $v, $l) { 
		    //     return array('lang'=>$k, 'name'=>$v, 'active'=>$l==$k?'active':'');
		    // }, array_keys($cfg->lang), 
		    // array_values($cfg->lang), 
		    // array_fill(0, count($cfg->lang), $selected['lang']));
		    $this->addView('language', array(
		        'selected' => $selected,
		        'list' => $language
		    ));
		}
		
		/*if (isset($data['name']) && is_array($data['name'])) {
			foreach ($data['name'] as $l=>$v) {

			}
			$selected['value'] = $data['name'][$selected['lang']];
		}*/
		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
			return $this->viewJson(array(
				'breadcrumb' => array(
		            array('mod'=>'dashboard', 'text'=>''),
		            array('mod'=>$this->_module, 'text'=>Gf::L('Category')),
		            array('text'=>Gf::L('Edit')),
		        ),
		        'data' => array(
		        	'btn_url_add' => Gf::url(array('action'=>'add')),
		        	'category_type' => $category_type,
		        	'language' => $language,
		        	'language_selected' => $selected,
		        	'data' => $data,
		        	'zones' => self::getZone(),
		        	//'name' => $data['name']
		        )
			));
		}
		return $this->view('category/edit');
		// if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
		//     return new View('category/edit');
		// }
		// return new View('layouts/admin');
	}

	function POST_edit()
	{
	    $categories = new Categories();
	    $urlalias = new Urlalias();
	    $categories->type = self::getCategoryType();
		$categories->level = self::getMaxLevel();
		$id = Gf::args('id');
	    $result = $categories->save($id, @$_POST);
	    if ($result) {
	    	if (isset($_POST['url']) && $_POST['url']) {
	    	    $urlalias->add($_POST['url'], 'C', $id, $categories->type) || $urlalias->save('C', $id, $_POST['url'], $categories->type);
	    	} else {
                $urlalias->del('', 'C', $id);
            }
	        Session::set('message', Gf::L('edit success'). ' #'.$id);
	        return $this->viewJson(array(
	            'status'=>1,
	            'redirect'=>Gf::url(array('module'=>$this->_module, 'action'=>''), false)
	        ), 1);
	    }
	}

	function del()
	{
		
	}

	function POST_del()
	{
		
	}

	function permission()
	{
		return $this->viewJson(array(
			'breadcrumb' => array(
	            array('mod'=>'dashboard', 'text'=>''),
	            array('mod'=>'category', 'text'=>'Category'),
	            array('text'=>'permission'),
	        ),
	        'rows' => $rows,
	        'data' => array(
	        	'btn_url_add' => Gf::url(array('action'=>'add'))
	        )
		));
	}	
}