<?php 
use Model\User;
use Htlib\Mvc\View;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;
use Htlib\Db\DbTable;

class Profile extends AdminController
{
    public function index()
    {
        // return $this->viewJson();
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            $u = new User();
            $data = $u->getOnce(Session::get('user_id'));
            $this->addView('status', 1);
            $this->addView('user_id', Session::get('user_id'));
            $this->addView('data', $data);
            $this->addView('header', array(
                'h1' => 'Profile',
            ));
            $this->addView('breadcrumb', array(
                array('mod'=>'dashboard', 'text'=>'Dashboard'),
                array('text'=>'Profile'),
            ));
            // $this->printJson();
            return $this->viewJson();
        }
        return $this->view('profile/index');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('profile/index');
        // }
        // return new View('layouts/admin');
    }

    public function POST_index()
    {
        $u = new User();
        if ($rq = $this->request_POST()) {
            if ($rq=='$UPDATE') {
                if ($error = Gf::invalid()) {
                } else{
                    $_POST['actived'] = (int)$_POST['actived'];
                    if ($u->save(Session::get('user_id'), $_POST)) {
                        $this->addView('status', 1);
                        $this->addView('message', 'update successful');
                    } else {
                        $this->addView('status', 0);
                        $this->addView('message', $u->error);
                    }
                }
            }

            if ($rq=='$PASSWORD') {
                if (empty($_POST['pwd1'])) {
                    $this->addView('status', 0);
                    $this->addView('message', Gf::L('Password is empty'));
                } elseif ($_POST['pwd1']!=$_POST['pwd2']) {
                    $this->addView('status', 0);
                    $this->addView('message', Gf::L('Confirm password is invalid'));
                } else {
                    if ($u->updatePassword(Session::get('user_id'), $_POST['password'], $_POST['pwd1'])) {
                        $this->addView('status', 1);    
                        $this->addView('message', 'change password successful');
                    } else {
                        $this->addView('status', 0);
                        $this->addView('message', $u->error);
                    }
                }
            }
        }
        $this->printJson();
    }
}
