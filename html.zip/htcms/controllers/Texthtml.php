<?php 

use Htlib\Mvc\View;
use Htlib\Configuration;
use Htlib\Gf;
use Htlib\Session;
use Model\Texthtml as Model_Texthtml;

/**
 * 
 */
class Texthtml extends AdminController
{
	
	function index()
	{
		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
			$content_type = self::getContentType();
			$content_type_id= Gf::args('tid') ? Gf::args('tid') : key($content_type);
			$texthtml = new Model_Texthtml();
			$texthtml->type = $content_type_id;
			$pageSize = 10;
	        $page = Gf::args('page') ? (int)Gf::args('page') : 1;
	        $data = $texthtml->getList(NULL, $pageSize, $page);
	        $rows = array_map(function($row){
	        	$row['data_type_name'] = strtr($row['data_type'], array(2=>'Text', 3=>'Html', 4=>'Json', 5=>'Article'));
	        	return $row;
	        }, $data->rows);
	        $pagination = Gf::pagination(Gf::url(array('page'=>NULL)), $data->count, $pageSize, $page);

	        if (Session::get('message')) {
	            $this->addView('message', Session::get('message'));
	            Session::delete('message');
	        }
			return $this->viewJson(array(
				'breadcrumb' => array(
		            array('mod'=>'dashboard', 'text'=>''),
		            array('text'=>Gf::L('Texthtml')),
		        ),
		        'rows' => $rows,
		        'pagination' => $pagination,
		        'data' => array(
		        	'contentType' => array_map(function($k,$v){return array('id'=>$k, 'text'=>$v);}, array_keys($content_type), array_values($content_type)),
		        	'contentTypeId' => $content_type_id,
		        ),
			));
		}
		if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
			$label = self::getLabel();
			if (!empty($label) && is_array($label)) {
				Gf::L($label);
				View::setLang('vi', $label);
			}
			if (self::getTemplate()) {
		    	return new View(self::getTemplate());
			}
		    return new View('texthtml/index');
		}
		return new View('layouts/admin');
	}

	function POST_index()
	{
		if ($this->request_POST('ADD')) {
			$texthtml = new Model_Texthtml();
			$id = $texthtml->add($this->_post()->toArray());
			if ($id) {
				return $this->viewJson(array(
				    'status'=>1,
				    'redirect'=>Gf::url(array('action'=>'edit', 'id'=>$id)),
				), 1);
			}
		}
		if ($this->request_POST('UPDATE')) {
			$texthtml = new Model_Texthtml();
			$inlineEdit = $this->_post()->inlineEdit;
			$inlineData = $this->_post()->inlineData;
			foreach ($inlineEdit as $id) {
			    $texthtml->edit($id, $inlineData[$id]);
			}
			Session::set('message', Gf::L('Update success'));
			return $this->viewJson(array(
			    'status'=>1,
			    'redirect'=>Gf::url(array()),
			), 1);
		}
		if ($this->request_POST('DELETE')) {
			$texthtml = new Model_Texthtml();
			if ($texthtml->del($this->_post()->id)) {
				Session::set('message', Gf::L('Delete success'));
				$status = 1;
			}
			return $this->viewJson(array(
			    'status'=>$status,
			    'redirect'=>Gf::url(array()),
			), 1);
		}
	}

	function edit()
	{
		$cfg = new Configuration();
		$id = Gf::args('id');
		$texthtml = new Model_Texthtml();

		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
        	$data = $texthtml->getOnce($id);
	        if ($cfg->lang) {
	            $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : key($cfg->lang));
	            $selected['name'] = $cfg->lang[$selected['lang']];
	            $language = array(
	                'selected' => $selected, 
	                'list' => array_map(function($k, $v, $s){
	                	return array('lang'=>$k, 'name'=>$v, 'active' => $s==$k ? 'active' : '');
	                }, array_keys($cfg->lang), array_values($cfg->lang), array_fill(0, count($cfg->lang), $selected['lang'])), 
	            );
	        } else {
	        	$selected = array('lang'=> 'vi');
	        }
	        $data['language'] = $language;
			$status = $data['data_type'];
			$breadcrumb = array(
		            array('mod'=>'dashboard', 'text'=>''), 
		            array('mod'=>$this->_module, 'text'=>Gf::L('Texthtml')), 
		            array('text'=>Gf::L('Edit')), 
		        );
			
			if (Session::get('message')) {
				$message = Session::get('message');
			    Session::delete('message');
			}
			return $this->viewJson(compact(array('status', 'breadcrumb', 'language', 'message', 'data')), 1);
		}

		if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
			$data = $texthtml->getList(array('id'=>$id), 1)->rows[0];
			if (self::getTemplate()) {
		    	return new View(self::getTemplate());
			}
		    return new View('texthtml/edit', array(
		    	'dfText' => $data['data_type']==2 ? true : false, 
		    	'dfHtml' => $data['data_type']==3 ? true : false, 
		    	'dfJson' => $data['data_type']==4 ? true : false, 
		    	'dfArticle' => $data['data_type']==5 ? true : false, 
		    ));
		}

		return new View('layouts/admin');
	}

	function POST_edit()
	{
		if ($this->request_POST('SAVE')) {
			$id = Gf::args('id');
			$texthtml = new Model_Texthtml();
			if ($texthtml->saveContent($id, $this->_post()->toArray())) {
				return $this->viewJson(array(
				    'status'=>1,
				    'message'=>Gf::L('Edit success'),
				), 1);
			}
		}
	}
}