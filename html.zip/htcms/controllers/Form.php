<?php 
use Htlib\Configuration;
use Htlib\Gf;
use Htlib\Session;
use Htlib\Db\DbTable;
use Htlib\Db\Expr; 
use Model\Form as Model_Form; 

/**
 * 
 */
class Form extends AdminController
{
	private $forms, $fid;
	function init()
	{
	    $label = self::getLabel();
	    if (!empty($label) && is_array($label)) {
	    	Gf::L($label);
	    	View::setLang('vi', $label);
	    }
	}

	function index()
	{
		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
			$form = new Model_Form();
			$data = $form->get();
			/*print_r($data);exit();*/
			if (Session::get('message')) {
			    $this->addView('message', Session::get('message'));
			    Session::delete('message');
			}
			return $this->viewJson(array(
				'breadcrumb' => array(
		            array('mod'=>'dashboard', 'text'=>''),
		            array('text'=>Gf::L('Form')),
		        ),
		        'rows' => $data->rows,
			));
		}
		return $this->view('form/index');
	}

	function POST_index()
	{
		
	}

	function POST_valuelist()
	{
		
	}

	function valuelist()
	{
		
	}
}