<?php 
use Htlib\Mvc\View;
use Htlib\Mvc\Controller;
/*use Htlib\Mvc\Role;*/
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;
use Model\Urlalias;

class Findex extends AdminController
{
    private static $uid, $dirPath, $uploadDir, $baseUrl, $path, $listdir, $dirlock;

    function init1()
    {
        $cfg = new Configuration();
        if (self::$uid = Session::get('user_id')) {
            $uri = explode('?', $_SERVER['REQUEST_URI']);


            $dirs = explode('/', trim($uri[0], '/'));


            unset($dirs[0]);
            unset($dirs[1]);
            unset($dirs[2]);
            self::$dirPath = implode('/', $dirs);
            self::$uploadDir = $cfg->upload['dir'];
            self::$baseUrl = $cfg->upload['url'];
            self::$path = self::$uploadDir .'/'. self::$dirPath;
            $dirs = array_map('urldecode', $dirs);
            Gf::urlMatch('/dir/module/action');
            $args = Gf::args();
            unset($args['dir']);
            unset($args['module']);
            unset($args['action']);
            print_r($args);
            global $path;
            

            //exit();
            self::$listdir = $dirs;
            if (!$dirs) {
                self::$dirlock = array_replace(array(
                    'banners' => 1, 
                    'categories' => 1, 
                    'files' => 1, 
                    'items' => 1, 
                    'menus' => 1, 
                ), is_array($this->dirLock) ? array_fill_keys($this->dirLock, 1) : array($this->dirLock=>1));
            }
            /*$role = G::role();*/
            /*echo (int)$role->check($this->module, 'add');
            exit($this->module);*/
            $context = array();
            if (Gf::R($this->module, 'add')) {
                $context['newdir'] = ';newdir:'.Gf::L('New folder');
                $context['upload'] = ';upload:'.Gf::L('Upload');
                $context['resize'] = ';resize:'.Gf::L('Resize');
                $context['duplicate'] = ';duplicate:'.Gf::L('Duplicate');
            }
            if (Gf::R($this->module, 'edit')) {
                $context['rename'] = ';rename:'.Gf::L('Rename');
            }
            if (Gf::R($this->module, 'del')) {
                $context['del'] = ';del:'.Gf::L('Delete');
            }
            $this->addView('ctx', $context);
            $this->addView('fullwidth', 1);
            return parent::init();
        } else {
            exit();
        }
    }

    private function str2latin($str)
    {
        $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
        $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
        $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
        $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
        $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
        $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
        $str = preg_replace("/(đ)/", 'd', $str);
        $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
        $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
        $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
        $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $str);
        $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
        $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
        $str = preg_replace("/(Đ)/", 'D', $str);
        return $str;
    }

    function index()
    {
        $breadcrumb = array(array('mod'=>'dashboard', 'text'=>''));
        $uri = explode('?', $_SERVER['REQUEST_URI']);
        $uri = trim($uri[0], ' /');
        $j = trim($this->_module.'/'.$this->_action, ' /');
        $i = stripos($uri, $j);
        $path = trim($i ? substr($uri, $i+strlen($j)) : substr($uri, strlen($j)), ' /');
        $url = $base_url = '/'.($i ? substr($uri, 0, $i+strlen($j)) : substr($uri, 0, strlen($j))) . (empty($this->_action) ? '/index':'');
        $cfg = array();
        $config = new Configuration();
        //$this->addView('cfg', $cfg);
        $cfg['baseDir'] = $dir = $config->upload['dir'];
        //$this->addView('baseDir', $dir);
        $cfg['baseUrl'] = $config->upload['url'];
        //$this->addView('baseUrl', $baseUrl);
        $furl = $config->upload['url'].'/'. $path;
        $dir = urldecode($dir .'/'. $path);
        $cfg['dir'] = $dir;
        //$this->addView('dir', $dir);
        $breadcrumb[] = array('url'=>$url, 'text'=>'<i class="fa fa-folder-open-o"></i>');
        if (strlen($path)>0) {
            $not_is_root = 1;
            $path = explode('/', $path);
            $end = end($path);
            unset($path[count($path)-1]);
            foreach ($path as $i=>$value) {
                $url.= '/'.$value;
                $breadcrumb[] = array('url'=>$url, 'text'=>$value);
            }
            $breadcrumb[] = array('text'=>$end);
        } else {
            $not_is_root = 0;
        }

        /*$this->addView('BU', $this->moduleDir .'/'. $this->module .'/index');
        $this->addView('listdir', self::$listdir);
        $this->addView('dirPath', self::$dirPath);
        $this->addView('dirlock', self::$dirlock);
        echo $d;
        exit();*/
        if (is_dir($dir)) {
            $d = dir($dir);
            $dirItems = $fileItems = array();
            while (false !== ($entry = $d->read())) {
                if ($entry) {
                    $fullpath = $dir.'/'.$entry;
                    $name = urldecode($entry);
                    if (file_exists($fullpath) && is_readable($fullpath) && is_file($fullpath)) {
                        $fileItems[$name] = array_replace(array(
                            'name' => $name,
                            'file' => $fullpath,
                            'furl' => $furl .'/'. $entry,

                        ), $this->fileInfo($fullpath));
                    } elseif(file_exists($fullpath) && is_readable($fullpath) && is_dir($fullpath) && $entry!='.') {
                        if ($not_is_root) {
                            $dirItems[$name] = array(
                                'dirlock'=>0,
                                'name' => $name,
                                'path' => $entry=='..' ? $url : ($url.'/'.$end.'/'.$name),
                            );
                        } elseif ($name!='..') {
                            $dirItems[$name] = array(
                                'dirlock'=>(int)in_array($name, array('..', 'banners', 'files', 'items')),
                                'name' => $name,
                                'path' => $entry=='..' ? $url : ($url.'/'.$name),
                            );
                        }
                    }
                }
            }
            $d->close();
            ksort($dirItems);
            ksort($fileItems);
            /*print_r($dirItems);
            print_r($fileItems);
            exit();*/
            // $this->addView('dirItems', $dirItems);
            // $this->addView('fileItems', $fileItems);
            /*$this->addView('rows', array(
                'dirItems' => $dirItems,
                'fileItems' => $fileItems,
            ));*/
        }

        $aa = $this->views->allow_add;
        $ae = $this->views->allow_edit;
        $ad = $this->views->allow_del;
        $ctx = array(
            'newdir' => $aa ? (';newdir:'.Gf::L('New folder')) : '',
            'upload' => $aa ? (';upload:'.Gf::L('Upload')) : '',
            'resize' => $aa ? (';resize:'.Gf::L('Resize')) : '',
            'duplicate' => $aa ? (';duplicate:'.Gf::L('Duplicate')) : '',
            'rename' => $ae ? (';rename:'.Gf::L('Rename')) : '',
            'del' => $ad ? (';del:'.Gf::L('Delete')) : '',
        );
        //print_r(pathinfo($config->upload['dir'])['filename']);exit();
        return $this->viewJson(array(
            'breadcrumb' => $breadcrumb,
            'data' => array(
                'ctx' => $ctx, 
                'cfg' => $cfg, 
                'not_is_root' => $not_is_root, 
                'dirItems' => array_values($dirItems), 
                'fileItems' => array_values($fileItems), 
                'dirname' => empty($end) ? pathinfo($config->upload['dir'])['filename'] : $end,
            ),
        ));
        //return '_action.html';
    }

    function popup()
    {
        
    }

    private function fileInfo($filename)
    {
        $mime = mime_content_type($filename);
        $modifyTime = filemtime($filename);
        $filesize = filesize($filename);
        if ($filesize > 1024 * 1024) {
            $size = ceil($filesize / (1024 * 1024)).'MB';
        } elseif ($filesize > 1024) {
            $size = ceil($filesize / 1024).'KB';
        } else {
            $size = $filesize.'B';
        }
        setlocale(LC_ALL,'en_US.UTF-8');
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($extension, array('png', 'jpg', 'gif'))) {
            $type = 'image';
        }
        return array(
            'mime' => $mime, 
            'extension' => $extension, 
            'filesize' => $filesize, 
            'size' => $size, 
            'modifyTime' => $modifyTime, 
            'type' => $type, 
        );
    }

    function uploadfindex_POST()
    {
        $this->view->setLayoutOff();
    }

    function upload_POST()
    {
        if ($file = @$_FILES["file"]) {
            if ($file['error']==0) {
                $cfg = new Configuration('config');
                $dir = $_POST['path'];
                $folderUpload = rtrim($cfg->upload['dir']) . ($dir ? ('/'.$dir) : '');
                $baseUrl = $cfg->upload['url'] . ($dir ? ('/'.$dir):'');
                if (is_dir($folderUpload)) {
                    chmod($folderUpload, 0775);
                }
                setlocale(LC_ALL,'en_US.UTF-8');
                $pathinfo = pathinfo($file['name']);
                $filename = $pathinfo['filename'].'.'.$pathinfo['extension'];
                $i = 1;
                while (file_exists($folderUpload.'/'.$filename) && $i<100) {
                    $filename = $pathinfo['filename'].'('.$i.').'.$pathinfo['extension'];
                    $i++;
                }
                
                $result = move_uploaded_file($file['tmp_name'], $folderUpload.'/'.$filename);
                if ($result) {
                    $fileInfo = $this->fileInfo($folderUpload.'/'.$filename);
                    $this->printJson(array(
                        'status' => 1,
                        'message'=> '',
                        'filename'=> $filename,
                        'src'=> $baseUrl.'/'.$filename,
                        'fileinfo' => $this->fileInfo($folderUpload.'/'.$filename),
                    ));
                }
            }
        }
        $this->view->image_url = "$image_url";
        $this->view->setLayoutOff(true);
        
        exit();
    }

    function newfolder()
    {
        $folderName = $this->str2latin(trim($_POST['folderName']));
        if (substr_count($folderName, '/')) {
            $this->printXML(array('node' => 'status', 'value' => 0), array('node' => 'message', 'value' => 'invalid name'));
        } else {
            if (is_dir(self::$path)) {
                chmod(self::$path, 0775);
            }
            $result = mkdir(self::$path.'/'.$folderName, 0775);
            if ($result) {
                $this->printXML(array(
                    'node' => 'status', 
                    'value' => 1, 
                    'attribute' => array(
                        'name' => $folderName
                    )
                ));
            }
        } 
        
        exit();
    }

    function del()
    {
        $d = self::$path;
        @$name = $_POST['name'];
        @$type = $_POST['type'];
        if ($name && $type=='file' && !self::$dirlock[$name] && unlink($d .'/'. $name)) {
            $this->printXML(array('node' => 'status', 'value' => 1));
        }
        if ($name && $type=='folder' && $this->deleteDirectory($d .'/'. $name)) {
            $this->printXML(array('node' => 'status', 'value' => 1));
        }
        exit();
    }
    private function deleteDirectory($dirPath)
    {
        if (! is_dir($dirPath)) {
            throw new InvalidArgumentException("$dirPath must be a directory");
        }
        if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
            $dirPath .= '/';
        }
        $files = glob($dirPath . '*', GLOB_MARK);
        foreach ($files as $file) {
            if (is_dir($file)) {
                $this->deleteDirectory($file);
            } else {
                unlink($file);
            }
        }
        if (rmdir($dirPath)) {
            return true;
        }
        return false;
    }

    function rename()
    {
        $d = self::$path;
        if (substr_count($_POST['new-name'], '/')) {
            $this->printXML(
                array('node' => 'status', 'value' => 0), 
                array('node' => 'message', 'value' => 'invalid name')
            );
        } elseif (!file_exists($d .'/'. $_POST['new-name'])) {
            if (rename($d .'/'. $_POST['old-name'], $d .'/'. $_POST['new-name'])) {
                if ($_POST['type']=='file') {
                    $fileinfo = $this->fileInfo($d .'/'. $_POST['new-name']);
                    $this->printXML(array(
                        'node' => 'status', 
                        'value' => 1, 
                        'attribute' => array(
                            'src' => self::$baseUrl.'/'.self::$dirPath.'/'.$_POST['new-name'],
                            'is-img' => (int)($fileinfo['type']=='image'),
                            'mime' => $fileinfo['mime']
                        )
                    ));
                } else {
                    $this->printXML(array('node' => 'status', 'value' => 1));
                }
            }
        }
        exit();
    }

    function duplicate()
    {
        $name = $_POST['name'];
        setlocale(LC_ALL,'en_US.UTF-8');
        $info = pathinfo(self::$path.'/'.$name);
        $d = 1;
        $filename = $info['filename'].' (copy '.$d.').'.$info['extension'];
        while (file_exists(self::$path.'/'.$filename)) {
            $d++;
            $filename = $info['filename'].' (copy '.$d.').'.$info['extension'];
        }
        if (copy(self::$path.'/'.$name, self::$path.'/'.$filename)) {
            $this->printJson(array(
                'status' => 1, 
                'filename' => $filename, 
                'src' => self::$baseUrl.'/'.self::$dirPath.'/'.$filename, 
                'fileinfo' => $this->fileInfo(self::$path.'/'.$filename),
            ));
        }
    }

    function resize()
    {
        $name = $_POST['name'];
        $filename = self::$path.'/'.$name;
        setlocale(LC_ALL,'en_US.UTF-8');
        $info = pathinfo($filename);
        $size = explode(',', $_POST['value']);
        if ($size[0]>0 || $size[1]>0) {
            include_once __DIR__.'/Findex.SimpleImage.php';
            $simpleImage = new SimpleImage();
            $imageInfo = $simpleImage->load($filename);
            if ($imageInfo && $imageInfo['sourceWidth'] <= $size[0] && $imageInfo['sourceHeight'] <= $size[1]) {
                $this->duplicate();
                return;
            } elseif($imageInfo) {
                $ratio  = $imageInfo['sourceHeight'] / $imageInfo['sourceWidth'];
                $W = $size[0];
                $H = $W * $ratio;
                if($H > $size[1]){
                    $H = $size[1];
                    $W = $H / $ratio;
                }
                $newFile = $info['filename'].'-'.$W.'x'.$H.'.'.$info['extension'];
                if (file_exists(self::$path.'/'.$newFile)) {
                    $d = 1;
                    $newFile = $info['filename'].'-'.$W.'x'.$H.' (copy '.$d.').'.$info['extension'];
                    while (file_exists(self::$path.'/'.$newFile)) {
                        $d++;
                        $newFile = $info['filename'].'-'.$W.'x'.$H.' (copy '.$d.').'.$info['extension'];
                    }
                }
                $simpleImage->resize($W, $H);
                $simpleImage->save(self::$path.'/'.$newFile, $imageInfo['sourceType']);
                $this->printJson(array(
                    'status' => 1, 
                    'filename' => $newFile, 
                    'src' => self::$baseUrl.'/'.self::$dirPath.'/'.$newFile, 
                    'fileinfo' => $this->fileInfo(self::$path.'/'.$newFile),
                ));
            }
        }
    }
}