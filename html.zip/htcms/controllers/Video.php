<?php 

/**
 * 
 */
class Video extends AdminController
{
	
	function index()
	{
		return $this->viewJson(array(
			'breadcrumb' => array(
	            array('mod'=>'dashboard', 'text'=>''),
	            array('text'=>'Video'),
	        ),
		));
	}
}