<?php 

/**
 * 
 */
class Image extends AdminController
{
	
	function index()
	{
		return $this->viewJson(array(
			'breadcrumb' => array(
	            array('mod'=>'dashboard', 'text'=>''),
	            array('text'=>'Image'),
	        ),
		));
	}
}