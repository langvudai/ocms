<?php 
use Htlib\Mvc\View;
use Htlib\G;
use Htlib\Gf;
use Htlib\Configuration;
use Htlib\Session;
use Model\User as modelUser;
use Model\Permission;
use Model\Log;

class User extends AdminController 
{
    function init()
    {
        $this->_muser = new modelUser();
        // return parent::init();
    }

    function index()
    {
        if ($this->request_POST()=='$DELETE') {
            $this->delUser();
        }
        $data = $this->getData();
        $this->addView('breadcrumb', array(
                    array('mod'=>'dashboard', 'text'=>''),
                    array('text'=>'User'),
                ));
        $this->addView('status', 1);
        $this->addView('data', NULL);
        $this->addView('rows', $data['rows']);
        $this->addView('pagination', $data['pagination']);
        $this->addView('role', $data['role']);
        $this->addView('offsetRow', $data['offsetRow']);
        $this->addView('search', @$data['search']);
        $this->addView('mtime', 111);
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson();
        }
        return $this->view('user/index');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('user/index');
        // }
        // return new View('layouts/admin');
    }
    private function getData($p=0)
    {
        
        $u = $this->_muser;
        $data = array();
        $page_row = 20;
        $page = $p ? $p : (Gf::args('page') ? (int)Gf::args('page') : 1);
        $filter = array();
        $keyword = Gf::args('search');
        if ($keyword) {
            $data['search'] = $keyword;
            $keyword = str_replace(' ', '%', $keyword);
            $keyword_slug = str_replace('-', '%', toSlug($keyword));
            $filter[] = 'username like \'%'.$keyword_slug.'%\' OR fullname LIKE \'%'.$keyword.'%\' OR email LIKE \'%'.$keyword_slug.'%\'';
        }
        $ls = $u->getAll($filter, $page_row, $page);
        foreach ($ls['rows'] as $key => $value) {
            $ls['rows'][$key]['urledit'] = Gf::url(array('action'=>'edit', 'id'=>$value['id']));
            $ls['rows'][$key]['urldel'] = Gf::url(array('action'=>'del'));
            $ls['rows'][$key]['name'] = explode(',', $value['name']);
        }
        $data['rows'] = $ls['rows'];
        $data['total'] = $ls['total'];
        $page_base_url = '#'.Gf::args('module').'/'.trim(Gf::args('action'), '-');
        if ($keyword) {
            $page_base_url .= '/search/'.$keyword;
        }
        $data['pagination'] = Gf::pagination(Gf::url(array('page'=>NULL)), $ls['total'], $page_row, $page);
        $data['offsetRow'] = ($page-1)*$page_row+1;
        $permission = new Permission();
        $role = $permission->getRoleA();
        foreach ($role as $key => $value) {
            $array[] = array( 'role_id'=>$key, 'role_name'=>$value);
        }
        $data['role'] = $array;
        $data['status'] = 1;
        $data['pushurl'] = Gf::url(array('action'=>''));
        return $data;
    }
    private function getForm($id=0)
    {
        $permission = new Permission();
        if ($id) {
            $user = $this->_muser->getOnce($id);
            $role = $permission->getRoleA($id);
        } else {
            $role = $permission->getRoleA();
        }
        return $this->viewJson(array(
            'data'=>compact(array('role', 'user')),
            'status'=>1,
            'userId' => $id,
        ));
    }

    function add()
    {
        $this->addView('breadcrumb', array(
                array('mod'=>'dashboard', 'text'=>'Dashboard'),
                array('mod'=>'user', 'text'=>'User'),
                array('text'=>'Add new user'),
            ));
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->getForm();
        }
        return $this->view('user/add');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('user/add');
        // }
        // return new View('layouts/admin');
    }

    function POST_edit()
    {
        $this->request_POST();
        $request = $this->_post();
        if($ms = Gf::invalid()) {
            $this->printJson(array(
                'status'=>0,
                'msg'=>$ms,
            ));
        } else {
            if ($request->confirmPassword && $request->newPassword && strlen($request->newPassword)>0) {
                if ($request->newPassword == $request->confirmPassword) {
                    $password = $request->newPassword;
                } else {
                    $this->printJson(array(
                        'status' => 0, 
                        'msg'=>Gf::L('invalid confirm password')
                    ));
                }
            }
            //unset($_POST['new-password']);
            //unset($_POST['confirm-password']);
            //$_POST['actived'] = (int)$_POST['actived'];
            $rs = $this->_muser->save($request->id, array(
                //'id',
                //'username' => $request->username,
                'email' => $request->email,
                //'password' => $request->password,A
                'actived' => (int)$request->actived,
                'fullname' => $request->fullname,
                
                'time_create' => $request->time_create,
                'time_update' => $request->time_update,
                //'timestamp' => $request->timestamp,

            ));
            if ($rs) {
                if (isset($password) && $password) {
                    $updpw = $this->_muser->updateNewPassword($request->id, $password);
                } 
                //if (is_array($request->role_id)) {
                (new Permission())->updateUserRole($request->id, $request->role_id);
                //}

                $this->printJson(array(
                    'status'=>'1', 
                    'message'=>Gf::L('updated'), 
                ));
            } else {
                $this->printJson(array('status'=>0, 'message'=>$this->_muser->error));
            }
        }
        
    }

    function POST_add()
    {
        $this->request_POST();
        $request = $this->_post();
        if(isset($request->password) && $request->password==$request->confirmPassword) {
            $u = $this->_muser;
            $id = $u->add(array(
                'username' => $request->username,
                'email' => $request->email,
                'password' => $request->password,
                'actived' => $request->actived,
                'fullname' => $request->fullname,
            ));
            if ($id) {
                (new Permission())->updateUserRole($id, $request->role_id);
                $this->printJson((object)array(
                    'status'=>'1', 
                    'message'=>Gf::L('added'), 
                    'redirectUrl'=>Gf::url(array('action'=>'', 'page'=>null, 'keyword'=>null)), 
                ));
            } else {
                $this->printJson(array(
                    'status'=>0,
                    'msg'=>$u->error,
                ));
            }
        } else {
            $this->printJson(array(
                'status'=>0,
                'msg'=>Gf::L('invalid confirm password'),
            ));
        }
    }

    function edit()
    {
        $userId = Gf::args('id');
        $this->addView('breadcrumb', array(
                array('mod'=>'dashboard', 'text'=>'Dashboard'),
                Gf::args('page')?array('mod'=>'user', 'text'=>'User', 'page'=>Gf::args('page')):array('mod'=>'user', 'text'=>'User'),
                array('text'=>'Edit user'),
            ));
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->getForm($userId);
        }
        return $this->view('user/edit');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('user/edit');
        // }
        // return new View('layouts/admin');
    }

    private function delUser()
    {
        if ($this->request_POST()) {
            if ($this->_muser->deleteUser($_POST['username'])) {
                $data = $this->getData(1);
                $this->printJson(array(
                    'status'=>'1', 
                    'messege'=>'<font color="#ff0000">'.Gf::L('deleted').'</font>', 
                    'rows' => $data['rows'], 
                    'pagination' => $data['pagination'],
                    'offsetRow' => $data['offsetRow'],
                ));
            } else {
                $this->printJson(array(
                    'status' => 0,
                    'message'=> '',
                    'error'  => $this->_muser->error,
                ));
            }
        }
        exit();
    }

    function gettest()
    {
        $this->setLayoutOff(true);
        $data = $this->getData();
        $this->view->headerJson();
        $data['offsetRow'] = 5;
        $this->printJson($data);
        exit();
        print_r($data);
        exit();
    }

    function history()
    {
        $data = array();
        $log = new Log();
        if ($this->request_POST() == '$Delete-History') {
            $request = $this->_post();
            if ($request->timeRange=='selected' && is_array($request->id)) {
                if ($log->delete('id IN ('.implode(',', $request->id).')')) {
                    $message = Gf::L('Delete history success');
                }
            } else {
                if ($log->delLog(strtolower($request->timeRange)=='all' ? 0 : $request->timeRange)) {
                    $message = Gf::L('Delete history success');
                } 
            }
        }
        $page_row = 25;
        $page = (int)Gf::args('page') ? (int)Gf::args('page') : 1;
        $offsetRow = ($page-1)*$page_row+1;
        @$rs = $log->getlog($page, $page_row, gf::args('fd'), gf::args('td'));
        $rows = !empty($rs['rows']) && is_array($rs['rows']) ? array_values($rs['rows']) : array();

        $page_base_url = '#'.Gf::args('module').'/'.trim(Gf::args('action'), '-');
        $pagination = Gf::pagination(Gf::url(array('page'=>NULL)), $rs['count'], $page_row, $page);

        if ($this->views->allow_del) {
            $actions[] = array(
                'text' =>'<i class="fa fa-trash"></i> Clear history', 
                'class'=>'btn-danger', 
                'dataset' => array( 
                    'backdrop' =>'static', 
                    'keyboard' =>'false', 
                    'target' =>'#deletehistory', 
                    'toggle' =>'modal', 
                )
            );
        }
        $breadcrumb = array(
            array('mod'=>'dashboard', 'text'=>'Dashboard'),
            array('mod'=>'user', 'text'=>'User'),
            array('text'=>'Log history'),
        );
        $status = 1;
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson((object)compact(array('breadcrumb', 'status', 'data', 'rows', 'pagination', 'message', 'offsetRow')));
        }
        return $this->view('user/history');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('user/history');
        // }
        // return new View('layouts/admin');
    }
}


