<?php 
use Htlib\Mvc\View;
use Htlib\Mvc\Controller;
use Htlib\Mvc\Role;
use Htlib\Configuration;
use Htlib\Session;
use Htlib\G;
use Htlib\Gf;
use Model\Banner as Model_Banner;

/**
* 
*/
class Banner extends AdminController
{
    private $positions, $posid;
    function init()
    {
        $this->posid = Gf::args('posid') ? Gf::args('posid') : 0;
        if (is_array(self::getPosition()) && !empty(self::getPosition())) {
            if (count(self::getPosition())==1) {
                $this->posid = key(self::getPosition());
            }
            $positions = array_replace(array(0=>Gf::L('All position')), self::getPosition());
            $this->positions = array_map(function($k, $v, $p) {
                return array('url'=>Gf::url(array('posid'=>$k ? $k : NULL)), 'text'=>$v, 'selected'=>$k==$p ? 'selected':'', 'id'=>$k);
            }, array_keys($positions), array_values($positions), array_fill(0, count($positions), $this->posid));
        } else {
            $positions = array();
        }

        // return parent::init();
    }
    function index()
    {
        

        $page_row = 20;
        $page = Gf::args('page') ? (int)Gf::args('page') : 1;
        // if ($this->views->posid) {
        // }
        $banner = new Model_Banner();
        if ($this->posid) {
            $banner->position = $this->posid;
        }
        $data = $banner->get(NULL, $page_row, $page);
        $pagination = Gf::pagination(Gf::url(array('page'=>NULL)), $data->count, $page_row, $page);
        //print_r($data);exit();
        if (Session::get('message')) {
            $this->addView('message', Session::get('message'));
            Session::delete('message');
        }
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson(array(
                'breadcrumb' => array(
                    array('mod'=>'dashboard', 'text'=>''),
                    array('text'=>Gf::L('Banner')),
                ), 
                'status' => 1, 
                'data' => array('posid'=>$this->posid, 'positions'=>$this->positions), 
                'rows' => $data->rows, 
                'pagination' => $pagination, 
                'offsetRow' => ($page-1)*$page_row+1, 
                'search' => '', 
            ));
        }
        return $this->view('banner/index');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('banner/index');
        // }
        // return new View('layouts/admin');
    }

    function POST_index() 
    {
        $banner = new Model_Banner();
        if ($this->request_POST()=='$DELETE') {
            if ($banner->del($this->_post()->banner_id)) {
                Session::set('message', Gf::L('delete success'));
                return $this->viewJson(array(
                    'status'=>1,
                    'redirect'=>Gf::url(array('module'=>$this->_module, 'action'=>''), false)
                ), 1);
            } else {
                return $this->viewJson(array(
                    'status'=>0,
                    'message'=>$banner->error
                ), 1);;
            }
        }
        if ($this->request_POST()=='$UPDATE') {
            $inlineEdit = $this->_post()->inlineEdit;
            $inlineData = $this->_post()->inlineData;
            foreach ($inlineEdit as $id) {
                $banner->update(array(
                    'name' => $inlineData[$id]['name'],
                    'order' => $inlineData[$id]['order'],
                    'display' => (int)$inlineData[$id]['display'],
                ), 'id='.$id);
                //echo $banner;
            }
            //exit();
            Session::set('message', Gf::L('update success'));
            return $this->viewJson(array(
                'status'=>1,
                'redirect'=>Gf::url(array('module'=>$this->_module, 'action'=>''), false)
            ), 1);
        }
    }
    function POST_add() 
    {
        $banner = new Model_Banner();
        if ($banner->add($_POST)) {
            Session::set('message', Gf::L('add new success'));
            return $this->viewJson(array(
                'status'=>1,
                'redirect'=>Gf::url(array('module'=>$this->_module, 'action'=>''), false)
            ), 1);
        } else {
            return $this->viewJson(array(
                'status'=>0,
                'message'=>$banner->error
            ), 1);;
        }
    }
    function add() 
    {
        array_shift($this->positions);
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson(array(
                'breadcrumb' => array(
                    array('mod'=>'dashboard', 'text'=>''),
                    array('mod'=>'banner', 'text'=>Gf::L('Banner')),
                    array('text'=>Gf::L('Add new banner')),
                ), 
                'status' => 1, 
                'data' => array(
                    'posid'=>$this->posid, 
                    'positions'=>$this->positions
                ), 
                'rows' => $data->rows, 
                'pagination' => $pagination, 
                'offsetRow' => ($page-1)*$page_row+1, 
                'search' => '', 
            ));
        }
        
        return $this->view('banner/add');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('banner/add');
        // }
        // return new View('layouts/admin');
    }
    function edit() 
    {
        array_shift($this->positions);
        $banner = new Model_Banner();
        $id = Gf::args('id');
        $data = $banner->getOnce($id);        
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson(array(
                'breadcrumb' => array(
                    array('mod'=>'dashboard', 'text'=>''),
                    array('mod'=>'banner', 'text'=>Gf::L('Banner')),
                    array('text'=>Gf::L('Edit banner')),
                ), 
                'status' => 1, 
                'data' => array(
                    'posid'=>$this->posid, 
                    'positions'=>$this->positions,
                    'data'=>$data
                ), 
                'rows' => $data->rows, 
                'pagination' => $pagination, 
                'offsetRow' => ($page-1)*$page_row+1, 
                'search' => '', 
            ));
        }
        return $this->view('banner/edit');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('banner/edit');
        // }
        // return new View('layouts/admin');
    }
    function POST_edit() 
    {
        $banner = new Model_Banner();
        $id = Gf::args('id');
        unset($_POST['id']);
        if ($banner->save($id, $_POST)) {
            Session::set('message', Gf::L('Edit success'));
            return $this->viewJson(array(
                'status'=>1,
                'redirect'=>Gf::url(array('module'=>$this->_module, 'action'=>''), false)
            ), 1);
        } else {
            return $this->viewJson(array(
                'status'=>0,
                'message'=>$banner->error
            ), 1);;
        }
    }

}