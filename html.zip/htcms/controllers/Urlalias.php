<?php 
use Htlib\Mvc\View;
use Htlib\G;
use Htlib\Gf;

/**
* 
*/
class Urlalias extends AdminController
{
    function index()
    {
        return $this->viewJson(array(
            'breadcrumb' => array(
                array('mod'=>'dashboard', 'text'=>''),
                array('text'=>'Urlalias'),
            ),
        ));
    }
    function get()
    {
        return $this->viewJson();
    }
}
