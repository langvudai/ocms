<?php 

use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;

/**
 * 
 */
class Item extends AdminController
{
	
	function index()
	{
		$cfg = new Configuration();
		if (Session::exist('filterdata')) {
			$filterdata = Session::get('filterdata');
		}
		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
			if ($cfg->lang) {
			    $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : key($cfg->lang));
			    $selected['name'] = $cfg->lang[$selected['lang']];
			    $language = array_map(function($k, $v) { 
			        return array('lang'=>$k, 'name'=>$v, 'href'=>$k);
			    }, array_keys($cfg->lang), array_values($cfg->lang));
			    $this->addView('language', array(
			        'selected' => $selected,
			        'list' => $language
			    ));
			} else {
				$selected = array('lang'=> 'vi');
			}

			return $this->viewJson(array(
				'breadcrumb' => array(
		            array('mod'=>'dashboard', 'text'=>''),
		            array('text'=>'Item'),
		        ),
		        'data' => compact(array('filterdata')),
			));
		}
		return $this->view('item/index');
	}

	function POST_index()
	{
		$request = $this->request_POST();
		$post = $this->_post();
		// print_r($post->toArray());
		if ($request=='$FILTER') {
			Session::set('filterdata', $post->filter);
			return $this->viewJson(array(
			    'status'=>1,
			    'redirect'=>Gf::url(array()),
			), 1);
		}
	}

	function add()
	{
		$cfg = new Configuration();
		$item_type = self::getItemType();
		$category_type = self::getCategoryType();
		if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
			if ($cfg->lang) {
			    $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : key($cfg->lang));
			    $selected['name'] = $cfg->lang[$selected['lang']];
			    $language = array_map(function($k, $v, $l) { 
			        return array('lang'=>$k, 'name'=>$v, 'active'=>$l==$k?'active':'');
			    }, array_keys($cfg->lang), 
			    array_values($cfg->lang), 
			    array_fill(0, count($cfg->lang), $selected['lang']));
			    $this->addView('language', array(
			        'selected' => $selected,
			        'list' => $language
			    ));
			} else {
				$selected = array('lang'=>'vi');
			}
			return $this->viewJson(array(
				'breadcrumb' => array(
		            array('mod'=>'dashboard', 'text'=>''),
		            array('mod'=>$this->_module, 'text'=>'Item'),
		            array('text'=>'Add new'),
		        ),
		        'data' => array(
		        	'item_type' => $item_type,
		        	'category_type' => $category_type,
		        	'language' => $language,
		        	'language_selected' => $selected,
		        	'itemStatus' => self::getItemStatus(),
		        	// 'zones' => self::getZone(),
		        )
			));
		}
		return $this->view('item/add');
	}
}