<?php 
use Htlib\Mvc\View;
use Htlib\G;
use Htlib\Gf;
use Htlib\Db\DbTable;

/**
* 
*/
class Dashboard extends AdminController
{
	function __construct($argument)
    {
        parent::__construct($argument);
    }

    function index()
    {
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson(array(
                'breadcrumb'=>array(
                    array('mod'=>'dashboard', 'text'=>'Dashboard'),
                    array('text'=>'Dashboard'),
                ),
            ));
        }
        if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
            return new View('dashboard/index');
        }
        return new View('layouts/admin');
    }
}