<?php 
use Htlib\Mvc\View;
use Model\Menu as modelMenu;
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;

/**
* 
*/
class Menu extends AdminController
{
    // private function assignTypeMenu()
    // {
        
    // }

    // private function getparent()
    // {

    // }
    
    function index()
    {
        $cfg = new Configuration();
        $actions = array();
        if ($this->views->allow_add) {
            $actions[] = array('text' =>'Addnew', 'url'  => '#'.$this->_module.'/add', 'class'=>'add-user-btn btn-success');
        }
        if ($this->views->allow_edit) {
            $actions[] = array('text' =>'Update', 'url'  => '#'.$this->_module.'/add', 'class'=>'btn-primary');
        }
        $this->addView('breadcrumb', array(
            array('mod'=>'dashboard', 'text'=>''),
            array('text'=>Gf::L('Menu')),
        ));
        if (Session::get('message')) {
            $this->addView('message', Session::get('message'));
            Session::delete('message');
        }
        //$menu_type = self::getMenuType();
        //print_r($menu_type);exit();
        /* if (is_array($menu_type) && !empty($menu_type)) {
            $a = array();
            foreach ($menu_type as $key => $value) {
                array_push($a, array('id'=>$key, 'name'=>$value));
            }
            $this->addView('menuType', $a);
        }*/
        if ($cfg->lang) {
            $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : key($cfg->lang));
            $selected['name'] = $cfg->lang[$selected['lang']];
            $language = array_map(function($k, $v) { 
                return array('lang'=>$k, 'name'=>$v, 'href'=>$k);
            }, array_keys($cfg->lang), array_values($cfg->lang));
            $this->addView('language', array(
                'selected' => $selected,
                'list' => $language
            ));
        } else {
            $selected = array('lang'=> 'vi');
        }

        $model_menu = new modelMenu();
        $model_menu->type = self::getMenuType();
        $model_menu->maxLevel = self::getMaxLevel();
        $model_menu->lang = $selected['lang'];
        $rows = $model_menu->get();
        $data['btn_url_add'] = Gf::url(array('action'=>'add'));
        /*print_r($rows);
        exit();*/
        $this->addView('rows', $rows);
        $this->addView('data', $data);
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson();
        }
        return $this->view('menu/index');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('menu/index');
        // }
        // return new View('layouts/admin');
    }

    function POST_index()
    {
        //print_r($_POST);exit();
        $menu = new modelMenu();
        if ($this->request_POST()=='$DELETE' &&$menu->del($this->_post()->menu_id)) {
            Session::set('message', Gf::L('Delete success'));
            return $this->viewJson(array(
                'status'=>1,
            ), 1);
        }
        /*return $this->viewJson(array(
            'status'=>0,
            'message'=>''
        ), 1);*/
    }

    private function optionTree()
    {
        
    }
    
    function getonce()
    {
        
    }
    
    function POST_add()
    {
        $menu = new modelMenu();
        $menu->type = self::getMenuType();
        $menu->maxLevel = self::getMaxLevel();
        Gf::validate(array(
            'menu_name' => Gf::NOTNULL,
        ));
        $id = $menu->add(@$_POST);
        if ($id) {
            Session::set('message', Gf::L('add new success'));
            return $this->viewJson(array(
                'status'=>1,
                'redirect'=>Gf::url(array('module'=>$this->_module, 'action'=>''), false)
            ), 1);
            /*return $this->viewJson(array(
                'status' => 1, 
                'message' => Gf::L('add new success'),
                //'data'=>array('menuParent' => $menuParent),
                'id' => $id,
            ));*/
        }
    }
    function add()
    {
        $cfg = new Configuration();
        $this->addView('breadcrumb', array(
                array('mod'=>'dashboard', 'text'=>'Dashboard'),
                array('mod'=>$this->_module, 'text'=>Gf::L('Menu')),
                array('text'=>Gf::L('Add new menu')),
            ));
        if ($cfg->lang) {
            $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : key($cfg->lang));
            $selected['name'] = $cfg->lang[$selected['lang']];
            $language = array_map(function($k, $v, $l) { 
                return array('lang'=>$k, 'name'=>$v, 'active'=>$l==$k?'active':'');
            }, array_keys($cfg->lang), 
            array_values($cfg->lang), 
            array_fill(0, count($cfg->lang), $selected['lang']));
            $this->addView('language', array(
                'selected' => $selected,
                'list' => $language
            ));
        } else {
            $selected = array('lang'=> 'vi');
        }
        $model_menu = new modelMenu();
        $menutype = self::getMenuType();
        $model_menu->type = $menutype;
        $model_menu->maxLevel = self::getMaxLevel();
        $model_menu->lang = $selected['lang'];
        $parent = $model_menu->getTreeOption();
        $status = 1;
        $data = compact(array('menutype', 'language', 'parent'));
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson(compact(array('status', 'data')));
        }
        return $this->view('menu/add');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('menu/add');
        // }
        // return new View('layouts/admin');
    }
    
    function edit()
    {
        if (Session::get('message')) {
            $this->addView('message', Session::get('message'));
            Session::delete('message');
        }
        $cfg = new Configuration();
        $selected = array('lang'=> Gf::args('lang') ? Gf::args('lang') : (is_array($cfg->lang) ? key($cfg->lang) : 'vi'));
        $menu_id = Gf::args('id');
        $this->addView('breadcrumb', array(
                array('mod'=>'dashboard', 'text'=>'Dashboard'),
                array('mod'=>$this->_module, 'text'=>Gf::L('Menu')),
                array('text'=>Gf::L('Edit menu')),
            ));
        $model_menu = new modelMenu();
        $menutype = self::getMenuType();
        $model_menu->type = $menutype;
        $model_menu->maxLevel = self::getMaxLevel();
        $model_menu->lang = $selected['lang'];
        $parent = $model_menu->getTreeOption($menu_id);
        $data = $model_menu->getOnce($menu_id);
        if (is_array($parent) && $parent) {
            foreach ($parent as $key => $value) {
                $value['selected'] = @$data['parent_id']==$value['id'] ? ' selected ':'';
                $parent[$key] = $value;
            }
        }
        if ($cfg->lang) {
            $selected['name'] = $cfg->lang[$selected['lang']];
            $language = $name = array();
            foreach ($cfg->lang as $key => $value) {
                array_push($language, array(
                    'lang'   => $key, 
                    'name'   => $value, 
                    'active' => $selected['name']==$key ? 'active' : ''
                ));
                array_push($name, array(
                    'lang' => $key, 
                    'value' => @$data['name'][$key], 
                    'active'=>$selected['lang']==$key?'active':''
                ));
            }
            if (!empty($data['name']) && is_array($data['name'])) { 
                $data['name'] = $name;
            }
            $this->addView('language', array(
                'selected' => $selected,
                'list' => $language
            ));
        }
        if (Gf::httpx('json')||(isset($_GET['format'])&&$_GET['format']=='json')) {
            return $this->viewJson(array(
                'status'=> 1,
                'data'  => array_replace($data, compact(array('menutype', 'language', 'parent')))
            ));
        }
        return $this->view('menu/edit');
        // if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
        //     return new View('menu/edit');
        // }
        // return new View('layouts/admin');
    }
    function POST_edit()
    {
        $cfg = new Configuration();
        $menu_id = Gf::args('id');
        $model_menu = new modelMenu();
        $model_menu->type = self::getMenuType();
        $model_menu->maxLevel = self::getMaxLevel();
        $result = $model_menu->save($menu_id, @$_POST);
        if ($result) {
            Session::set('message', Gf::L('update success').' #'.$menu_id);
            return $this->viewJson(array(
                'status'=>1,
                'redirect'=>Gf::url(array('module'=>$this->_module, 'action'=>''), false)
            ), 1);
        }
    }
    
    function permission(){}
    function POST_permission(){}
}