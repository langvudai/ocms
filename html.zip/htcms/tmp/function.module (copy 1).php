<?php 
use Htlib\Mvc\View;
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;

Gf::getImage(function($url){
    if (is_readable($f = Configuration::getUpload('dir').'/'.$url) && is_file($f)) {
        return '<img src="'.Configuration::getUpload('url').'/'.$url.'" />';
    } else {
        return '<img role="no-image" src="//cdn.appnet.vn/AdminLTE/imgs/no-image.png">';
    }
});

if (!function_exists('view')) {
	function view($temp, $data=NULL)
	{

	}
}

function INCLUDE_HTML($path)
{
	$file = __DIR__.'/views/'.$path;
	if (file_exists($file) && is_file($file) && is_readable($file)) {
		return file_get_contents($file);
	}
	return '<li><i></i><span>'.$file.'</span></li>';
}

