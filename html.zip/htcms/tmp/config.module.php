<?php 
return array(
    'route' => array(
        'banner' => array(
            'file' => 'controllers/Banner',
            'class'=> 'Banner',
            'call' => 'before_call_banner',
            'arg' => array(
                'position' => array(
                    6 => 'header-top', 
                    7 => 'slide', 
                    8 => 'banner center', 
                    9 => 'brand', 
                ),
                'disableFeild' => array('order'),
            ),
            'nav-menu' => 'Nội dung/Banner',
            'nav-ajax' => true,
            'nav-icon' => 'globe',
        ),
        'menu' => array(
            'file' => 'controllers/Menu',
            'class'=> 'Menu',
            'call' => function(){
                Menu::setMenuType(array(
                    /*5 => 'top header',*/
                    6 => 'header',
                ));
                Menu::setMaxLevel(array(5=>1, 6=>5));
                Menu::disable(array('icon'=>1));
            },
            'nav-menu' => 'Nội dung/Menu',
            'nav-ajax' => true,
            'nav-icon' => 'list',
        ),
        'linkfooter' => array(
            'file' => 'controllers/Menu',
            'class'=> 'Menu',
            'call' => function(){
                Menu::setMenuType(array(
                    7 => 'link footer',
                ));
                Menu::setMaxLevel(array(7=>3));
                /*Menu::disable(array('icon'=>1));*/
            },
            'nav-menu' => 'Nội dung/Footer link',
            'nav-ajax' => true,
        ), 
        'category' => array(
            'file' => 'controllers/Category',
            'class'=> 'Category',
            'call' => function() {
                Category::setCategoryType(array(
                    '10' => 'San pham'
                ));
                Category::setMaxLevel(array(5=>3));
                Category::setPrefixUrl('/');
                Category::setAppearance(array('theme1' => '/theme1.jpg'));
                Category::disable(array('title'=>1, 'description'=>1));
                Category::setCategoryOption(array(
                    array('name'=>'title_seo', 'label'=>'Title', 'type'=>'text'),
                    array('name'=>'key_seo', 'label'=>'Keyword', 'type'=>'textarea'),
                    array('name'=>'des_seo', 'label'=>'Description', 'type'=>'textarea'),
                    array('name'=>'fb_img', 'label'=>'Social image', 'type'=>'image'),
                    /*array('name'=>1, 'label'=>'Social image', 'type'=>'select', 'option' => array(
                            'value-1' => '111111111111111111',
                            'value-2' => '222222222222222222',
                            'value-3' => '333333333333333333',
                            'value-4' => '444444444444444444',
                            'value-5' => '555555555555555555',
                    ),),*/
                ));
            },
            'nav-menu' => 'Nội dung/Quản lý danh mục',
            'nav-icon' => 'folder',
            'nav-ajax' => true,
        ),
        'product' => array(
            'file' => 'controllers/Item',
            'class'=> 'Item',
            'nav-menu' => 'Nội dung/Product',
            'nav-ajax' => true,
            'nav-icon' => 'dropbox', 
            'action'=>array(
                'add' => 'Thêm mới',
                'excel' => 'Đồng bộ excel',
            ),
            'call' => function(){
                Item::setCategoryType(array(10 => 'Danh muc san pham'));
                Item::setMultiCategory(true);
                Item::setPrefixUrl('/');
                Item::setItemType(array(
                    10 => 'San pham',
                ));
                Item::setTypeGroup(array(
                    2 => 'Article',
                    1 => 'Static',
                ));
                Item::setItemOption(
                    array(
                        'name'   => 'price',
                        'label'  => 'Gia',
                        'type'   => '',
                        'className'  => 'datetime',
                    ),
                    array(
                        'name'   => 'sale_price',
                        'label'  => 'Gia khuyen mai',
                        'type'   => '',
                    ),
                    array(
                        'name'   => 'seo_keyword',
                        'label'  => 'Seo keyword',
                        'type'   => 'text',
                    ),
                    array(
                        'name'   => 'seo_description',
                        'label'  => 'Seo description',
                        'type'   => 'text',
                    ),
                    array(
                        'name'   => 'seo_title',
                        'label'  => 'Seo title',
                        'type'   => 'text',
                    )
                );
                Item::disable(array('chk0' => 1, 'chk1' => 1, 'chk2' => 1, 'chk3' => 1, 'chk4' => 1, 'chk5' => 1, 'chk6' => 1, 'chk7' => 1, 'chk8' => 1, 'chk9'=>1, 'tags'=>0, 'is_hot'=>1, 'is_new'=>1));
            }
        ),
        'news' => array(
            'file' => 'controllers/Item',
            'class'=> 'Item',
            'nav-menu' => 'Nội dung/Tin tức',
            'nav-ajax' => true,
            'nav-icon' => 'newspaper-o', 
            'action'=>array(
                'add' => 'Thêm mới',
            ),
            'call' => function(){
                /*Item::setCategoryType(array(10 => 'Danh muc san pham'));*/
                Item::setPrefixUrl('/');
                Item::setItemType(array(
                    11 => 'Tin tuc',
                ));
                Item::setTypeGroup(array(
                    2 => 'Article',
                    1 => 'Static',
                ));
                Item::setItemOption(
                    /*array(
                        'name'   => 'price',
                        'label'  => 'Gia',
                        'type'   => '',
                        'className'  => 'datetime',
                    ),
                    array(
                        'name'   => 'sale_price',
                        'label'  => 'Gia khuyen mai',
                        'type'   => '',
                    ),*/
                    array(
                        'name'   => 'author',
                        'label'  => 'Author',
                        'type'   => 'text',
                        'tab'    => 'general',
                    ),
                    array(
                        'name'   => 'seo_keyword',
                        'label'  => 'Seo keyword',
                        'type'   => 'text',
                        'tab'    => 'general',
                    ),
                    array(
                        'name'   => 'seo_description',
                        'label'  => 'Seo description',
                        'type'   => 'text',
                        'tab'    => 'general',
                    ),
                    array(
                        'name'   => 'seo_title',
                        'label'  => 'Seo title',
                        'type'   => 'text',
                        'tab'    => 'general',
                    )
                );
                Item::disable(array('chk0' => 1, 'chk1' => 1, 'chk2' => 1, 'chk3' => 1, 'chk4' => 1, 'chk5' => 1, 'chk6' => 1, 'chk7' => 1, 'chk8' => 1, 'chk9'=>1, 'tags'=>0, 'status'=>1, 'category'=>1));
            }
        ),
        'texthtml' => array(
            'file' => 'controllers/Texthtml',
            'class'=> 'Texthtml',
            'call' => 'before_call_texthtml',
            'arg'  => array(
                'content-type'=>array(
                    1 => 'block',
                    2 => 'Static',
                    3 => 'Service',
                ),
            ),
            /*'nav-menu' => "Text html",*/
            'nav-ajax' => true,
        ),
        'Service' => array(
            'file' => 'controllers/Texthtml',
            'class'=> 'Texthtml',
            'call' => 'before_call_texthtml',
            'arg'  => array(
                'content-type'=>array(
                    3 => 'Service',
                ),
                'disableFeild'=>array(
                    'btnAdd'=>1,
                    'btnUpdate'=>1,
                    'btnDel'=>1,
                ),
            ),
            /*'nav-menu' => "Nội dung/Service",*/
            'nav-ajax' => true,
        ),
        'static' => array(
            'file' => 'controllers/Texthtml',
            'class'=> 'Texthtml',
            'call' => 'before_call_texthtml',
            'arg'  => array(
                'content-type'=>array(
                    2 => 'Static',
                ),
                'disableFeild'=>array(
                    'btnAdd'=>1,
                    'btnUpdate'=>1,
                    'btnDel'=>1,
                ),
            ),
            'nav-menu' => "Nội dung/Nội dung tĩnh",
            'nav-ajax' => true,
        ),
        'texthtmla' => array(
            'file' => 'controllers/Texthtml',
            'class'=> 'Texthtml',
            'call' => 'before_call_texthtml',
            'arg'  => array(
                /*'content-type'=>array(*/
                    /*1 => 'block',*/
                    /*2 => 'Static',*/
                /*),*/
                'disableFeild'=>array(
                    'order'=>true,
                    'form-order' => true,
                ),
                'action-edit'=>'about',
            ),
            'nav-menu' => "Nội dung/About",
            'nav-ajax' => true,
        ),
        'attribute' => array(
            'file' => 'controllers/Attribute',
            'class'=> 'Attribute',
            'nav-ajax' => true,
            'call' => function(){
                Attribute::setType(array(
                    /*1 => 'block',*/
                    2 => 'Static',
                ));
            }
        ),

        /**/
        'urlalias' => array(
            'file' => 'controllers/Urlalias',
            'class'=> 'Urlalias',
            'nav-menu' => 'Nội dung/Url alias',
            'nav-ajax' => true,
            'call' => function(){
            }
        ),
        /*'order' => array(
            'file' => 'controllers/ordercart/Order',
            'class'=> 'Order',
            'nav-menu' => 'Bán hàng/Đơn đặt hàng',
            'nav-ajax' => true,
        ),
        'contact' => array(
            'file' => 'controllers/ordercart/Contact',
            'class'=> 'Contact',
            'nav-menu' => 'Bán hàng/Ý kiên khách hàng',
            'nav-ajax' => true,
        ),
        'customer' => array(
            'file' => 'controllers/ordercart/Customer',
            'class'=> 'Customer',
            'nav-menu' => 'Bán hàng/Khách hàng',
            'nav-ajax' => true,
        ),
        'reseller' => array(
            'file' => 'controllers/ordercart/Reseller',
            'class'=> 'Reseller',
            'nav-menu' => 'Bán hàng/Đại lý',
        ),
        'warehouse' => array(
            'file' => 'controllers/Warehouse',
            'class'=> 'Warehouse',
            // 'nav-menu' => 'Bán hàng/Kho hàng',
            'nav-ajax' => true,
        ),
        'report' => array(
            'file' => 'controllers/Report',
            'class'=> 'Report',
            // 'nav-menu' => 'Bán hàng/Báo cáo',
            'nav-ajax' => true,
        ),
        'bill' => array(
            'file' => 'controllers/Bill',
            'class'=> 'Bill',
            // 'nav-menu' => 'Bán hàng/Hóa đơn',
            'nav-ajax' => true,
        ),*/
    ),
    'viewDir' => __DIR__.'/views', 
    'layout' => __DIR__.'/views/layout.html', 
    'velayout' => __DIR__.'/views/velayout.html', 
);
