<?php 
use Htlib\Gf;
return array(
	'index' => 'Index',
	'login' => 'Login',
	'logout' => 'Login::logout',
	'profile' => 'Profile',
	'upload' => 'Upload',
	'dashboard' => 'Dashboard',
	'user' => 'User',
	'urlalias' => 'Urlalias',
	'user/history' => array('User::history'=>array(
		'position' => array(
		    6 => 'header-top', 
		    7 => 'slide', 
		    8 => 'banner center', 
		    9 => 'brand', 
		),
		'disableFeild' => array('order'),
	)),
	'role' => 'Role',
	'banner' => array('Banner'=>array(
        'position' => array(
            1 => 'header-top', 
            2 => 'slide', 
            3 => 'banner center', 
            4 => 'brand', 
        ),
        'disableFeild' => array('start_date'=>0, 'end_date'=>0),
    )),
	'menu' => array('Menu'=>array(
		'menuType'=>1,
		'maxLevel'=>3,
		// 'disableFeild'=>array('icon'=>1)
	)),
	'footerlink' => array('Menu'=>array(
		'menuType'=>2,
		'maxLevel'=>1,
		'disableFeild'=>array('icon'=>0),
		'label' => array(
			'Menu' => 'Liên kết chân trang',
			'Menu manager' => 'Quản lý liên kết chân trang',
			'Add Menu' => 'Thêm mới',
			'Menu name' => 'Text',
			'Menu url' => 'Url',
		),
	)),
	'category' => array('Category'=>array(
		'categoryType'=>1,
		'maxLevel'=>1,
		'prefixUrl'=>'/',
		'sufixUrl'=>'',
		'appearance'=>array('theme1'=>'/theme11.jpg'),
		'disableFeild'=>array('tab1'=>1, 'tab2'=>1, 'tab3'=>1, 'parent_id'=>1),
		'zone'=>array(
			'1'=>'Home',
			'2'=>'Right',
		),
	)),
	'category/permission' => array('Category::permission'=>array(
		'categoryType'=>1,
		'maxLevel'=>3,
	)),
	'categorynews' => array('Category'=>array(
		'categoryType'=>2,
		'maxLevel'=>1,
		'prefixUrl'=>'/',
		'sufixUrl'=>'',
		'disableFeild'=>array('title', 'description'),
		'categoryOption'=>array(
			array('name'=>'title_seo', 'label'=>'Title', 'type'=>'text'),
			array('name'=>'key_seo', 'label'=>'Keyword', 'type'=>'textarea'),
			array('name'=>'des_seo', 'label'=>'Description', 'type'=>'textarea'),
			array('name'=>'fb_img', 'label'=>'Social image', 'type'=>'image'),
		),
	)),
	'item' => array('Item'=>array(
		'categoryType' => array(10 => 'Danh muc san pham'),
		'multiCategory' => true,
		'prefixUrl' => '/',
		'sufixUrl'=>'',
		'itemType' => array(1 => 'San pham',),
		'typeGroup'=> array(
		    2 => 'Article',
		    1 => 'Static',
		),
		'itemOption'=>array (
		    array(
		        'name'   => 'price',
		        'label'  => 'Gia',
		        'type'   => '',
		        'className'  => 'datetime',
		    ),
		    array(
		        'name'   => 'sale_price',
		        'label'  => 'Gia khuyen mai',
		        'type'   => '',
		    ),
		    array(
		        'name'   => 'seo_keyword',
		        'label'  => 'Seo keyword',
		        'type'   => 'text',
		    ),
		    array(
		        'name'   => 'seo_description',
		        'label'  => 'Seo description',
		        'type'   => 'text',
		    ),
		    array(
		        'name'   => 'seo_title',
		        'label'  => 'Seo title',
		        'type'   => 'text',
		    )
		),
		'itemStatus'=>array(
			1=>'Pending',
			2=>'Approved',
			3=>'Not approve',
		),
		'disableFeild'=>array('code'=>0, 'chk0' => 1, 'chk1' => 1, 'chk2' => 1, 'chk3' => 1, 'chk4' => 1, 'chk5' => 1, 'chk6' => 1, 'chk7' => 1, 'chk8' => 1, 'chk9'=>1, 'tags'=>0, 'is_hot'=>0, 'is_new'=>1, 'date'=>0, 'status'=>0, )
	)),
	'item/permission' => 'Item::permission',
	'texthtml' => array('Texthtml'=>array(
		'content-type'=>array(
		    1 => 'block',
		    /*2 => 'Static',
		    3 => 'Service',*/
		),
		'label' => array(
			'Describes the data type Text' => 'Nội dung chỉ chứa text đơn giản',
			'Describes the data type Html' => 'Nội dung là siêu văn bản, chứa các thẻ HTML',
			'Describes the data type Json' => 'Nội dung dạng json, cần định nghĩa các key',
			'Describes the data type Article' => 'Định dạng bài viết bao gồm tiêu đề, ảnh đại diện, sapo, tóm tắt, nội dung chi tiết',
		),
	)),
	'service' => array('Texthtml'=>array(
		'content-type'=>array(
		    3 => 'Service',
		),
		'template'=>'texthtml/service',
		'label' => array(
			'Texthtml' => 'Service',
			'Describes the data type Html' => 'Nội dung là siêu văn bản, chứa các thẻ HTML',
			'Describes the data type Json' => 'Nội dung dạng json, cần định nghĩa các key',
			'Describes the data type Article' => 'Định dạng bài viết bao gồm tiêu đề, ảnh đại diện, sapo, tóm tắt, nội dung chi tiết',
		),
	)),
	'texthtmla' => array('Texthtml::edit'=>array(
		'disableFeild'=>array(
		    'order'=>true,
		    'form-order' => true,
		),
		'name'=>'about'
	)),
	'video' => 'Video',
	'image' => 'Image',
	'page' => 'Page',
	'findex' => 'Findex',
);
