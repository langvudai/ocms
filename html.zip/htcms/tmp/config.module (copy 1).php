<?php 
return array(
	array(
		'text'=> 'Dashboard',
		'mod' => 'dashboard',
		'act' => '',
		'url' => 'dashboard',
		'onlyMobile' => 1,
	),
	array(
		'text' => 'Chung',
		'icon' => 'globe',
		'childs'=>array(
			array('text' => "Quản lý tài khoản",'mod' => "user",'url' => "user",'icon' => "user"),
			array('text' => "Lịch sử đăng nhập",'mod' => "user",'act' => "history",'url' => "user/history",'icon' => "history"),
			array('text' => "Phân quyền tài khoản",'mod' => "permission",'url' => "permission",'icon' => "users"),
			array('text' => "Banner",'mod' => "banner",'url' => "banner"),
			array('text' => "Menu",'mod' => "menu",'url' => "menu"),
			array('text' => "Category",'mod' => "category",'url' => "category",'icon' => "folder-o"),
			array('text' => "Item",'mod' => "item",'url' => "item"),
			array('text' => "Text html",'mod' => "texthtml",'url' => "texthtml"),
		)
	),
	array(
		'text' => 'Media',
		'icon' => 'camera-retro',
		'childs'=>array(
			array('text' => "Quản lý video",'mod' => "video",'url' => "video",'icon' => "video-camera"),
		)
	),
	array(
		'text' => 'Pages',
		'childs'=>array(
			array('text' => "Builder",'mod' => "pagebuilder",'url' => "pagebuilder",'childs'=>array(
					array('text' => "setting",'mod' => "pagebuilder",'act' => "set",'url' => "pagebuilder/set",'active' => ""),
				)
			)
		)
	),
	array('href' => "/htcms/findex",'url' => "findex",'text' => "Fileman",'icon' => "cabinet"),
);
