<?php return array(
        'banner' => array(
            'file' => 'controllers/Banner',
            'class'=> 'Banner',
            'call' => function(){
                Banner::setPosition(1, 'default');
                /*Menu::setMenuType(array(
                    1 => 'top header',
                    2 => 'header',
                ));
                Menu::setMaxLevel(array(1=>3, 2=>5));*/
            },
            'nav-menu' => 'General/Banner',
            /*'nav-icon' => 'list',*/
        ),
        'menu' => array(
            'file' => 'controllers/Menu',
            'class'=> 'Menu',
            'call' => function(){
                Menu::setMenuType(1, 'top header');
                Menu::setMaxLevel(3);
                Menu::setValueUrl(array(
                    '/' => 'Homepage',
                    '#a' => '',
                    '#b' => '',
                    '#c' => '',
                    '#d' => '',
                ));
                Menu::disable(array('icon'=>0));
            },
            'nav-menu' => 'General/Menu',
        ),
        'category' => array(
            'file' => 'controllers/Category',
            'class'=> 'Category',
            'call' => function(){
                Category::setCategoryType(1, 'Category type name');
                Category::setMaxLevel(3);
                Category::disable(array(
                    'in_home'=>1,
                    'size_top'=>1,
                    'appearance'=>1,
                    'title'=>1,
                    'description'=>0,
                    'url'=>1,
                    'parent_id'=>0,
                ));
                Category::setCategoryOption(array(
                    array('name'=>3, 'label'=>'Title tag', 'type'=>'text'),
                    array('name'=>2, 'label'=>'Meta tag keyword', 'type'=>'textarea'),
                    array('name'=>1, 'label'=>'Meta tag description', 'type'=>'textarea'),
                    array('name'=>4, 'label'=>'Social image', 'type'=>'image'),
                    array('name'=>5, 'label'=>'Option', 'type'=>'select', 'option' => array(
                            'value-1' => '111111111111111111',
                            'value-2' => '222222222222222222',
                            'value-3' => '333333333333333333',
                            'value-4' => '444444444444444444',
                            'value-5' => '555555555555555555',
                    ),),
                ));
            },
            'nav-menu' => 'General/Category',
            'nav-icon' => 'folder-o',
        ),
        'item' => array(
            'file' => 'controllers/Item',
            'class'=> 'Item', 
            'call' => function(){
                Item::setItemType(5, 'Item type name');
                Item::setCategoryType(array(1 => 'Category'));
                Item::setMaxLevel(2);
                Item::setMultiCategory(true);
                Item::setPrefixUrl('/');
                Item::disable(array(
                    'filter_category'=>0,
                    'code'=>0,
                    'date'=>0,
                    'status'=>0,
                    'is_hot'=>0,
                    'is_new'=>0,
                    'chk0'=>0,
                    'chk1'=>0,
                    'chk2'=>1,
                    'chk3'=>1,
                    'chk4'=>1,
                    'chk5'=>1,
                    'chk6'=>1,
                    'chk7'=>1,
                    'chk8'=>1,
                    'chk9'=>1,
                    'shared'=>1,
                    'image' => 1,
                ));
                Item::setItemOption(
                    array(
                        'name'   => 'price', 
                        'label'  => 'Option price', 
                        'type'   => '', 
                        'className'  => 'datetime', 
                        'tab'    => 'general', 
                        'format-text' => 'number', 
                    ),
                    array(
                        'name'   => 'seo_keyword',
                        'label'  => 'Seo keyword',
                        'type'   => 'textarea',
                    ),
                    array(
                        'name'   => 'seo_description',
                        'label'  => 'Seo description',
                        'type'   => 'textarea',
                    ),
                    array(
                        'name'   => 'seo_title',
                        'label'  => 'Seo title',
                        'type'   => 'text',
                    )
                );
            },
            'nav-menu' => 'General/Item',
        ),
        'texthtml' => array(
            'file' => 'controllers/Texthtml',
            'class'=> 'Texthtml',
            'call' => function($argument){
                Texthtml::setTexthtmlType(
                    array(1, 'System keyword'),
                    array(2, 'Static')
                );
                /*
                Texthtml::setTexthtmlType(1, 'system keyword');
                */
                Texthtml::setDataType();
                Texthtml::disable(array(
                    'editname' => 0,
                    'btnAdd' => 0,
                    'btnEdit' => 0,
                    'btnDel' => 0,
                    'btnUpdate' => 0,
                    'data_type' => 0,
                    'description' => 0,
                    'order' => 0,
                    'image' => 0,
                ));
                /*Texthtml::callEdit(0);*/
            },
            'nav-menu' => "General/Text html",
        ),
    );