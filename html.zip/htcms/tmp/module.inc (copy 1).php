<?php 
use Htlib\Mvc\View;
use Htlib\Db\DbTable;
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;

return array(
    'route' => array(
        '/' => array('file'=>'controllers/Index', 'class'=>'Index'),
        '' => function() {
            View::header404(__DIR__.'/views/404.html');
        },
        'logout' => function(){
            Session::delete('user_id');
            Session::destroy();
            header('location: /'.View::getDir().'/');
        },
        '/^([a-z])([a-zA-Z0-9]+)(\/([a-z][a-zA-Z0-9\-_]+))?/' => function ($all, $m1, $m2, $has_act='', $action='') {
	        $controller = strtoupper($m1) . $m2;
            $action = preg_replace_callback('/[\-_]+([a-z])/i', function($m){return strtoupper($m[1]);}, $action);
	        $file = realpath(__DIR__.'/controllers/'.$controller.'.php');
	        if ($file && is_readable($file) && is_file($file)) {
                if (empty($has_act)) {
                    return array('file' => 'controllers/'.$controller, 'class'=> $controller);
                } else {
    	        	return array(
    	        		'file' => 'controllers/'.$controller, 
    	        		'class'=> $controller,
                        'arg'=>array(
                            'module'=>$controller, 
                            'function'=>$action,
                        ),
    	        	);
                }
	        }
	        exit(empty($has_act) ? ('<pre>Controller:'.$controller) : ('<pre>Controller:'.$controller." \nAction:".$action));
	    },
	    
    ),
    'initmodule'=> function ($route, $dir, $mod, $act, $other) {
        View::setViewDir(__DIR__.'/views'); 
        View::setBaseUrl(Gf::url($dir));
        View::setDir($dir);
        View::setModule($mod);
        View::setAction($act);
        new DbTable(Configuration::getDb());
        Gf::urlMatch('/dir/module/action', array('dir'=>$dir, 'module'=>'-', 'action'=>'-'));
        Gf::pagination(function($page_base_url, $total, $page_row=10, $page=0){
            $paging = paging($total, $page_row, $page);
            $pagination['first'] = $paging['total'] > 1 ? array(
                'url'=>$page_base_url.'/page/1',
                'page' => 1,
            ) : false;
            $pagination['last'] = $paging['total'] > 1 ? array(
                'url'=>$page_base_url.'/page/'.$paging['total'],
                'page' => $paging['total'],
            ) : false;
            for ( $i = $paging['from']; $i <= $paging['to']; $i++ ) {
                if ( $i == $page ) {
                    $pagination['pages'][] = array(
                            'url' => $page_base_url.'/page/'.$i,
                            'page' => $i, 
                            'current' => 1,
                        );
                } else {
                    $pagination['pages'][] = array(
                            'url' => $page_base_url.'/page/'.$i,
                            'page' => $i, 
                        );
                }
            }
            return $pagination;
        });
        Gf::redirect(function($url='') {
            if (is_array($url)) {
                header('location:'.Gf::url($url));
            } else {
                header('location:'.Gf::url('admin/'.trim($url, '/')));
            }
            exit();
        });
    }
);
