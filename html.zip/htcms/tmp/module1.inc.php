<?php 
use Htlib\Mvc\View;
use Htlib\Db\DbTable;
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;

return array(
    array(
        'route' => Gf::getRoute(__DIR__.'/config.inc.php', array( 
            '/' => array('file' => 'controllers/Index', 'class' => 'Index'),
            ''  => function($all, $dir='', $has_ca='', $ctrl='', $act=''){
                $file = __DIR__.'/controllers/'. strtoupper(substr($ctrl, 0, 1)) . substr($ctrl, 1) . '.php';
                if (file_exists($file) && is_readable($file) && is_file($file)) {
                    return array('file' => $file, 'class' => $ctrl);
                }
                header('Content-type: application/json');
                exit(json_encode(array('denied'=>1, 'message'=>'Not permission', 'controller'=>$ctrl, 'action'=>$act)));
            }
        )),
        'permission' => function($r, $m, $a) { 
            if (Session::get('user_id')) {
                return empty($a) ? ($m.'/') : ($m.'/'.$a.'/'); 
            } elseif ($m!='login' && (Gf::httpx('json')||Gf::is_POST())) {
                //$this->printJson(array('logout'=>1, 'message'=>'Please sign in'));
                header('Content-type: application/json');
                exit(json_encode(array('logout'=>1, 'message'=>'Please sign in')));
            } elseif ($m!='login') {
                header('location:'.Gf::url(array('module'=>'login', 'action'=>''), 1));
            }
        }
    ),
    function ($_this, $dir, $mod, $act, $other) {
        // print_r($_this);exit();
        Configuration::setConfig_route_path(__DIR__.'/config.inc.php');
        /*$config = new Configuration();
        $config->config_route_path = __DIR__.'/config.inc.php';*/
        /*
        $cfgPath = file_exists(__DIR__.'/config.inc.php') && is_readable(__DIR__.'/config.inc.php') && is_file(__DIR__.'/config.inc.php') ? (__DIR__.'/config.inc.php'):'';
        Htlib\Mvc\Controller::setCfgPath($cfgPath);
        if (Gf::httpx('js-template-engine') || @$_GET['format']=='template') {
            $_this->route = array(''=>array(
                'file'=>'controllers/Index', 
                'class'=>'Index', 
                'call'=>'Index::callTemplate', 
                'arg'=>array(
                    'mod'=>trim($mod,'- '), 
                    'act'=>trim($act,'- ')
                )
            ));
        }*/
        View::setViewDir(__DIR__.'/views'); 
        View::setCompileDir(NULL);
        View::setBaseUrl(Gf::url($dir));
        View::setDir($dir);
        View::setModule($mod);
        View::setAction($act);
        new DbTable(Configuration::getDb());
        Gf::urlMatch('/dir/module/action', array('dir'=>$dir, 'module'=>'-', 'action'=>'-'));
        Gf::pagination(function($page_base_url, $total, $page_row=10, $page=0){
            $paging = paging($total, $page_row, $page);
            $pagination['first'] = $paging['total'] > 1 ? array(
                'url'=>$page_base_url.'/page/1',
                'page' => 1,
            ) : false;
            $pagination['last'] = $paging['total'] > 1 ? array(
                'url'=>$page_base_url.'/page/'.$paging['total'],
                'page' => $paging['total'],
            ) : false;
            for ( $i = $paging['from']; $i <= $paging['to']; $i++ ) {
                if ( $i == $page ) {
                    $pagination['pages'][] = array(
                            'url' => $page_base_url.'/page/'.$i,
                            'page' => $i, 
                            'current' => 1,
                        );
                } else {
                    $pagination['pages'][] = array(
                            'url' => $page_base_url.'/page/'.$i,
                            'page' => $i, 
                        );
                }
            }
            return $pagination;
        });
        Gf::redirect(function($url='') {
            if (is_array($url)) {
                header('location:'.Gf::url($url));
            } else {
                header('location:'.Gf::url('admin/'.trim($url, '/')));
            }
            exit();
        });
    }
);
