<?php 
use Htlib\Mvc\View;
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;

View::addEngine('L', function($param) {
    return '<?php echo Gf::L(\''.$param.'\')?>';
});
View::addEngine('A', function($param) {
    return '<?php echo Gf::args(\''.addcslashes($matches[2], "'").'\') ?>';
});
View::addEngine('URL', function($param) {
    $arrayItems = explode(',', $param);
    $arrayItems = array_map('trim', $arrayItems);
    $arrayItemsStr = array();
    foreach ($arrayItems as $v) { 
        $i = strpos($v, ':');
        if ($i>0) {
            $k = substr($v, 0, $i);
            if ($k) {
                $k = preg_match('/^\$/', $k) ? $k : ('\'' .trim($k, ' \'"'). '\'');
                $v = trim(substr($v, $i+1));
                $v = preg_match('/^\$/', $v) ? $v : ('\'' .trim($v, '"'."'"). '\'');
                $arrayItemsStr[] = $k. '=>'. $v;
            }
        }
    }
    return '<?php echo Gf::url(array('.implode(', ', $arrayItemsStr).')) ?>';
});

Gf::urlMatch('/dir/module/action', array('dir'=>$dir, 'module'=>'index', 'action'=>'-'));
Gf::lang(function($lang=''){
    $langCfg = Configuration::getLang();
    if ($lang && is_array($langCfg) && isset($langCfg[$lang])) {
        return $lang;
    } elseif (is_array($langCfg)) {
        return key($langCfg);
    } else {
        return '';
    }
});
Gf::pagination(function($total, $pageRow=10, $page=0, $lang=''){
    $paging = paging($total, $pageRow, $page);
    /*print_r($paging);
    exit();*/
    if ($lang) {
        $pagination['setLang'] = $lang;
    }
    $pagination['first'] = $paging['total'] > 1 ? 1 : '#';
    $pagination['last'] = $paging['total'] > 1 ? $paging['total'] : '#';
    for ( $i = $paging['from']; $i <= $paging['to']; $i++ ) {
        if ( $i == $page ) {
            $pagination['pages'][] = array(
                    'page' => $i, 
                    'current' => 1,
                );
        } else {
            $pagination['pages'][] = array(
                    'page' => $i, 
                    'current' => 0,
                );
        }
    }

    return $pagination;
});
Gf::R(function($module, $action){
    $role = G::role();
    return is_object($role)&&method_exists($role, 'check') ? $role->check($module, $action) : false;
});
Gf::getImage(function($url){
    /*echo(Configuration::getUpload('dir').'/'.$url);*/
    if (is_readable($f = Configuration::getUpload('dir').'/'.$url) && is_file($f)) {
        return '<img src="'.Configuration::getUpload('url').'/'.$url.'" />';
    } else {
        return '<img role="no-image" src="/AdminLTE/imgs/no-image.png">';
    }
});

/* on before call controller */
function before_call_controller(array $argument=NULL)
{
    if (!empty($argument)) {
        foreach ($argument as $key => $value) {
            
        }
    }
}

function before_call_banner(array $argument=NULL)
{
    isset($argument['position']) && Banner::setPosition($argument['position']);
    isset($argument['disableFeild']) && Banner::setDisable($argument['disableFeild']);
}


function before_call_menu(array $argument=NULL)
{
    isset($argument['content-type']) && Menu::setMenuType($argument['content-type']);
    isset($argument['disableFeild']) && Menu::setDisableFeild($argument['disableFeild']);
    isset($argument['menuOption']) && Menu::setMenuOption($argument['menuOption']);
    /*G::starttime(time());
    Menu::setMenuType($argument['content-type']);
    Menu::setDisableFeild('order', 'display');

    Menu::setMenuOption(
        array(
            'name'   => 1,
            'label'  => 'Meta keyword',
            'type'   => 'text',
            'className'  => '',
        ),
        array(
            'name'   => 2,
            'label'  => 'Meta description',
            'type'   => 'textarea',
        ),
        array(
            'name'   => 3,
            'label'  => 'Social image',
            'type'   => 'image',
            'className'  => '',
        ),
        array(
            'name'   => 4,
            'label'  => 'option 4',
            'type'   => 'select',
            'className'  => 'class-abc',
            'option' => array(
                'value-1' => '111111111111111111',
                'value-2' => '222222222222222222',
                'value-3' => '333333333333333333',
                'value-4' => '444444444444444444',
                'value-5' => '555555555555555555',
            ),
        )
    );*/
}

function before_call_category(array $argument=NULL)
{
    isset($argument['content-type']) && Category::setCategoryType($argument['content-type']);
    isset($argument['prefixUrl']) && Category::setPrefixUrl($argument['prefixUrl']);
    isset($argument['maxLevel']) && Category::setMaxLevel($argument['maxLevel']);
    isset($argument['categoryOption']) && Category::setCategoryOption($argument['categoryOption']);
    isset($argument['itemType']) && Category::setItemType($argument['itemType']);

    /*Category::setPrefixUrl('/category/');
    Category::setCategoryType(array(
        1 => 'Article',
        2 => 'Product',
        5 => 'Coupon',*/
        /*2 => 'Ban điều hành',
        'Top' => array(
            3 => 'Left', 
            4 => 'Right', 
        ),*/
    /*));*/
    /*Category::setMaxLevel(array(
        1=>6, 2=>6, 3=>1, 4=>1
    ));
    Category::setCategoryOption(
        array(
            'name'   => 1,
            'label'  => 'Meta keyword',
            'type'   => 'text',
            'className'  => '',
        ),
        array(
            'name'   => 2,
            'label'  => 'Meta description',
            'type'   => 'textarea',
        ),
        array(
            'name'   => 3,
            'label'  => 'Social image',
            'type'   => 'image',
            'className'  => '',
        ),
        array(
            'name'   => 4,
            'label'  => 'Apparance',
            'type'   => 'select',
            'className'  => 'class-abc',
            'option' => array(
                'value-1' => '111111111111111111',
                'value-2' => '222222222222222222',
                'value-3' => '333333333333333333',
                'value-4' => '444444444444444444',
                'value-5' => '555555555555555555',
            ),
        )
    );*/
    /*Category::setItemType(array(
        2 => 'Article',*/
        /*1 => 'Static',*/
    /*));*/
    /*Form::disableFeild('item_relate[0]');*/
}

function before_call_texthtml(array $argument=NULL)
{
    isset($argument['content-type']) && Texthtml::setType($argument['content-type']);
    isset($argument['disableFeild']) && Texthtml::disable($argument['disableFeild']);
    isset($argument['action-edit']) && Texthtml::callEdit($argument['action-edit']);
}
function before_call_item(array $argument=NULL)
{
    isset($argument['content-type']) && Item::setItemType($argument['content-type']);
    isset($argument['prefixUrl']) && Item::setPrefixUrl($argument['prefixUrl']);
    isset($argument['itemGroup']) && Item::setTypeGroup($argument['itemGroup']);
    isset($argument['categoryType']) && Item::setCategoryType($argument['categoryType']);
    isset($argument['categoryMaxLevel']) && Item::setMaxLevel($argument['categoryMaxLevel']);
    isset($argument['multiCategory']) && Item::setMultiCategory($argument['multiCategory']);
    isset($argument['itemOption']) && Item::setItemOption($argument['itemOption']);

    /*Item::setCategoryTypeId(1);
    Item::setMaxLevel(2);
    Item::setMultiCategory(false);
    
    Item::setTypeGroup(array(
        2 => 'Article',
        1 => 'Static',
    ));
    Item::setItemOption(
        array(
            'name'   => 1,
            'label'  => 'Ngày đăng',
            'type'   => 'text',
            'className'  => 'datetime',
        ),
        array(
            'name'   => 2,
            'label'  => 'Tên tác giả',
            'type'   => 'text',
        ),
        array(
            'name'   => 3,
            'label'  => 'Nguồn',
            'type'   => 'text',
        ),
        array(
            'name'   => 3,
            'label'  => 'Nhuận bút',
            'type'   => 'text',
        )
    );*/
    /*Item::setCategoryType(array(
        1 => 'Article',*/
        /*'Ban điều hành' => array(2 => ''), */
        /*1 => 'News', */
    /*));*/
}
/*Texthtml::setType(array(
                    1 => 'block',
                    2 => 'Static',
                ));
                Texthtml::edit(1);
                Texthtml::setDisable(array(
                    'order'=>true,
                    'form-order' => true,
                ));*/