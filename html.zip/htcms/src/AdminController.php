<?php 
use Htlib\Mvc\Controller;
use Htlib\Mvc\View;
use Htlib\Db\Expr; 
use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;
use Model\User;
use Model\Permission;

/**
* AdminController
*/
class AdminController extends Controller
{
    function __construct($argument)
    {
        // print_r(HT::get()->{1});exit();
        $user_id = (int)Session::get('user_id');
        parent::__construct($argument);
        if ($user_id) {
            $path = preg_match('/^index\//', $argument['permission']) ? '/' : preg_replace('/(all|add|edit|del|index|-)\/$/', '', $argument['permission']);
            $user = new User();
            $user->update(array('last_access'=>$path), 'id='.$user_id);
            $this->addView('issa', $user_id==1?1:0);
            $this->addView('status', 1);
            $this->addView('data', NULL);
            $this->addView('rows', array());
            $this->addView('offsetRow', 0);
            $this->addView('pagination', array());
            $this->addView('user', $user->info($user_id));
            
            $this->addView('uploadDir', Configuration::getUpload()->dir);
            $this->addView('uploadUrl', Configuration::getUpload()->url);
            
            $this->addView('disableFeild', (object)self::getDisableFeild());
            $this->addView('prefixUrl', self::getPrefixUrl());
            $this->addView('sufixUrl', self::getSufixUrl());
            $this->addView('layout', (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) ? false:true);
            
            if ($user_id == 1) {
                $query = $user->select('id, name, path', 'permissions p')
                    ->leftJoin('permissions b', 'b.parent_id=p.id', array('act'=>new Expr('GROUP_CONCAT', 'b.name')))
                    ->where(not_null('p.usage'))
                    ->where('p.guard=', 'mod')
                    ->group('p.id');
            } else {
                $query_act = $user->select('name, parent_id', 'permissions')
                ->innerJoin('permission_role', 'permissions.id=permission_role.permission_id', 'role_id');
                $query = $user->select('id, name, path', 'permissions p')
                    ->leftJoin(array('b'=>$query_act), 'b.parent_id=p.id', array('act'=>new Expr('GROUP_CONCAT', 'b.name')))
                    ->innerJoin('permission_role pr', 'p.id=pr.permission_id')
                    ->innerJoin('user_role ur', 'pr.role_id=ur.role_id')
                    ->innerJoin('users u', 'u.id=ur.user_id')
                    ->where(not_null('p.usage'))
                    ->where('p.guard=', 'mod')
                    ->where(not_null('u.usage'))
                    ->where('u.id=', $user_id)
                    ->group('p.id');
            }
            $permission = $query->fetch('path');
            // print_r($permission);
            $permission['/'] = array('id'=>0, 'name'=>'', 'act'=>'all');
            if (isset($permission[$path])) {
                // echo $path;
                $a = explode(',', @$permission[$path]['act']);
                // print_r($a);
                $this->addView('allow_add', $this->views->issa || in_array('all', $a) || in_array('add', $a));
                $this->addView('allow_edit', $this->views->issa || in_array('all', $a) || in_array('edit', $a));
                $this->addView('allow_del', $this->views->issa || in_array('all', $a) || in_array('del', $a));
                // echo $this->views->allow_add;
            } else {
                $this->printJson((object)array('denied'=>1, 'message'=>'Not permission.'));
            }
            foreach ($permission as $key => $v) {
                $this->addView('role_'.$v['name'], !0);
            }
            // exit();
        }
    }

    function view($template, array $data=NULL)
    {
        if (Gf::httpx('js-template-engine')||(isset($_GET['format'])&&$_GET['format']=='template')) {
            return new View($template, $data);
        }
        return new View('layouts/admin', $data);
    }
}