<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Mvc\Role;
use Htlib\Configuration;
use Htlib\Session;

class Category extends DbTable
{
    public 
        $lang = 'vi',
        $type = 0,
        $maxLevel = 5;

    function add($data)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $name = @$data['name'];
        $title = @$data['title'];
        $description = @$data['description'];
        /*print_r($description);
        exit();*/
        $menu = $this->parseSchema('categories', $data);
        @$menu['category_type'] = $this->type;
        $menu['time_create'] = time();
        $menu['user_create'] = (int)Session::get('user_id');
        isset($data['icon']) && is_array($menu['icon']) && ($menu['icon'] = @$menu['icon'][0]);
        $this->update('categories', array('url'=>(object)'NULL'), 'url=\''.@$data['url'].'\' AND parent_id='.(int)@$data['parent_id'].' AND category_type='.(int)@$menu['category_type']);
        $rs = $this->insert('categories', $this->parseSchema('categories', $menu));
        $id = $rs ? $this->lastid() : 0;
        if ($id) {
            foreach ($name as $key => $value) {
                if (isset($langCfg[$key])) {
                    $this->insert('category_lang', array(
                        'category_id' => $id, 
                        'lang' => $key, 
                        'name' => $value, 
                        'title' => $title[$key], 
                        'description' => $description[$key], 
                    ));
                }
            }
            if (is_array(@$data['option'])) {
                foreach ($data['option'] as $oid => $value) {
                    if ($value && is_array($value)) {
                        foreach ($value as $key => $v) {
                            $this->insert('category_option', array(
                                'category_id' => $id, 
                                'option_id' => $oid, 
                                'lang' => $key, 
                                'value' => is_array($v) ? array_shift($v) : $v
                            ));
                        }
                    }
                }
            }
        }
        return $id;
    }

    function save($id, $data)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $name = @$data['name'];
        $title = @$data['title'];
        $description = @$data['description'];
        $data['user_id'] = (int)Session::get('user_id');
        $data['category_type'] = $this->type;
        $data['display'] = (int)@$data['display'];
        $data['time_update'] = time();
        isset($data['icon']) && is_array($data['icon']) && ($data['icon'] = @$data['icon'][0]);
        $dataUpdate = $this->parseSchema('categories', $data);
        $this->update('categories', array('url'=>(object)'NULL'), 'url=\''.$data['url'].'\' AND parent_id='.$data['parent_id'].' AND category_type='.$data['category_type']);
        $rs = $this->update('categories', $dataUpdate, "id = $id");
        if ($rs) {
            foreach ($name as $key => $value) {
                if (isset($langCfg[$key])) {
                    $this->insert('category_lang', array(
                        'category_id' => $id, 
                        'lang' => $key, 
                        'name' => $value, 
                        'title' => $title[$key], 
                        'description' => $description[$key], 
                    ), array(
                        'name' => $value,
                        'title' => $title[$key], 
                        'description' => $description[$key], 
                    ));
                    /*echo $this->__toString();*/
                }
            }
            /*exit();*/
            if (is_array(@$data['option'])) {
                foreach ($data['option'] as $oid => $value) {
                    if ($value && is_array($value)) {
                        foreach ($value as $key => $v) {
                            if (isset($langCfg[$key])) {
                                $this->insert('category_option', array(
                                    'category_id' => $id, 
                                    'option_id' => $oid, 
                                    'lang' => $key, 
                                    'value' => is_array($v) ? array_shift($v) : $v
                                ), array(
                                    'value'=>is_array($v) ? array_shift($v) : $v
                                ));
                            }
                        }
                    }
                }
            }
        }
        if ($rs) {
            return true;
        }
        return false;
    }

    function del($id)
    {
        $sql = "UPDATE `{categories}` a
        INNER JOIN `{categories}` b
        ON a.`parent_id`=b.`id`
        SET a.`parent_id`=b.`parent_id`
        WHERE b.`id`=$id";
        $rs = $this->query($sql);
        if (!$rs->error) {
            $role = new Role();
            $rs = $this->update('categories', array(
                    'usage'=> (object)'NULL',
                    'time_update'=>time(),
                    'user_id'=>(int)Session::get('user_id'),
            ), "`id`=$id");
            return $rs;
        }
        return false;
    }

    function get($where='')
    {
        is_array($this->lang) && reset($this->lang);
        $lang = is_array($this->lang) ? key($this->lang) : $this->lang;
        empty($lang) && ($lang='vi');
        $sql = $this->select('*', 'categories c')
        ->leftJoin('category_lang cl', 'c.id=cl.category_id AND cl.lang=\''.$lang.'\'', array('name', 'lang'=>(object)('IF(LENGTH(cl.lang)>0, cl.lang, \''.$lang.'\')')))
        ->where(not_null('c.usage'))
        ->where('c.category_type=', $this->type)
        ->order('c.parent_id, c.order');
        if (is_array($where)) {
            foreach ($where as $value) {
                $sql->where($value);
            }
        }

        $rs = $this->query($sql)->fetch('parent_id', true);
        return $this->treeRow($rs);
    }
    
    function getOnce($id)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $sql = $this->select("*", 'categories')->where('id=', $id);
        $rs = $this->query($sql)->fetch();
        if($rs){
            $data = $rs[0];

            $sql = $this->select('*', 'category_lang')
            ->where('category_id=', $id)
            ->where('lang IN (\''.implode('\', \'', array_keys($langCfg)).'\')');
            $rs = $this->query($sql)->fetch();
            if (!empty($rs) && is_array($rs)) {
                foreach ($rs as $r) {
                    $data['name'][$r['lang']] = $r['name'];
                    $data['title'][$r['lang']] = $r['title'];
                    $data['description'][$r['lang']] = $r['description'];
                }
            }
            /*$data['name'] = $this->query($sql)->fetchOnce('name', 'lang');*/

            $sql = $this->select('option_id, lang, value', 'category_option')
            ->where('category_id=', $id)
            ->where('lang IN (\''.implode('\', \'', array_keys($langCfg)).'\')');
            $rs = $this->query($sql)->fetch();
            if (!empty($rs) && is_array($rs)) {
                foreach ($rs as $r) {
                    $data['option'][$r['option_id']][$r['lang']] = $r['value'];
                }
            }
            return $data;
        }
        return array();
    }

    function getTreeOption($edit_id='')
    {
        is_array($this->lang) && reset($this->lang);
        $lang = is_array($this->lang) ? key($this->lang) : $this->lang;
        $select = $this->select('id, parent_id', 'categories m')
            ->leftJoin('category_lang ml', 'ml.category_id=m.id', 'name')
            ->where(not_null('usage'))
            ->where('`lang`='."'$lang'")
            ->where('m.id<>', $edit_id)
            ->where('`category_type`=', $this->type)
            ->order('parent_id ASC, order, id');
        $rs = $this->query($select)->fetch('parent_id', true);
        $return = $this->treeOption($rs);
        return $return;
    }

    private function treeRow($ar, $p=0, $lv=1){
        $a = array();
        if (($this->maxLevel==0 || $lv <= $this->maxLevel) && isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])) {
            foreach ($ar[$p] as $i=>$row) {
                $a[] = array(
                    'id'=>$row['id'],
                    'lv'=>$lv,
                    'name'=>$row['name'],
                    'lang'=>$row['lang'],
                    'url'=> isset($row['url']) ? $row['url'] : null,
                    'icon'=>isset($row['icon']) ? $row['icon'] : null,
                    'display'=>$row['display'],
                    'order'=>$row['order'],
                    'haschild'=>!empty($ar[$row['id']])&&is_array($ar[$row['id']]) ? count($ar[$row['id']]) : 0,
                    'parent'=>$p,
                );
                if (isset($ar[$row['id']])) {
                    $a = array_merge($a, $this->treeRow($ar, $row['id'], $lv+1));
                }
            }
        }
        return $a;
    }

    private function treeOption($ar, $p=0, $lv=1){
        $a = array();
        if (($this->maxLevel ==0 || $lv < $this->maxLevel) && isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])) {
            foreach ($ar[$p] as $i=>$row) {
                $a[] = array(
                    'id'=>$row['id'],
                    'level'=>$lv,
                    'name'=>$row['name'],
                );
                if (isset($ar[$row['id']])) {
                    $a = array_merge($a, $this->treeOption($ar, $row['id'], $lv+1));
                }
            }
        }
        return $a;
    }

    public function getOptionValue($option_id='', $category_id='')
    {
        $sql = $this->select('option_id, category_id, value', 'category_option');
        (strlen($option_id)>0) && $sql->where("option_id IN ($option_id)");
        (strlen($category_id)>0) && $sql->where("category_id IN ($category_id)");
        $rs = $this->query($sql)->fetch();
        $data = array();
        if (is_array($rs)) {
            foreach ($rs as $r) {
                $data[$r['option_id']][$r['category_id']] = $r['value'];
            }
        }
        return $data;
    }
}