<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Mvc\Role;
use Htlib\Configuration;
use Htlib\Session;

class Menu extends DbTable
{
    public 
        $lang = 'vi',
        $type = 0,
        $maxLevel = 5;

    function add($data)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $name = @$data['name'];
        $menu = $this->parseSchema('menus', $data);
        @$menu['menu_type'] = $this->type;
        $menu['time_create'] = time();
        $menu['user_create'] = (int)Session::get('user_id');
        isset($data['icon']) && is_array($menu['icon']) && ($menu['icon'] = @$menu['icon'][0]);
        $this->update('menus', array('url'=>(object)'NULL'), 'url=\''.@$data['url'].'\' AND parent_id='.(int)@$data['parent_id'].' AND menu_type='.(int)@$menu['menu_type']);
        $rs = $this->insert('menus', $this->parseSchema('menus', $menu));
        $id = $rs ? $this->lastid() : 0;
        if ($id) {
            foreach ($name as $key => $value) {
                if (isset($langCfg[$key])) {
                    $this->insert('menu_lang', array(
                        'menu_id' => $id, 
                        'lang' => $key, 
                        'name' => $value, 
                    ));
                }
            }
            if (is_array(@$data['option'])) {
                foreach ($data['option'] as $oid => $value) {
                    if ($value && is_array($value)) {
                        foreach ($value as $key => $v) {
                            $this->insert('menu_option', array(
                                'menu_id' => $id, 
                                'option_id' => $oid, 
                                'lang' => $key, 
                                'value' => is_array($v) ? array_shift($v) : $v
                            ));
                        }
                    }
                }
            }
        }
        return $id;
    }

    function save($id, $data)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $name = @$data['name'];
        $data['user_id'] = (int)Session::get('user_id');
        $data['menu_type'] = $this->type;
        $data['display'] = (int)@$data['display'];
        $data['time_update'] = time();
        isset($data['icon']) && is_array($data['icon']) && ($data['icon'] = @$data['icon'][0]);
        $dataUpdate = $this->parseSchema('menus', $data);
        $this->update('menus', array('url'=>(object)'NULL'), 'url=\''.$data['url'].'\' AND parent_id='.$data['parent_id'].' AND menu_type='.$data['menu_type']);
        $rs = $this->update('menus', $dataUpdate, "id = $id");
        if ($rs) {
            foreach ($name as $key => $value) {
                if (isset($langCfg[$key])) {
                    $this->insert('menu_lang', array(
                        'menu_id' => $id, 
                        'lang' => $key, 
                        'name' => $value, 
                    ), array(
                        'name' => $value,
                    ));
                }
            }
            if (is_array(@$data['option'])) {
                foreach ($data['option'] as $oid => $value) {
                    if ($value && is_array($value)) {
                        foreach ($value as $key => $v) {
                            if (isset($langCfg[$key])) {
                                $this->insert('menu_option', array(
                                    'menu_id' => $id, 
                                    'option_id' => $oid, 
                                    'lang' => $key, 
                                    'value' => is_array($v) ? array_shift($v) : $v
                                ), array(
                                    'value'=>is_array($v) ? array_shift($v) : $v
                                ));
                            }
                        }
                    }
                }
            }
        }
        if ($rs) {
            return true;
        }
        return false;
    }

    function del($id)
    {
        $sql = "UPDATE `{menus}` a
        INNER JOIN `{menus}` b
        ON a.`parent_id`=b.`id`
        SET a.`parent_id`=b.`parent_id`
        WHERE b.`id`=$id";
        $rs = $this->query($sql);
        if (!$rs->error) {
            $role = new Role();
            $rs = $this->update('menus', array(
                    'usage'=> (object)'NULL',
                    'time_update'=>time(),
                    'user_id'=>(int)Session::get('user_id'),
            ), "`id`=$id");
            return $rs;
        }
        return false;
    }

    function get($key='')
    {
        is_array($this->lang) && reset($this->lang);
        $lang = is_array($this->lang) ? key($this->lang) : $this->lang;
        $select = $this->select('id, parent_id, display, order, url, icon', 'menus m');
        $select->leftJoin('menu_lang ml', "ml.menu_id = m.id AND lang='$lang'", array('name', 'lang'=>(object)('IF(LENGTH(ml.lang)>0, ml.lang, \''.$lang.'\')')));
        $select->where(not_null('usage'));
        if($this->type)
            $select->where('menu_type='.$this->type);
        strlen($key)>0 && $select->where("ml.name like '%".str_ireplace(' ', '%', $key)."%'");
        $select->order('parent_id ASC, order, id');
        $rs = $this->query($select)->fetch('parent_id', true);
        return $this->treeRow($rs);
    }
    
    function getOnce($id)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $sql = $this->select("*", 'menus')->where('id=', $id);
        $rs = $this->query($sql)->fetch();
        if($rs){
            $data = $rs[0];

            $sql = $this->select('name, lang', 'menu_lang')
            ->where('menu_id=', $id)
            ->where('lang IN (\''.implode('\', \'', array_keys($langCfg)).'\')');
            $data['name'] = $this->query($sql)->fetchOnce('name', 'lang');

            $sql = $this->select('option_id, lang, value', 'menu_option')
            ->where('menu_id=', $id)
            ->where('lang IN (\''.implode('\', \'', array_keys($langCfg)).'\')');
            $rs = $this->query($sql)->fetch();
            if (!empty($rs) && is_array($rs)) {
                foreach ($rs as $r) {
                    $data['option'][$r['option_id']][$r['lang']] = $r['value'];
                }
            }
            return $data;
        }
        return array();
    }

    function getTreeOption($edit_id='')
    {
        is_array($this->lang) && reset($this->lang);
        $lang = is_array($this->lang) ? key($this->lang) : $this->lang;
        $select = $this->select('id, parent_id', 'menus m')
            ->leftJoin('menu_lang ml', 'ml.menu_id=m.id', 'name')
            ->where(not_null('usage'))
            ->where('`lang`='."'$lang'")
            ->where('m.id<>', $edit_id)
            ->where('`menu_type`=', $this->type)
            ->order('parent_id ASC, order, id');
        $rs = $this->query($select)->fetch('parent_id', true);
        $return = $this->treeOption($rs);
        return $return;
    }

    private function treeRow($ar, $p=0, $lv=1){
        $a = array();
        if (($this->maxLevel==0 || $lv <= $this->maxLevel) && isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])) {
            foreach ($ar[$p] as $i=>$row) {
                $a[] = array(
                    'id'=>$row['id'],
                    'lv'=>$lv,
                    'name'=>$row['name'],
                    'lang'=>$row['lang'],
                    'url'=>$row['url'],
                    'icon'=>$row['icon'],
                    'display'=>$row['display'],
                    'order'=>$row['order'],
                    'haschild'=>count(@$ar[$row['id']]),
                    'parent'=>$p,
                );
                if (isset($ar[$row['id']])) {
                    $a = array_merge($a, $this->treeRow($ar, $row['id'], $lv+1));
                }
            }
        }
        return $a;
    }

    private function treeOption($ar, $p=0, $lv=1){
        $a = array();
        if (($this->maxLevel ==0 || $lv < $this->maxLevel) && isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])) {
            foreach ($ar[$p] as $i=>$row) {
                $a[] = array(
                    'id'=>$row['id'],
                    'level'=>$lv,
                    'name'=>$row['name'],
                );
                if (isset($ar[$row['id']])) {
                    $a = array_merge($a, $this->treeOption($ar, $row['id'], $lv+1));
                }
            }
        }
        return $a;
    }

    public function getOptionValue($option_id='', $menu_id='')
    {
        $sql = $this->select('option_id, menu_id, value', 'menu_option');
        (strlen($option_id)>0) && $sql->where("option_id IN ($option_id)");
        (strlen($menu_id)>0) && $sql->where("menu_id IN ($menu_id)");
        $rs = $this->query($sql)->fetch();
        $data = array();
        if (is_array($rs)) {
            foreach ($rs as $r) {
                $data[$r['option_id']][$r['menu_id']] = $r['value'];
            }
        }
        return $data;
    }
}