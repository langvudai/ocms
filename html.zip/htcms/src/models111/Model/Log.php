<?php 
namespace Model;
use htlib\db\DbTable;

class Log extends DbTable
{
    function getLog($page=1, $count=10, $from='', $to=''){
        $sql = $this->select(array('id', 'username', 'password', 'iplogin', 'timelogin', 'status', 'D'=>(object)"DATE_FORMAT(timelogin,'%Y-%m-%d')", 'T'=>(object)"TIME_FORMAT(timelogin,'%H:%i:%s')"), 'user_login');
        $from && $sql->where("timelogin>='$from'");
        $to && $sql->where("timelogin<='$to'");
        $sql->order('timelogin DESC')
        ->limit($count, $page);
        /*echo $sql->__toString();*/
        $rows = $this->query($sql)->fetch();
        $total = $this->query($sql->getCount())->fetch();
        return array('rows'=>$rows, 'count'=>$total);
    }
    
    function delLog($timeRange, $to){
        return $this->delete('user_login', $timeRange==0 ? 1 : ('timelogin>=DATE_SUB(NOW(), INTERVAL '.$timeRange.')'));
    }
}