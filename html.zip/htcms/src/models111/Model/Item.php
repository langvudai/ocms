<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Mvc\Role;
use Htlib\Configuration;
use Htlib\Session;

class Item extends DbTable
{
    public
        $_wCategory,
        $type = 0, 
        $lang = 'vi';
    function setLang ($lang)
    {
        if ($lang) {
            $this->lang = $lang;
        } elseif(is_array(Configuration::getLang())) {
            $this->lang = key(Configuration::getLang());
        }
    }
    
    public function whereCategory(array $categoryId)
    {
        $this->_wCategory = $categoryId;
        return $this;
    }

    public function get(array $where = NULL, $order='', $limit='10', $page=1)
    {
        is_array($this->lang) && reset($this->lang);
        $lang = is_array($this->lang) ? key($this->lang) : $this->lang;
        empty($lang) && ($lang='vi');
        /*print_r($where);*/
        $sql = $this->select('*', 'items i')
        ->leftJoin('item_lang il', 'i.id = il.item_id AND il.lang='."'$lang'", 'name')
        ->leftjoin('url_alias ua', 'i.id = ua.id and ua.type=\'I\'', 'url')
        ->where(not_null('i.usage'))
        ->where('item_type=', $this->type)
        ->order('i.order, i.id DESC')
        ->limit($limit, $page);
        ;
        empty($where['category']) || $sql->innerJoin('item_category ic', 'i.id=ic.item_id')->where('ic.category_id=', $where['category']);
        empty($where['keyword']) || $sql->where('il.`name` LIKE \'%'.$where['keyword'].'%\'');
        empty($where['filter_is_hot']) || $sql->where('i.is_hot=1');
        empty($where['filter_is_new']) || $sql->where('i.is_new=1');
        for ($i=0; $i<10; $i++) {
            empty($where['filter_is_chk'.$i]) || $sql->where('i.chk'.$i.'=1');
        }
        /*exit($sql->__toString());*/
        $rows = $this->query($sql)->fetch('id');
        /*print_r(array_keys($rows));*/
        $count = $this->query($sql->getCount())->fetch();
        /*** options ***/
        $sql = $this->select(array('item_id', (object)"'options'", 'value'), 'item_option o')
        ->innerJoin('item_option_field of', 'o.option_id=of.id', 'field_name')
        ->where('item_id IN ('.implode(',', array_keys($rows)).')')
        ->where('lang=', $lang);
        /*echo $sql->__toString();*/
        $options = $this->query($sql)->fetchArrayKey('value');
        /*print_r($options);
        exit();*/
        if (is_array($options) && is_array($rows)) {
            $rows = array_replace_recursive($rows, $options);
        }
        /*print_r($rows);
        exit();*/
        /*$sql = $this->select('item_id, option_id, value, lang', 'item_option')
        ->where('item_id IN (\''.implode(',', array_keys($rows)).'\')')
        ->where('lang=', $lang);
        $option = $this->query($sql)->fetch('item_id', true);
        foreach ($rows as $key => $value) {
            $rows[$key]['options'] = $option[$key];
        }*/
        return array('rows' => array_values($rows), 'count' => $count);


        /*empty($this->_wCategory) ? $sql->from('items i', 'id, code, date, status, order, display, is_hot, is_new, chk0, chk1, chk2, chk3, chk4, chk5, chk6, chk7, chk8, chk9, time_create, time_update, user_id, user_create') : $sql->from('items i', 'id, code, date, status, display, is_hot, is_new, chk0, chk1, chk2, chk3, chk4, chk5, chk6, chk7, chk8, chk9, time_create, time_update, user_id, user_create');
        $sql->leftJoin('item_lang il', "i.id = il.item_id AND il.lang='".$this->lang."'", array('name', 'lang'=>(object)('IF(LENGTH(il.lang)>0, il.lang, \''.$this->lang.'\')')))
        ->leftJoin('item_category ic', "i.id = ic.item_id", array('category_id' => (object)"GROUP_CONCAT(DISTINCT `ic`.`category_id`)"))
        ->leftjoin('url_alias ua', "i.id = ua.id and ua.type='I'", 'url')
        ->where(not_null('i.usage'))
        ->where('item_type=', $this->type)
        ->group('i.id')
        ->limit($limit, $page);
        empty($where) || $sql->where($where);
        empty($order) ? (empty($this->_wCategory) ? $sql->order('i.order, i.id DESC'):$sql->order('wic.order, i.id DESC')) : $sql->order($order);
        empty($this->_wCategory) || is_array($this->_wCategory) && $sql->innerJoin('item_category wic', 'i.id = wic.item_id', 'order')->where('wic.category_id IN ('. implode(',', $this->_wCategory) .')' );
        echo($sql->__toString());
        exit();
        $rows = $this->query($sql)->fetch('id');
        $count = $this->query($sql->getCount())->fetch();
        $sql = $this->select('item_id, option_id, value, lang', 'item_option')
        ->where('item_id IN (\''.implode(',', array_keys($rows)).'\')')
        ->where('lang=', $this->lang);
        $option = $this->query($sql)->fetch('item_id', true);
        foreach ($rows as $key => $value) {
            $rows[$key]['options'] = $option[$key];
        }
        $rows = array_values($rows);
        return array('rows' => $rows, 'count' => $count);*/
    }
    
    public function getOnce($id) 
    {
        $sql = $this->select('*', 'items i')
        ->leftJoin('url_alias ua', "ua.id = i.id AND ua.type='I'", 'url')
        ->leftJoin('item_category ic', "ic.item_id = i.id", array('category_id'=>(object)"GROUP_CONCAT(DISTINCT(`category_id`))"))
        ->leftJoin('item_tag_add it', "it.item_id = i.id", array('tag_id'=>(object)"GROUP_CONCAT( DISTINCT(`tag_id`))"))
        ->where(not_null('usage'))
        ->where('i.id=', $id)
        ;
        /*echo $sql->__toString();*/
        $rs = $this->query($sql)->fetch();
        if ($rs) {
            $data = $rs[0];
            $data['tag_id'] = explode(',', $data['tag_id']);
            if (isset($data['category_id'])) {
                $data['category_id'] = array_fill_keys(explode(',', $data['category_id']), 1);
            }

            $sql = $this->select('image_url', 'item_images')
            ->where('item_id=', $id);
            $rs = $this->query($sql)->fetchOnce('image_url');
            $data['image'] = $rs;

            $arrLang = get_object_vars(Configuration::getLang());
            if(is_array($arrLang)) {
                $lang = '\''.implode('\', \'', array_keys($arrLang)).'\'';

                $sql = $this->select('*', 'item_lang')
                ->where('item_id=', $id)
                ->where('lang IN ('.$lang.')');
                $rs = $this->query($sql)->fetch();
                /*print_r($rs);exit();*/
                if ($rs) {
                    foreach ($rs as $row) {
                        $l = $row['lang'];
                        unset($row['item_id']);
                        unset($row['lang']);
                        if (is_array($row)) {
                            foreach ($row as $c=>$v) {
                                if (isset($data[$c]) && is_array($data[$c])) {
                                    $data[$c][$l] = $v;
                                } else {
                                    $data[$c] = array($l=>$v);
                                }
                            }
                        }
                    }
                }
                /*print_r($data);print_r($rs);exit();*/

                $sql = $this->select('option_id, value, lang', 'item_option')
                ->where('item_id=', $id)
                ->where('lang IN ('.$lang.')');
                $rs = $this->query($sql)->fetch();
                $data['option'] = array();
                if (is_array($rs)) {
                    foreach ($rs as $v) {
                        $data['option'][$v['option_id']][$v['lang']] = $v['value'];
                    }
                }
            }
            return $data;
        }
        return;
    }
    
    public function getCategory($item=0)
    {
        $sql = "select category_id from `{item_category}` where item_id=$item_id";
    }
    
    public function add($data)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $data['time_create'] = time();
        $data['user_create'] = (int)Session::get('user_id');
        if (!@$data['code']) {
            $data['code'] = (object)'NULL';
        }
        $data['item_type'] = $this->type;
        $rs = $this->insert('items', $this->parseSchema('items', $data));
        /*echo $this->__toString().';';*/
        $id = $rs ? $this->lastid() : 0;
        
        if ($id) {
            if (isset($data['item_relate']) && is_array($data['item_relate'])) {
                $sql = 'INSERT IGNORE `item_relate`(`item_id`, `item_id_relate`) VALUES (' . $id . ', '.implode('), (' . $id . ', ', (int)$data['item_relate']) . ')';
                /*echo $sql.';';*/
                $this->query($sql);
            }

            if (isset($data['filename']) && is_array($data['filename'])) {
                foreach ($data['filename'] as $value) {
                    $this->insert('item_images', array(
                        'item_id'=>$id, 
                        'image_url'=>$value
                    ));
                    /*echo $this->__toString().';';*/
                }
            }
            if (isset($data['category_id']) && is_array($data['category_id'])) {
                foreach ($data['category_id'] as $value) {
                    $this->insert('item_category', array(
                        'item_id'=>$id, 
                        'category_id'=>$value
                    ));
                    /*echo $this->__toString().';';*/
                }
            }
            
            foreach ($langCfg as $lang => $valueText) {
                $this->insert('item_lang', array(
                    'item_id' => $id,
                    'lang' => $lang,
                    'name' => $data['name'][$lang],
                    'summary' => $data['summary'][$lang],
                    'content' => $data['content'][$lang],
                ));
                /*echo $this->__toString().';';*/
                if (is_array($data['option'])) {
                    $option_names = array_keys($data['option']);
                    $sql = $this->select()->from('item_option_field', 'id, field_name')->where('field_name IN (\''.implode('\', \'', $option_names).'\')');
                    $option_ids = $this->query($sql)->fetchOnce('id', 'field_name');
                    if (array_diff_key($data['option'], $option_ids)) {
                        $this->query('INSERT IGNORE `{item_option_field}` (`field_name`) VALUES (\''.implode('\', \'', $option_names).'\')');
                        $sql = $this->select()->from('item_option_field', 'id, field_name')->where('field_name IN (\''.implode('\', \'', $option_names).'\')');
                        $option_ids = $this->query($sql)->fetchOnce('id', 'field_name');
                    }
                    foreach ($data['option'] as $option_name => $value) {
                        if (isset($value[$lang])) {
                            $dataOption['item_id'] = $id;
                            /*$dataOption['option_id'] = $optionId;*/
                            $dataOption['option_id'] = $option_ids[$option_name];
                            $dataOption['lang'] = $lang;
                            $dataOption['value'] = $value[$lang];
                            $this->insert('item_option', $dataOption);
                            /*echo $this->__toString().';';*/
                        }
                    }
                }
            }
        }
        return $id;
    }
    
    public function save($id, $data) 
    {
        $langCfg = Configuration::getLang();
        $data['user_id'] = (int)Session::get('user_id');
        $data['time_update'] = time();
        $data['code'] = (isset($data['code']) && strlen($data['code'])>0) ? $data['code'] : (object)"NULL";
        $data['display'] = (int)@$data['display'];
        $data['is_hot'] = (int)@$data['is_hot'];
        $data['is_new'] = (int)@$data['is_new'];
        for ($i=0; $i <10 ; $i++) { 
            $data['chk'.$i] = (int)@$data['chk'.$i];
        }
        $data['item_type'] = $this->type;
        $rs = $this->update('items', $this->parseSchema('items', $data), "id = $id");
        /*echo $this->__toString().';';*/
        if ($rs) {
            /*if (isset($data['item_relate']) && is_array($data['item_relate'])) {
                $this->delete('item_relate', 'item_id='.$id);
                $sql = 'INSERT IGNORE `item_relate`(`item_id`, `item_id_relate`) VALUES (' . $id . ', '.implode('), (' . $id . ', ', $data['item_relate']) . ')';
                $this->query($sql);
            }*/

            if (isset($data['filename']) && is_array($data['filename'])) {
                $this->delete('item_images', 'item_id='.$id);
                foreach ($data['filename'] as $value) {
                    $this->insert('item_images', array(
                        'item_id'=>$id, 
                        'image_url'=>$value
                    ));
                    /*echo $this->__toString().';';*/
                }
            }
            if (isset($data['category_id']) && is_array($data['category_id'])) {
                $this->delete('item_category', 'item_id='.$id);
                foreach ($data['category_id'] as $value) {
                    $this->insert('item_category', array(
                        'item_id'=>$id, 
                        'category_id'=>$value,
                    ));
                    /*echo $this->__toString().';';*/
                }
            }
            /*print_r($data['content']);*/
            foreach ($langCfg as $lang => $valueText) {
                $this->insert('item_lang', array(
                    'item_id' => $id,
                    'lang' => $lang,
                    'name' => $data['name'][$lang],
                    'summary' => $data['summary'][$lang],
                    'content' => $data['content'][$lang],
                ), array(
                    'name' => $data['name'][$lang],
                    'summary' => $data['summary'][$lang],
                    'content' => $data['content'][$lang],
                ));
                /*echo $this->__toString().";\n";*/
            }
            /*exit();*/
            if (is_array($data['option'])) {
                $option_names = array_keys($data['option']);
                $sql = $this->select()->from('item_option_field', 'id, field_name')->where('field_name IN (\''.implode('\', \'', $option_names).'\')');
                $option_ids = $this->query($sql)->fetchOnce('id', 'field_name');
                if (array_diff_key($data['option'], $option_ids)) {
                    $this->query('INSERT IGNORE `{item_option_field}` (`field_name`) VALUES (\''.implode('\', \'', $option_names).'\')');
                    $sql = $this->select()->from('item_option_field', 'id, field_name')->where('field_name IN (\''.implode('\', \'', $option_names).'\')');
                    $option_ids = $this->query($sql)->fetchOnce('id', 'field_name');
                }
                /*$this->delete('item_option', 'item_id='.$id);*/
                /*echo $this->__toString().';';*/
                /*print_r($data['option']);*/
                reset($langCfg);
                /*print_r($data['option']);*/
                foreach ($langCfg as $lang => $valueText) {
                    foreach ($data['option'] as $option_name => $value) {
                        if (isset($value[$lang])) {
                            $dataOption['item_id'] = $id;
                            /*$dataOption['option_id'] = $optionId;*/
                            $dataOption['option_id'] = $option_ids[$option_name];
                            $dataOption['lang'] = $lang;
                            $dataOption['value'] = $value[$lang];
                            $this->insert('item_option', $dataOption, array('value'=>$value[$lang]));
                            echo $this->__toString().';';
                        }
                    }
                }
            }
            /*exit();*/
            return true;
        }
        return false;
    }

    public function orderCategory($category_id, $item_id, $order)
    {
        $this->update('item_category', array('order'=>$order), 'category_id='.$category_id.' AND item_id='.$item_id);
    }
    
    private function setOptionValue($id, $option) 
    {
        if (is_array($option)) {
            $option_names = array_keys($data['option']);
            $sql = $this->select()->from('item_option_field', 'id, field_name')->where('field_name IN (\''.implode('\', \'', $option_names).'\')');
            $option_ids = $this->query($sql)->fetchOnce('id', 'field_name');
            if (array_diff_key($data['option'], $option_ids)) {
                $this->query('INSERT IGNORE `{item_option_field}` (`field_name`) VALUES (\''.implode('\', \'', $option_names).'\')');
                $sql = $this->select()->from('item_option_field', 'id, field_name')->where('field_name IN (\''.implode('\', \'', $option_names).'\')');
                $option_ids = $this->query($sql)->fetchOnce('id', 'field_name');
            }
            foreach ($option as $option_name => $value) {
                if (is_array($value)) {
                    foreach ($value as $lang => $v) {
                        $this->insert('item_option', array(
                            'item_id' => $id,
                            /*'option_id'=>$option_name, */
                            'option_id'=>$option_ids[$option_name], 
                            'lang' => $lang,
                            'value' => $v,
                        ), array('value' => $v));
                    }
                } else {
                    $this->insert('item_option', array(
                        'item_id' => $id,
                        /*'option_id'=>$option_id, */
                        'option_id'=>$option_ids[$option_name], 
                        'lang' => $this->lang,
                        'value' => $value,
                    ), array('value' => $value));
                }
            }
        }
    }
    
    public function del($id, $deleted=0)
    {
        if($deleted)
        {
            $this->delete('item_lang', "item_id = $id");
            $this->delete('item_images', "item_id = $id");
            $this->delete('item_category', "item_id = $id");
            $this->delete('items', "id = $id");
        }
        else 
        {
            $this->update('items', array('usage'=>(object)'NULL', 'user_id'=>(int)Session::get('user_id')), "id=$id");
        }
        return true;
    }
    
    public function getOptionValue($option_id='', $item_id='')
    {
        $sql = $this->select('option_id, item_id, value', 'item_option');
        (strlen($option_id)>0) && $sql->where("option_id IN ($option_id)");
        (strlen($item_id)>0) && $sql->where("item_id IN ($item_id)");
        $rs = $this->query($sql)->fetch();
        $data = array();
        if(is_array($rs))
        {
            foreach ($rs as $r) 
            {
                $data[$r['option_id']][$r['item_id']] = $r['value'];
            }
        }
        return $data;
    }

    public function getOption(array $itemId)
    {
        $sql = $this->select('item_id, option_id, value', 'item_option')
        ->where("option_id IN (".implode(', ', $itemId).")")
        ->where('lang=\''.$this->lang.'\' OR lang=\''.key(Configuration::getLang()).'\'' );
        /*echo $sql->__toString();*/
        return $this->query($sql)->fetchArrayKey('value');
    }

    public function duplicate($id)
    {
        $cols = array_keys($this->getTableSchema('items'));
        $key = array_search('id', $cols);
        $cols[$key] = (object)'NULL';
        $key = array_search('code', $cols);
        $cols[$key] = (object)'NULL';
        $key = array_search('time_create', $cols);
        $cols[$key] = (object)time();
        $key = array_search('user_create', $cols);
        $cols[$key] = (object)Session::get('user_id');
        $key = array_search('timestamp', $cols);
        $cols[$key] = (object)'NULL';
        $sql = $this->select($cols, 'items tb')->where('tb.id=', $id);
        $this->query( 'INSERT INTO `{items}` '.$this->select($cols, 'items tb')->where('tb.id=', $id)->__toString() );
        $insert_id = $this->lastId();
        if ($insert_id) {
            $cols = array_keys($this->getTableSchema('item_lang'));
            $key = array_search('id', $cols);
            $cols[$key] = (object)'NULL';
            $key = array_search('item_id', $cols);
            $cols[$key] = (object)$insert_id;
            $langCfg = Configuration::getLang();
            foreach ($langCfg as $lang => $valueText) {
                $this->query( 'INSERT INTO `{item_lang}` '.$this->select($cols, 'item_lang tb')->where('lang=', $lang)->where('tb.item_id=', $id)->__toString() );
            }

            $this->query('INSERT INTO `{item_option}` (SELECT NULL, '.$insert_id.', `option_id`, `lang`, `value` FROM `{item_option}` AS b WHERE b.item_id='.$id.')');
            $this->query('INSERT INTO `{item_images}` (SELECT NULL, '.$insert_id.', `image_url`, `order` FROM `{item_images}` AS b WHERE b.item_id='.$id.')');
            $this->query('INSERT INTO `{item_relate}` (SELECT NULL, '.$insert_id.', `item_id_relate` FROM `{item_relate}` AS b WHERE b.item_id='.$id.')');
            $this->query('INSERT INTO `{item_tag_add}` (SELECT NULL, '.$insert_id.', `tag_id` FROM `{item_tag_add}` AS b WHERE b.item_id='.$id.')');
            return $insert_id;
        }
        return 0;
    }
}