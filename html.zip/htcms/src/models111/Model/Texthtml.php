<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Mvc\Role;
use Htlib\Configuration;
use Htlib\Session;

class Texthtml extends DbTable
{
    public $type = 0, $lang = 'vi';
    
    public function get($key='', $limit=10, $page=0)
    {
        $sql = $this->select('*', 'texthtml t')
            ->leftJoin('url_alias ua', "ua.id=t.id AND ua.type='T'", 'url')
            ->where(not_null('t.usage'))
            ->where('t.type=', $this->type)
            ->limit($limit, $page);
        if ($key) {
            $key = str_ireplace(' ', '%', $key);
            $sql->where("name LIKE N'%$key%' OR description LIKE N'%$key%'");
        }
        $rows = $this->query($sql)->fetch('id');
        $total = $this->query($sql->getCount())->fetch();
        $sql = $sql = $this->select('texthtml_id, key, lang, value', 'texthtml_content tc')
        ->innerJoin('texthtml t', 't.id=tc.texthtml_id')
        ->where('t.id IN ('.implode(',', array_keys($rows)).')')
        ->where('t.data_type IN (\'text\', \'image\')');
        $rs = $this->query($sql)->fetchArrayKey('value');
        foreach ($rs as $key => $value) {
            if (is_array($rows[$key])) {
                $rows[$key]['content'] = $value;
            }
        }
        return array(
            'rows' => array_values($rows),
            'total'=> $total, 
        );
    }
    
    public function getOnce($id)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $sql = $this->select('*', 'texthtml')
        ->leftJoin('url_alias ua', "ua.id=texthtml.id AND ua.type='T'", 'url')
        ->where(not_null('texthtml.usage'))
        ->where('texthtml.id=', $id);
        $rs = $this->query($sql)->fetch();
        if ($rs) {
            $data = $rs[0];
            $sql = $this->select('key, lang, value', 'texthtml_content')
            ->where('texthtml_id=', $id);
            $data['content'] = $this->query($sql)->fetchArrayKey('value');
            return $data;
        }
        return array();
    }

    public function getContent($id)
    {
        $sql = $this->select('key, lang, value', 'texthtml_content')
        ->where('texthtml_id=', $id);
        $rs = $this->query($sql)->fetchArrayKey('value');
        $sql = $this->select('url', 'url_alias')->where('type=\'T\'')->where('id=', $id)->limit(1);
        $url = $this->query($sql)->fetch();
        return empty($url)||!is_array($url) ? $rs : array_replace($rs, $url[0]);
    }

    public function getByName($name)
    {
        $langCfg = get_object_vars(Configuration::getLang());
        $sql = $this->select('*', 'texthtml')
            ->leftJoin('url_alias ua', "ua.id=texthtml.id AND ua.type='T'", 'url')
            ->where(not_null('usage'))
            ->where('name=', $name);
        $rs = $this->query($sql)->fetch();
        if ($rs) {
            $data = $rs[0];
            $sql = $this->select('key, lang, value', 'texthtml_content')
            ->where('texthtml_id=', $id);
            $data['content'] = $this->query($sql)->fetchArrayKey('value');
            return $data;
        }
        return array();
    }

    public function add($data)
    {
        $arlang = Configuration::getLang();
        $data['lang'] = empty($this->lang) ? key($arlang) : $this->lang;
        $data['type'] = $this->type;
        $data['user_create'] = (int)Session::get('user_id');
        $data['time_create'] = time();
        $rs = $this->insert('texthtml', $this->parseSchema('texthtml', $data));
        return $rs ? $this->lastId() : 0;
    }

    public function save($id, $data)
    {
        $data = $this->parseSchema('texthtml', $data);
        $rs = $this->update('texthtml', $data, "id=$id");
        return $rs;
    }

    public function saveContent($id, $data)
    {
        $cfg = new Configuration();
        $langCfg = $cfg->lang;
        $dflang = key($langCfg);
        @$url = trim($data['url'], '# ');
        unset($data['url']);
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                foreach ($langCfg as $lang=>$t) {
                    $this->insert('texthtml_content', array(
                        'texthtml_id' => $id, 
                        'key' => $key, 
                        'lang' => $lang,
                        'value' => $value[$lang], 
                    ), array('value' => $value[$lang]));
                }
            } elseif (is_scalar($value)) {
                $this->insert('texthtml_content', array(
                    'texthtml_id' => $id, 
                    'key' => $key, 
                    'lang' => $dflang,
                    'value' => $value, 
                ), array('value' => $value));
            }
        }
        if (!empty($url)) {
            $this->insert('url_alias', array(
                'type' => 'T', 
                'id' => $id, 
                'url' => $url, 
                'type_id' => $this->type, 
            ), array('url' => $url));
        }
        return true;
    }

    public function del($id)
    {
        if ($this->update('texthtml', array('usage'=>(object)'NULL'), "id=$id")) {
            return true;
        }
        return false;
    }
}