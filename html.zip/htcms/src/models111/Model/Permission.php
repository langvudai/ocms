<?php 
namespace Model;

use Htlib\Db\DbTable;
use Htlib\Db\ArrayAssoc;
use Htlib\Configuration;

class Permission extends DbTable
{
    function getRole($selectall=false)
    {
        if($selectall)
        {
            $sql = $this->select('*', 'roles');
            return $this->query($sql)->fetch('id');
        }
        else
        {
            $sql = $this->select("id, name", 'roles');
            return $this->query($sql)->fetchOnce('name', 'id');
        }
    }

    function getOnceRole($id)
    {
        $sql = $this->select('*', 'roles')->where('id=', $id);
        $rs = $this->query($sql)->fetch();
        return isset($rs[0]) && is_array($rs[0]) ? $rs[0] : array();
    }

    function getName($id)
    {
        $sql = "SELECT name FROM `{roles}` WHERE id=$id";
        return $this->query($sql)->fetchOnce('name');
    }
    
    function getPermission($role_id=0)
    {
        $sql = $this->select('module, action, enable', 'permissions p')
        ->innerJoin('roles r', 'r.id=p.role_id', 'name');
        if ($role_id) {
            $sql->where('r.id=', $role_id);
        }
        $rs = $this->query($sql)->fetch();
        return $rs;
    }

    function get($id)
    {
        $sql = $this->select('module, action', 'permissions')->where('role_id=', $id);
        $result = $this->query($sql)->fetchArrayKey();
        return $result;
    }

    function getContentType($id)
    {
        $sql = $this->select('module, type_id', 'permission_content_type')->where('role_id=', $id);
        $result = $this->query($sql)->fetch();
        return $result;
    }

    function set($role_id, array $mod, array $permission)
    {
        $this->delete('permissions', '`role_id`='.$role_id);
        if ($mod) {
            foreach ($mod as $mod_id=>$value) {
                if (isset($permission[$mod_id])) {
                    $this->insert('permissions', array('role_id'=>$role_id, 'module'=>$mod_id, 'action'=>''));
                    foreach ($permission[$mod_id]['action'] as $act => $text) {
                        $v = (int)$mod[$mod_id][$act];
                        $this->insert('permissions', array('role_id'=>$role_id, 'module'=>$mod_id, 'action'=>$act, 'enable'=>$v));
                    }
                }
            }
            $this->update('roles', array('timestamp'=>(object)'CURRENT_TIMESTAMP'), 'id='.$role_id);
        }
        return true;
    }

    function setContentType($role_id, array $typeId, array $permission) {
        $this->delete('permission_content_type', '`role_id`='.$role_id);
        if ($typeId) {
            foreach($typeId as $mod=>$value) {
                if (is_array($value)) {
                    foreach ($value as $id) {
                        $this->insert('permissions', array('role_id'=>$role_id, 'module'=>$mod, 'type_id'=>$id));
                    }
                } else {
                    $this->insert('permissions', array('role_id'=>$role_id, 'module'=>$mod, 'type_id'=>$value));
                }
            }
            $this->update('roles', array('timestamp'=>(object)'CURRENT_TIMESTAMP'), 'id='.$role_id);
        }
        return true;
    }

    function add($name, $description)
    {
        $rs = $this->insert('roles', array('name'=>$name, 'description'=>$description));
        if ($rs) {
            return $this->lastId();
        }
        return 0;
    }

    function edit($id, $name, $description)
    {
        $rs = $this->update('roles', array('name'=>$name, 'description'=>$description), "id=$id");
        return $rs;
    }

    function delRole($id)
    {
        $this->delete('permissions', 'role_id='.$id);
        /*echo $this->__toString();*/
        $this->delete('user_role', 'role_id > 1 AND role_id='.$id);
        /*echo $this->__toString();*/
        $this->delete('roles', 'id > 1 AND id='.$id);
        /*echo $this->__toString();*/
        /*exit();*/
        return true;
    }

    function getToNav($role_id)
    {
        if ($role_id>0) {
            $sql = $this->select()
            ->from('permissions p', 'module, action, enable')
            ->where('role_id=', $role_id);
            return $this->query($sql)->fetchArrayKey('enable');
        }
        return false;
    }

    private function getActionNav($kmod, array $acts)
    {
        $ar = array();
        foreach ($acts as $key => $value) {
            if (!in_array($key, array('add', 'edit', 'del'))) {
                $ar[] = array(
                    'text'=> $value,
                    'mod' => $kmod,
                    'act' => $key,
                    'url' => $kmod.'/'.$key,
                    'active' => $kmod==@$_GET['mod']&&$key==@$_GET['act'] ? 'class=active' : '',
                );
            }
        }
        return $ar;
    }
    function getNav()
    {
        $cfg = new Configuration();
        $nav = $cfg->nav;
        $hash1 = $_REQUEST['mod'] ? ('#'. $_REQUEST['mod']) : '';
        global $hash2;
        $hash2 = $_REQUEST['act'] ? ($hash1 .'/'. $_REQUEST['act']) : $hash1;
        /*print_r($nav);*/
        foreach ($nav as $key => $value) {
            if (@$value->childs) {
                $array_keys = array_keys($value->childs);
                $join_url = ' '.implode(' ', $array_keys);
                if ($hash1 && stripos($join_url, $hash1)) {
                    $nav[$key]->active = 'class="active"';
                }
                $nav[$key]->childs = array_map(function($key, $value) {
                    global $hash2;
                    $value->url = $key;
                    if ($hash2 && trim($key,'/')==trim($hash2,'/')) {
                        $value->active = 'class="active"';
                    }
                    if (!empty($value->childs)&&is_array($value->childs)) {
                        $value->childs = array_map(function($key, $value) {
                            $value->url = $key;
                            return $value;
                        }, array_keys($value->childs), array_values($value->childs)); 
                    }
                    return $value;
                }, $array_keys, array_values($value->childs));
            } else {
                if ($hash1==$value->url) {
                    $nav[$key]->active = 'class="active"';
                }
            }
        }
        return $nav;
    }
}