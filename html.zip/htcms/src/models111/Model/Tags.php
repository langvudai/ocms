<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Db\DbTable;
use Htlib\Configuration;

class Tags extends DbTable
{
    public $lang='vi', $type=0;
    function add($data)
    {
        /*print_r($data); */
        $role = new Role();
        $this->insert('item_tags', $this->parseSchema('item_tags', $data));
        return $this->lastId();
    }

    function addTagsItem($item_id, $tags)
    {
        if (is_array($tags)) {
            $tags = array_map('trim',$tags);
            $sql = 'INSERT IGNORE `{item_tags}`(`name`) VALUES ';
            $sql.= '(N\''.implode('\'),(N\'', $tags).'\')';
            $this->query($sql);
        } else {
            $tags = preg_replace('/(\s*,\s*)/', "','", $tags);
            $tags = explode(',', $tags);
            $sql = 'INSERT IGNORE `{item_tags}`(`name`) VALUES ';
            $sql.= '(N\''.implode('\'),(N\'', $tags).'\')';
            $this->query($sql);
        }
        $sql = 'INSERT IGNORE `{item_tag_add}`(`item_id`, `tag_id`) 
        (SELECT '.$item_id.' , id FROM `{item_tags}` WHERE `name` IN (N\''.implode('\',N\'', $tags).'\'))'; 
        $this->query($sql);
    }

    function saveTagsItem($item_id, $tags)
    {
        if (is_array($tags)) {
            $tags = array_map('trim',$tags);
            $sql = 'INSERT IGNORE `{item_tags}`(`name`) VALUES ';
            $sql.= '(N\''.implode('\'),(N\'', $tags).'\')';
            $this->query($sql);
        } else {
            $tags = preg_replace('/(\s*,\s*)/', "','", $tags);
            $tags = explode(',', $tags);
            $sql = 'INSERT IGNORE `{item_tags}`(`name`) VALUES ';
            $sql.= '(N\''.implode('\'),(N\'', $tags).'\')';
            $this->query($sql);
        }
        $this->delete('item_tag_add', 'item_id='.$item_id);
        $sql = 'INSERT IGNORE `{item_tag_add}`(`item_id`, `tag_id`) 
        (SELECT '.$item_id.' , id FROM `{item_tags}` WHERE `name` IN (N\''.implode('\',N\'', $tags).'\'))'; 
        $this->query($sql);
    }

    function get($field='*')
    {
        $sql = $this->select($field, 'item_tags');
        $rs = $this->query($sql)->fetch();
        return $rs ? $rs : array();
    }

    function getTags()
    {
        
    }
}