<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Mvc\Role;
use Htlib\Session;

class Banner extends DbTable
{
    public $position=0;
    public static function test($a)
    {
        return 'tt'.$a;
    }


    function get(array $where=null, $limit=10, $page=0, $sort='')
    {
        $sql = $this->select('*', 'banners')
        ->where(not_null('usage'))
        ->where('position=', $this->position);
        if($where){
            $sql->where($where);
        }
        if($sort){
            $sql->order($sort);
        }
        else
        {
            $sql->order('order');
        }
        $sql->limit($limit, $page);
        /*echo $sql->__toString();exit();*/
        $data['rows'] = $this->query($sql)->fetch();
        $data['total'] = $this->query($sql->getCount())->fetch();
        return $data;
    }

    function add($data)
    {
        global $USER;
        @$category = $data['category'];
        isset($data['filename']) && ($data['filename'] = "".@$data['filename'][0]."");
        $data['user_id'] = Session::get('user_id'); 
        $data['user_create'] = Session::get('user_id'); 
        $data['time_create'] = time();
        $data = $this->parseSchema('banners', $data);
        $rs = $this->insert('banners', $data);
        $id = $this->lastid();
        if($id && is_array($category)){
            $ins = array();
            foreach ($category as $value) {
                $ins[] = "$id, $value";
            }
            $this->query("INSERT IGNORE banner_category VALUES (".implode("), (", $ins).")");
        }
        return $id;
    }

    function save($id, $data)
    {
        global $USER;
        isset($data['filename']) && ($data['filename'] = "".@$data['filename'][0]."");
        @$category = $data['category'];
        $data['user_id'] = Session::get('user_id'); 
        $data = $this->parseSchema('banners', $data);
        $rs = $this->update('banners', $data, "id = $id");
        /*echo $this->__toString();*/
        if($rs)
        {
            if(is_array($category))
            {
                $this->delete('banner_category', "banner=$id");
                $ins = array();
                foreach ($category as $value) 
                {
                    $ins[] = "$id, $value";
                }
                $this->query("INSERT IGNORE banner_category VALUES (".implode("), (", $ins).")");
            }
            return true;
        }
        else 
            return false;
    }

    function del($id)
    {
        $rs = $this->update('banners', array('usage'=>(object)"null", 'user_id'=>Session::get('user_id')), "id = $id");
        /*echo $this->__toString();*/
        if($rs)
            return true;
        else 
            return false;
    }

    function getOnce($id)
    {
        $sql = $this->select('*', 'banners')->where("id = ",$id);
        $rs = $this->query($sql)->fetch();
        if(count($rs))
        {
            $data = $rs[0];
            $data['category'] = array();
            $sql = "select category from `{banner_category}` where banner = ".$id;
            $rs = $this->query($sql)->fetch();
            if(is_array($rs))
            foreach ($rs as $value) 
            {
                $data['category'][] = $value['category'];
            }
            return $data;
        }
        return null;
    }
}