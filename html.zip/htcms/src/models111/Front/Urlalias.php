<?php 
namespace Front;

use Htlib\Db\DbTable;
use Htlib\Configuration;

class Urlalias extends DbTable 
{
    private static $_prototype=array();

    function __construct($argument='')
    {
        $url = trim($argument, '/');
        parent::__construct();
        if($url)
        {
            /*$urlAliasDir = Configuration::getUrlAliasDir();
            if($urlAliasDir)
            {
                $file = substr($url, 0, 3).'.url.php';
                $urlCls = new \htlib\db\ArrayAssoc("$urlAliasDir/$file");
                $urlCls->read();
                $value = $urlCls->get($url);
                if(isset($value['type']) && isset($value['type_id']) && isset($value['id']))
                {
                    self::$_prototype['type'] = $rs[0]['type'].$rs[0]['type_id'];
                    self::$_prototype['id'] = $rs[0]['id'];
                    self::$_prototype['url_alias_id'] = $rs[0]['url_alias_id'];
                    return $this;
                }
            }*/

            $sql = $this->select('type, type_id, id, url_alias_id', 'url_alias')->where('`url` REGEXP \'^/*'.$url.'$\'');
            /*echo $sql->toSQLcmd();*/
            $rs = $this->query($sql)->fetch();
            /*print_r($rs);*/
            if($rs)
            {
                /*if(isset($urlCls) && is_a($urlCls, 'htlib\\db\\ArrayAssoc'))
                {
                    $urlCls->set(trim($url, '/'), $rs[0]);
                }
                $urlCls->write();*/
                self::$_prototype['typeid'] = $rs[0]['type'].$rs[0]['type_id'];
                self::$_prototype['type'] = $rs[0]['type'];
                self::$_prototype['id'] = $rs[0]['id'];
                self::$_prototype['url_alias_id'] = $rs[0]['url_alias_id'];
                return $this;
            }
        }
    }

    function __get($name)
    {
        return isset(self::$_prototype[$name]) ? self::$_prototype[$name] : '';
    }

    public static function __callStatic($name, $value)
    {
        if(preg_match('/^get([A-Z_].*)$/', $name, $match))
        {
            return  isset(self::$_prototype[$match[1]]) ? self::$_prototype[$match[1]] : '';
        }
    }

    function getTypeId($url)
    {
        $url = trim($url, '/');
        $urlAliasDir = \Configuration::getUrlAliasDir();
        if($urlAliasDir)
        {
            $file = substr($url, 0, 3).'.url.php';
            $urlCls = new \htlib\db\ArrayAssoc("$urlAliasDir/$file");
            $urlCls->read();
            $value = $urlCls->get($url);
            if(isset($value['type']) && isset($value['type_id']) && isset($value['id']))
            {
                return array('type'=>$value['type'].$value['type_id'], 'id'=>$value['id'], '_id'=>$value['_id']);
            }
        }
        
        $sql = $this->select('type, type_id, id, _id', 'url_alias')->where("`url` REGEXP '^/*$url$'");
        $rs = $this->query($sql)->fetch();      
        if($rs)
        {
            if(isset($urlCls) && is_a($urlCls, 'htlib\\db\\ArrayAssoc'))
            {
                $urlCls->set(trim($url, '/'), $rs[0]);
            }
            $urlCls->write();
            return array('type'=>$rs[0]['type'].$rs[0]['type_id'], 'id'=>$rs[0]['id'], '_id'=>$rs[0]['_id']);
        }
        else
            return array();
    }
}