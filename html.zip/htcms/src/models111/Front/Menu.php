<?php 
namespace Front;

use Htlib\Db\DbTable;

/**
* 
*/
class Menu extends DbTable
{
    private $data;
    public $lang='vi', $type = 0, $condition;

    /**
     *
     * @param string $name type, clearWhere, /^where([A-Z])([A-Za-z0-9_]*)$/, notree
     * 
     */
    public function __call($name, $value)
    {
        if ($name=='type') {
            $this->type = array_shift($value);
        } elseif ($name=='clearWhere') {
            $this->condition = array();
        } elseif ($name=='notree') {
            $this->notTree = empty($value) ? true : !array_shift($value);
        } elseif (preg_match('/^where([A-Z])([A-Za-z0-9_]*)$/', $name, $matches) && !empty($value)) {
            $strWhere = strtolower($matches[1]) .$matches[2]; 
            $strWhere = strtolower(preg_replace('/(([a-z])([A-Z]))/', '\\2.\\3', $strWhere)); 
            if (count($value)==1) {
                $value = array_shift($value);
            }
            if (is_array($value)) { 
                $strWhere = preg_replace('/([a-z][a-z0-9_]*)/i', "`$1`", $strWhere); 
                $value = array_map(function($a) {return trim($a, '"\'');}, $value); 
                $value = array_map(function($a) {return is_numeric($a) ? $a : ("'".addslashes($a)."'");}, $value); 
                $strWhere.= ' IN ('. implode(',', $value).')'; 
                $this->condition[] = $strWhere; 
            } elseif (is_scalar($value)) { 
                $this->condition[] = array($strWhere => $value);
            }
        } 
        return $this; 
    }
    
    /**
     * get list menu
     * @return tree menu
     */
    function get()
    {
        $sql = $this->select('id, parent_id, url, target, url_id, display, icon', 'menus m')
            ->innerJoin('menu_lang ml', 'm.id=ml.menu_id AND ml.lang="'.$this->lang.'"', 'name')
            ->where(not_null('usage'))
            ->where('menu_type=', $this->type)
            ->order('parent_id ASC, order, id');
        if (!empty($this->condition) && is_array($this->condition)) {
            foreach ($this->condition as $condition) {
                $sql->where($condition);
            }
        }
        $data = $this->query($sql)->fetch('parent_id', true);

        /*$sql = $this->select('menu_id, option_id, value', 'menu_option mo')
        ->innerJoin('menus m', 'm.id=mo.menu_id')
        ->where('mo.lang=', $this->lang)
        ->where(not_null('usage'))
        ->where('m.menu_type=', $this->type);
        $rs = $this->query($sql)->fetch();*/
        /*foreach ($rs as $r) 
        {
            $option[$r['menu_id']][$r['option_id']] = $r['value'];
        }*/

        /*$data = $this->treeMenu($data, $option);*/
        $data = $this->treeMenu($data, array());
        return $data;
    }
    
    private function treeMenu($data, $option, $pid=0, $lv=0){
        $array = array();
        if(is_array($data))
        foreach ($data[$pid] as $i=>$r){
            if(isset($data[$r['id']])){
                $array[] = array(
                        'id' => $r['id'],
                        'level' => $lv,
                        'url'=> $r['url'],
                        'target' => $r['target'],
                        'url_id' => $r['url_id'],
                        'display'=> $r['display'],
                        'icon'=> $r['icon'],
                        'name'=> $r['name'],
                        'option'=> isset($option[$r['id']]) ? $option[$r['id']] : NULL,
                        'child'=>$this->treeMenu($data, $option, $r['id'], $lv+1)
                    );
            }
            else{
                $array[] = array(
                        'id' => $r['id'],
                        'level' => $lv,
                        'url'=> $r['url'],
                        'target' => $r['target'],
                        'url_id' => $r['url_id'],
                        'display'=> $r['display'],
                        'icon'=> $r['icon'],
                        'name'=> $r['name'],
                        'option'=> isset($option[$r['id']]) ? $option[$r['id']] : NULL,
                );
            }
        }
            
            
        return $array;
    }
}