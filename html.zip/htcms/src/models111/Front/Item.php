<?php 
namespace Front;

use Htlib\Db\DbTable;

/**
* 
*/
class Item extends DbTable
{
    private $data, $total;
    public $lang='vi', $type = 0, $condition, $itemOption;

    /**
     *
     * @param string $name type, clearWhere, /^where([A-Z])([A-Za-z0-9_]*)$/, notree
     * 
     */
    public function __call($name, $value)
    {
        if ($name=='type') {
            $this->type = array_shift($value);
        } elseif ($name=='clearWhere') {
            $this->condition = array();
        } elseif ($name=='filter') {
            $this->condition[] = array_shift($value);
        } elseif (preg_match('/^where([A-Z])([A-Za-z0-9_]*)$/', $name, $matches) && !empty($value)) {
            $strWhere = strtolower($matches[1]) .$matches[2]; 
            $strWhere = strtolower(preg_replace('/(([a-z])([A-Z]))/', '\\2.\\3', $strWhere)); 
            if (count($value)==1) {
                $value = array_shift($value);
            }
            if (is_array($value)) { 
                $strWhere = preg_replace('/([a-z][a-z0-9_]*)/i', "`$1`", $strWhere); 
                $value = array_map(function($a) {return trim($a, '"\'');}, $value); 
                $value = array_map(function($a) {return is_numeric($a) ? $a : ("'".addslashes($a)."'");}, $value); 
                $strWhere.= ' IN ('. implode(',', $value).')'; 
                $this->condition[] = $strWhere; 
            } elseif (is_scalar($value)) { 
                $this->condition[] = array($strWhere => $value);
            }
        } 
        return $this; 
    }

    /**
     * get list item
     * @param array $categoryId
     * @param int $limit
     * @param int $page
     * @return list item
     */
    function get(array $categoryId=NULL, $limit=0, $page=0, $order='')
    {
        $sql = $this->select('id, item_type, code, date, status, is_hot, is_new, user_id, user_create', 'items i')
            ->innerJoin('item_lang il', 'i.id=il.item_id AND il.lang="'.$this->lang.'"', 'name, summary')
            ->leftJoin('url_alias u', "u.id = i.id AND `type`='I'", 'url')
            ->leftJoin('item_images ii', (object)'ii.id=(SELECT id FROM item_images WHERE item_id=i.id ORDER BY `order` LIMIT 1)', 'image_url')
            ->where('deleted=0 AND display>0')
            ->where('item_type=', $this->type)
            ->order(empty($order) ? 'i.order, i.id DESC' : $order)
            ->limit($limit, $page);
        empty($categoryId) || $sql->where('ic.category_id IN ('.implode(', ', $categoryId).')');
        empty($categoryId) || $sql->innerJoin('item_category ic', 'i.id=ic.item_id', 'category_id');
        if (!empty($this->condition) && is_array($this->condition)) {
            foreach ($this->condition as $condition) {
                $sql->where($condition);
            }
        }
        if (defined('DEBUG') && DEBUG) echo $sql->__toString();
        $data = empty($categoryId) ? array($this->query($sql)->fetch('id')) : $this->query($sql)->fetch('category_id', true);

        $this->total = $this->query($sql->getCount())->fetch();

        return count($categoryId)>1 ? $data : array_shift($data);
    }

    function getTag()
    {
        
    }

    function getOption(array $itemId)
    {
        $sql = $this->select('item_id, option_id, value', 'item_option')
        ->where('lang=', $this->lang)
        ->where('item_id IN ('.implode(', ', $itemId).')');
        $data = $this->query($sql)->fetchArrayKey('value');
        return $data;
    }

    function getOptionByCategory(array $categoryId)
    {
        $sql = $this->select('item_id, option_id, value', 'item_option io')
        ->innerJoin('item_category ic', 'io.item_id=ic.item_id')
        ->innerJoin('items i', 'io.item_id=i.id')
        ->where('item_type=', $this->type)
        ->where('io.lang=', $this->lang)
        ->where('ic.category_id IN ('.implode(', ', $categoryId).')')
        ->group('io.id');
        $data = $this->query($sql)->fetchArrayKey('value');
        /*print_r($data);*/
        return $data;
    }

    function getOnce($itemId)
    {
        $sql = $this->select('*', 'items i')
        ->innerJoin('item_lang il', 'il.item_id=i.id', 'name, summary, content')
        ->where('lang=', $this->lang)
        ->where('deleted=0 OR deleted IS NULL')
        ->where('display>0')
        ->where('item_id=', $itemId);
        /*echo($sql->__toString());*/
        $result = $this->query($sql)->fetch();
        if (!empty($result)) {
            $data = $result[0];
            $sql = $this->select('image_url, item_id', 'item_images')->where('item_id=', $itemId);
            $data['images'] = $this->query($sql)->fetchOnce('image_url');
            $sql = $this->select('option_id, value', 'item_option')->where('lang=', $this->lang)->where('item_id=', $itemId);
            $data['options'] = $this->query($sql)->fetchOnce('value', 'option_id');
            $sql = $this->select('*', 'item_tags t')
            ->innerJoin('item_tag_add it', 'it.tag_id=t.id')
            ->where('item_id=', $itemId);
            $data['tags'] = $this->query($sql)->fetch();
            $sql = $this->select('category_id', 'item_category')->where('item_id=', $itemId);
            $data['category_id'] = $this->query($sql)->fetchOnce('category_id');
            return $data;
        }
        return NULL;
    }
}