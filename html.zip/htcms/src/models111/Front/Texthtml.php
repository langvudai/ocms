<?php 
namespace Front;

use Htlib\Db\DbTable;

/**
* 
*/
class Texthtml extends DbTable
{
    public $lang = 'vi';

    function getByName($name)
    {
        $sql = $this->select('id, type, name, data_type', 'texthtml');
        is_array($name) ? $sql->where('`name` IN (\''.implode("', '", $name).'\')') : $sql->where('name=', $name);
        $sql->where(not_null('usage'))
        ->where('lang=', $this->lang);
        $rs = $this->query($sql)->fetch('name');
        if (is_array($name)) {
            $sql = $this->select('name', 'texthtml t')
            ->innerJoin('texthtml_content tc', 't.id=tc.texthtml_id', array('content'=>(object)"'content'", 'key'=>'key', 'value'=>'value'))
            ->where('lang=', $this->lang)
            ->where('`name` IN (\''.implode("', '", $name).'\')');
            $rsc = $this->query($sql)->fetchArrayKey('value');
            return is_array($rs) && is_array($rsc) ? array_merge_recursive($rs, $rsc) : array();
        } else {
            $data = $rs[0];
            $sql = $this->select('key, value', 'texthtml_content')
            ->where('texthtml_id=', $data['id']);
            $rsc = $this->query($sql)->fetchOnce('value', 'key');
            $data['content'] = $rsc;
            return $data;
        }
    }

    function getByType($type_id){
        $sql = $this->select('id, type, name, data_type', 'texthtml')
        ->where('lang=', $this->lang)
        ->where('type=', $type_id)
        ->where(not_null('usage'))
        ->order('order');
        $rs = $this->query($sql)->fetch('name');
        return $rs;

        $sql = $this->select('id, type, name, data_type, description', 'texthtml')
        ->where('type=', $type_id)
        ->where(not_null('usage'))
        ->where('lang=', $this->lang);
        $rs = $this->query($sql)->fetch('name');
        
        $sql = $this->select('name', 'texthtml t')
        ->innerJoin('texthtml_content tc', 't.id=tc.texthtml_id', array('content'=>(object)"'content'", 'key'=>'key', 'value'=>'value'))
        ->where('lang=', $this->lang)
        ->where(not_null('t.usage'))
        ->where('t.type=', $type_id);
        $rsc = $this->query($sql)->fetchArrayKey('value');
        return array_merge_recursive($rs, $rsc);
    }
}