<?php 
namespace Front;

use Htlib\Db\DbTable;

/**
* 
*/
class Banner extends DbTable
{
    
    public $position = 0;

    /**
     * 
     * @param array | int $position
     * @param array $where
     * @param string $order
     * @return list banner
     */
    function get($position, array $where=NULL, $order='', $limit=0)
    {
        $sql = $this->select('*', 'banners')
        ->where(not_null('usage'))
        ->where('display=1');
        is_array($position) ? $sql->where("position IN (".implode(',', $position).")") : $sql->where("position=", $position);
        if($where)
        {
            foreach ($where as $w)
            {
                $sql->where($w);
            }
        }
        $order ? $sql->order($order) : $sql->order('order, id');
        empty($limit) || $sql->limit($limit);
        /*echo $sql->toSQLcmd();*/
        $data = $this->query($sql)->fetch('position', true);
        /*print_r($data);*/
        return is_array($position) ? $data : $data[$position];
    }

    /**
     * 
     * @param array | int $position
     * @param array | int $categoryId
     * @param array $where
     * @param string $order
     * @return list banner
     */
    function getByCategory($position, $categoryId, array $where=NULL, $order='')
    {
        $sql = $this->select('*', 'banners')
        ->innerjoin('banner_category', "banner=banner_id")
        ->where(not_null('usage'))
        ->where('banner_display>0');
        is_array($position) ? $sql->where('banner_position IN ('.implode(',', $position).')') : $sql->where('banner_position=', $position);
        is_array($category_id) ? $sql->where("category IN(".implode(',', $category_id).")") : $sql->where('category=', $category_id);
        $sql->order("banner_order")->group('banner_id');
        $data = $this->query($sql)->fetch('banner_position', true);
        return (is_array($position) ? $data : $data[$position]);
    }
    /**
     * 
     * @param int $position
     * @param int $categoryType
     * @param array $where
     * @param string $order
     * @return list banner
     */
    function getByCategoryType($position, $categoryType, array $where=NULL, $order='')
    {
        if($position && $categoryType)
        {
            $sql = $this->select('*', 'banners')
            ->innerjoin(array('bc'=>'banner_category'), "bc.banner=banner_id")
            ->innerjoin(array('c'=>'category'), "bc.category=c.category_id")
            ->where(not_null('usage'))
            ->where("banner_display>0")
            ->where("c.category_type=", $categoryType);
            is_array($this->position) ? $sql->where('banner_position IN ('.implode(',', $position).')') : $sql->where('banner_position=', $position);
            $sql->order("banner_order")->group('banner_id');
            /*echo($sql->toSQLcmd());*/
            $data = $this->query($sql)->fetch('banner_position', true);
            return is_array($position) ? $data : $data[$position];
        }
        else 
            return array();
    }
}