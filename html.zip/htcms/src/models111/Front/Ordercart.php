<?php 
namespace Front;

use Htlib\Db\DbTable;

/**
* 
*/
class Ordercart extends DbTable
{
    function addOrder($data)
    {
        /*print_r($data);
        exit();*/
        $order = $this->parseSchema('order', $data);
        $order['create_time'] = time();
        $this->insert('order', $order);
        $lastId = $this->lastId();
        if ($lastId) {
            if (!empty($data['product']) && is_array($data['product'])) {
                foreach ($data['product'] as $id => $value) {
                    $value['order_id'] = $lastId;
                    $this->insert('order_product', $value);
                }
            }
        }
        return $lastId;
    }

    function removeOrder($data)
    {
        
    }
}