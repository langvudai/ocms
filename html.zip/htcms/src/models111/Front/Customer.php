<?php 
namespace Front;

use Htlib\Db\DbTable;

/**
* 
*/
class Customer extends DbTable
{
    public $lang='vi';

    function getInfo($id)
    {
        $sql = $this->select('*', 'customer')->where('id=', $id);
        $result = $this->query($sql)->fetch();
        if ($result) {
            return $result[0];
        }
        return array();
    }

    function resellerPrice($level, $search_name='', $limit=10, $page=1)
    {
        $sql = $this->select('id, description, product_id, expired', 'reseller_price rp')
        ->innerJoin('reseller_price_level rpl', 'rpl.reseller_price_id=rp.id', 'price')
        ->innerJoin('items i', 'rp.product_id=i.id')
        ->innerJoin('item_lang il', 'i.id=il.item_id', 'name')
        ->leftJoin('url_alias u', "u.id = i.id AND `type`='I'", 'url')
        ->where(not_null('rp.usage'))
        ->where(not_null('i.usage'))
        ->where('rp.expired >= DATE(NOW()) OR rp.expired IS NULL')
        ->where('rpl.level=', $level)
        ->where('il.lang=', $this->lang)
        ->limit($limit, $page);
        empty($search_name) || $sql->where('il.name LIKE \'%'.str_replace(' ', '%', $search_name).'%\'');

        $result = $this->query($sql)->fetch('id');
        $total = $this->query($sql->getCount())->fetch();
        return array('rows' => $result, 'total'=>$total);

        /*$sql = $this->db->select('id', 'items i')
        ->innerJoin('item_lang il', 'i.id=il.item_id', 'name')
        ->where('il.lang=', $this->lang)
        ->where('i.id IN ('.$this->db->select('product_id', 'reseller_price').')')
        ->limit($limit, $page);
        is_array($this->type) ? $sql->where('item_type IN ('.implode(',', $this->type).')') : $sql->where('item_type=', $this->type);
        
        if ($search_name) {
            $sql->where('il.name LIKE \'%'.str_ireplace(' ', '%', $search_name).'\'%');
        }
        $result = $this->db->query($sql)->fetch('id');
        if ($result) {
            $total = $this->db->query($sql->getCount())->fetch();
            $list_pid = array_keys($result);
            $sql = $this->db->select('item_id, option_id, value', 'item_option')
            ->where('item_id IN ('.implode(',', $list_pid).')');
            $rs_option = $this->db->query($sql)->fetchArrayKey('value');

            $sql = $this->select('id, product_id, level, price, expired, create_user, create_time', 'reseller_price')
            ->where(not_null('usage'))
            ->where('product_id IN ('.implode(',', $list_pid).')');
            $rs_price = $this->db->query($sql)->fetch('product_id', true);
            foreach ($result as $key => $value) {
                $result[$key]['options'] = $rs_option[$key];
                $result[$key]['reseller_price'] = $rs_price[$key];
            }
            return array('rows' => $result, 'total'=>$total);
        }*/
    }
}