<?php 
namespace Front;

use htlib\db\DbTable;

class Category extends DbTable
{
    private $listHome, $listPath, $listId, $notTree, $lm;
    public $lang='vi', $type = 0, $condition;

    /**
     *
     * @param string $name type, clearWhere, /^where([A-Z])([A-Za-z0-9_]*)$/, notree
     * 
     */
    public function __call($name, $value)
    {
        if ($name=='type') {
            $this->type = array_shift($value);
        } elseif ($name=='clearWhere') {
            $this->condition = array();
        } elseif ($name=='notree') {
            $this->notTree = empty($value) ? true : !array_shift($value);
        } elseif (preg_match('/^where([A-Z])([A-Za-z0-9_]*)$/', $name, $matches) && !empty($value)) {
            $strWhere = strtolower($matches[1]) .$matches[2]; 
            $strWhere = strtolower(preg_replace('/(([a-z])([A-Z]))/', '\\2.\\3', $strWhere)); 
            if (count($value)==1) {
                $value = array_shift($value);
            }
            if (is_array($value)) { 
                $strWhere = preg_replace('/([a-z][a-z0-9_]*)/i', "`$1`", $strWhere); 
                $value = array_map(function($a) {return trim($a, '"\'');}, $value); 
                $value = array_map(function($a) {return is_numeric($a) ? $a : ("'".addslashes($a)."'");}, $value); 
                $strWhere.= ' IN ('. implode(',', $value).')'; 
                $this->condition[] = $strWhere; 
            } elseif (is_scalar($value)) { 
                $this->condition[] = array($strWhere => $value);
            } 
        } 
        return $this; 
    }

    public function getId()
    {
        return $this->listId;
    }

    public function getPath($categoryId)
    {
        $lid = !empty($this->listPath)&&is_array($this->listPath) ? implode(',', array_keys($this->listPath)): '0';
        $sql = $this->select('id, parent_id', 'categories c')
            ->innerJoin('category_lang cl', "c.id = cl.`category_id` AND `lang` = '".$this->lang."'", 'name')
            ->leftJoin('url_alias u', "u.id = c.id AND `type`='C'", 'url')
            ->where(not_null('c.usage'))
            ->where('display=1')
            ->where("c.category_type=", $this->type)
            ->where('`c`.`id` NOT IN ('.$lid.')');
        if (!empty($this->condition) && is_array($this->condition)) {
            foreach ($this->condition as $condition) {
                $sql->where($condition);
            }
        }
        $rs = $this->query($sql)->fetch('id');
        if (is_array($rs) && !empty($rs)) {
            $this->listPath = is_array($this->listPath) && !empty($this->listPath) ? array_replace($this->listPath, $rs) : $rs;
        }
        
        /* get path */
        $array = array();
        if (is_array($categoryId)) {
            $treetmp = array();
            foreach ($categoryId as $id) {
                if (isset($this->listPath[$id])) {
                    $treetmp[$this->listPath[$id]['parent_id']][] = $id;
                }
            }
            $catId = $categoryId;
            foreach ($catId as $i=>$id) {
                if (isset($treetmp[$id])) {
                    unset($catId[$i]);
                }
            }
            $catId = end($catId);
            /*print_r($categoryId);
            print_r($catId);*/
            while (isset($this->listPath[$catId]['parent_id']) && $this->listPath[$catId]['parent_id']!=0) {
                in_array($catId, $categoryId) && array_unshift($array, $this->listPath[$catId]);
                $catId = $this->listPath[$catId]['parent_id'];
            }
            in_array($catId, $categoryId) && array_unshift($array, $this->listPath[$categoryId]);
        } else {
            while (isset($this->listPath[$categoryId]['parent_id']) && $this->listPath[$categoryId]['parent_id']!=0) {
                array_unshift($array, $this->listPath[$categoryId]);
                $categoryId = $this->listPath[$categoryId]['parent_id'];
            }
            array_unshift($array, $this->listPath[$categoryId]);
        }
        return $array;
    }

    public function get()
    {
        $sql = $this->select('id, parent_id, thumbnail, in_home', 'categories c')
            ->innerJoin('category_lang cl', "c.id = cl.`category_id` AND `lang` = '".$this->lang."'", 'name')
            ->leftJoin('url_alias u', "u.id = c.id AND `type`='C'", 'url')
            ->where(not_null('c.usage'))
            ->where('display=1')
            ->where("c.category_type=", $this->type);

        if (!empty($this->condition) && is_array($this->condition)) {
            foreach ($this->condition as $condition) {
                $sql->where($condition);
            }
        }
        if ($this->notTree) {
            $sql->order('c.`order`');
            $rs = $this->query($sql)->fetch('id');
            $this->listId = array_keys($rs);
            $this->listHome = array();
            $this->listPath = array();
            foreach ($rs as $row) {
                if ($row['in_home']) {
                    $this->listHome[$row['id']] = $row;
                }
                if (!isset($this->listPath[$row['id']])) {
                    $this->listPath[$row['id']] = array('id'=>$row['id'], 'parent_id' => $row['parent_id'], 'name' => $row['name'], 'url' => $row['url']);
                }
            }
            return array_values($rs);
        }
        $sql->order('c.parent_id ASC, c.`order`');
        $rs = $this->query($sql)->fetch('parent_id', true);
        $this->listHome = array();
        $this->listPath = array();
        $this->listId = array();
        return $this->createTree($rs);
    }

    /**
     * 
     * 
     * 
     * @return array(id=>array(id, thumbnail, name, url), ....)
     */
    public function getInHome()
    {
        if (empty($this->listHome)) {
            $listId = 0;
        } else {
            $listId = implode(',', array_keys($this->listHome));
        }
        $sql = $this->select('id, thumbnail', 'categories c')
        ->innerJoin('category_lang cl', 'c.id = cl.`category_id`', 'name')
        ->leftJoin('url_alias u', 'u.id = c.id AND `type`=\'C\'', 'url')
        ->where('lang=', $this->lang)
        ->where('c.in_home=1')
        ->where('c.category_type=', $this->type)
        ->where('c.id NOT IN ('.$listId.')')
        ->order('c.order')
        ;

        $rs = $this->query($sql)->fetch('id');
        $this->listHome = is_array($this->listHome) ? array_replace($this->listHome, empty($rs)?array():$rs) : $rs;
        return $this->listHome;
    }

    private function createTree($ar, $p=0, $lv=0)
    {
        $a = array();
        if(isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])){
            foreach($ar[$p] as $i=>$row){
                if ($row['in_home']) {
                    $this->listHome[$row['id']] = $row;
                }
                if (!isset($this->listPath[$row['id']])) {
                    $this->listPath[$row['id']] = array('id'=>$row['id'], 'parent_id' => $row['parent_id'], 'name' => $row['name'], 'url' => $row['url']);
                }
                $this->listId[$row['id']] = $row['id'];
                if(isset($ar[$row['id']])){
                    $row['level'] = $lv;
                    $row['child'] = $this->createTree($ar, $row['id'], $lv+1);
                    $a[] = $row;
                }
                else {
                    $row['level'] = $lv;
                    $a[] = $row;
                }
            }
        }
        return $a;
    }
    
    function getOnce($categoryId)
    {
        /*$sql = $this->select('*', 'categories c')
        ->innerJoin('category_lang cl', "c.id = cl.`category_id` AND `lang` = '".$this->lang."'", 'name, title, description')
        ->leftJoin('url_alias u', "u.id = c.id AND `type`='C'", 'url')
        ->where('c.id=', $categoryId);
        $rs = $this->query($sql)->fetch();
        if($rs){
            $sql = $this->select('', 'article')
            ->leftJoin('article_lang', "article_lang_id=article_id AND article_lang='".$this->lang."'", '*')
            ->where('(article_type=0 OR article_type IS NULL) AND category=', $category_id);
            $rs = $this->query($sql)->fetch();
            if(@$rs[0]){
                foreach ($rs[0] as $key => $value) {
                    $data[$key] = $value;
                }
            }
        }
        return NULL;*/
        $sql = $this->select('*', 'categories c')
        ->innerJoin('category_lang cl', 'c.id = cl.category_id', 'name, title, description')
        ->leftJoin('url_alias u', "u.id = c.id AND `type`='C'", 'url')
        ->where('cl.lang=', $this->lang)
        ->where('c.id=', $categoryId)
        ->limit(1);
        $rs = $this->query($sql)->fetch();
        if($rs){
            $data = $rs[0];
            $sql = $this->select('option_id, value', 'category_option')
            ->where('category_id=', $categoryId)
            ->where('lang=', $this->lang);
            $data['option'] = $this->query($sql)->fetchOnce('value', 'option_id');
            return $data;
        }
        return NULL;
    }

    /**
     *
     * @return array Id has not child
     */
    function getIdMaxLevel()
    {
        $sqlw = $this->select('parent_id', 'categories')
        ->where(not_null('usage'));
        $sql = $this->select('id', 'categories')
        ->where(not_null('usage'))
        ->where('id NOT IN ('.$sqlw.')');
        $rs = $this->query($sql)->fetchOnce('id');
        return empty($rs) ? array() : $rs;
    }

    /**
     *
     * @return array Id category has parent_id=0
     */
    function getIdRoot()
    {
        $sql = $this->select('id', 'categories')
        ->where(not_null('usage'))
        ->where('parent_id=0 OR parent_id IS NULL');
        /*echo $sql->toSQLcmd();*/
        $rs = $this->query($sql)->fetchOnce('id');
        return empty($rs) ? array() : $rs;
    }

    function getParent()
    {
        $sqlw = $this->select('parent_id', 'categories')->where(not_null('usage'));
        $sql = $this->select('id', 'categories')
        ->where(not_null('usage'))
        ->where('id IN ('.$sqlw.')');
        /*echo $sql->toSQLcmd();*/
        $rs = $this->query($sql)->fetchOnce('id');
        return empty($rs) ? array() : $rs;
    }

    function gettTreetops()
    {
        $sqlw = $this->select('parent_id', 'categories');
        $sql = $this->select('id', 'categories')
        ->where('id NOT IN ('.$sqlw.')');
        $rs = $this->query($sql)->fetchOnce('id');
        return empty($rs) ? array() : $rs;
    }
}