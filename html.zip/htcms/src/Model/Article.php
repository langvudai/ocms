<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Mvc\Role;
use Htlib\Session;

class Article extends DbTable
{
	private $type=0, $_name='articles';

	public function add($data)
	{
		$insert = $this->parseSchema($this->_name, $data);
		$insert['user_id'] = Session::get('user_id');
		$insert['update_time'] = time();
		$this->insert($insert);
		return (int)$this->lastId();
	}
	public function edit($id, $data)
	{
		$update = $this->parseSchema($this->_name, $data);
		$update['user_id'] = Session::get('user_id');
		$update['update_time'] = time();
		unset($update['id']);
		$rs = $this->update($update, 'id='.$id);
		return $rs;
	}
	public function del($id)
	{

	}
	public function get(array $where=null, $limit=10, $page=0, $sort='')
	{
		$query = $this->select('id, title, sapo, thumb, status, is_hot, is_new, display, order, date, category_id', array('a'=>$this->_name))
		->where(not_null('a.usage'))
		->where('type=', $this->type)
		->limit($limit, $page);
		empty($sort) ? $query->order('order') : $query->order($sort);
		empty($where['category'])||$query->where('category_id=', $where['category']);
		if (!empty($where['keyword'])) { 
			$keyword = str_replace(' ', '%', $where['keyword']);
			$query->where("title LIKE '%$keyword%' OR sapo LIKE '%$keyword%'");
		}
		return $query->get();
	}
	public function getOnce($id)
	{

	}
}