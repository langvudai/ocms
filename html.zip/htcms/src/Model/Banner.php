<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Mvc\Role;
use Htlib\Session;

class Banner extends DbTable
{
	public $position=0;
	protected $_name = 'banners';

	public static function test($a)
	{
		return 'tt'.$a;
	}


	function get(array $where=null, $limit=10, $page=0, $sort='')
	{
		$feild = $this->getTableSchema($this->_name);
		unset($feild['time_create']);
		unset($feild['time_update']);
		unset($feild['user_id']);
		unset($feild['user_create']);
		unset($feild['usage']);
		unset($feild['timestamp']);
		$query = $this->select(array_keys($feild), $this->_name)->where(not_null('usage'))->limit($limit, $page);
		empty($this->position) || $query->where('position=', $this->position);
		empty($this->sort) ? $query->order('order') : $query->order($sort);
		
		return $query->get();

		/*$sql = $this->select('*', 'banners')
		->where('deleted=0')
		->where('position=', $this->position);
		if($where){
			$sql->where($where);
		}
		if($sort){
			$sql->order($sort);
		}
		else
		{
			$sql->order('order');
		}
		$sql->limit($limit, $page);
		$data['rows'] = $this->query($sql)->fetch();
		$data['total'] = $this->query($sql->getCount())->fetch();
		return $data;*/
	}

	function add($data)
	{
		global $USER;
		@$category = $data['category_id'];
		/*isset($data['filename']) && ($data['filename'] = "".@$data['filename'][0]."");*/
		$data['user_id'] = Session::get('user_id'); 
		$data['user_create'] = Session::get('user_id'); 
		$data['time_create'] = time();
		$data = $this->parseSchema('banners', $data);
		$rs = $this->insert('banners', $data);
		//echo $this->toSQLcmd();exit();
		$id = $this->lastid();
		if($id && is_array($category)){
			$ins = array();
			foreach ($category as $value) {
				$ins[] = "$id, $value";
			}
			$this->query("INSERT IGNORE banner_category VALUES (".implode("), (", $ins).")");
		}
		return $id;
	}

	function save($id, $data)
	{
		global $USER;
		/*isset($data['filename']) && ($data['filename'] = "".@$data['filename'][0]."");*/
		@$category = $data['category'];
		$data['user_id'] = Session::get('user_id'); 
		$data = $this->parseSchema('banners', $data);
		if (empty($data['start_date'])) {
			unset($data['start_date']);
		}
		if (empty($data['end_date'])) {
			unset($data['end_date']);
		}
		$data['display'] = (int)$data['display'];
		$rs = $this->update('banners', $data, "id = $id");
		// echo $this->toSQLcmd();exit();
		if($rs)
		{
			if(is_array($category))
			{
				$this->delete('banner_category', "banner=$id");
				$ins = array();
				foreach ($category as $value) 
				{
					$ins[] = "$id, $value";
				}
				$this->query("INSERT IGNORE banner_category VALUES (".implode("), (", $ins).")");
			}
			return true;
		}
		else 
			return false;
	}

	function del($id)
	{
		$rs = $this->update('banners', array('usage'=>(object)'NULL', 'user_id'=>Session::get('user_id')), "id = $id");
		/*echo $this->toSQLcmd();*/
		if($rs)
			return true;
		else 
			return false;
	}

	function getOnce($id)
	{
		$sql = $this->select('*', 'banners')->where("id = ",$id);
		$rs = $this->query($sql)->fetch();
		if(count($rs))
		{
			$data = $rs[0];
			$data['category'] = array();
			$sql = "select category from `{banner_category}` where banner = ".$id;
			$rs = $this->query($sql)->fetch();
			if(is_array($rs))
			foreach ($rs as $value) 
			{
				$data['category'][] = $value['category'];
			}
			return $data;
		}
		return null;
	}
}