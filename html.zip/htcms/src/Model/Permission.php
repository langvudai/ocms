<?php 
namespace Model;

use Htlib\Db\DbTable; 
use Htlib\Db\ArrayAssoc; 
use Htlib\Db\Expr; 
use Htlib\Configuration;
use Htlib\Session;

class Permission extends DbTable
{
    protected $_name = 'permissions';
    function getRoleA($user_id=0)
    {
        if (empty($user_id)) {
            $query = $this->select('id, name, description, actived', 'roles')
                ->where('actived=1')
                ->where(not_null('usage'));
        }
        $query = $this->select('id, name, description, actived', 'roles')
            ->leftJoin('user_role', 'user_role.role_id=roles.id AND user_role.user_id='.$user_id, array('selected'=>new Expr('IF(user_role.id > 0, 1, 0)')))
            ->where(not_null('usage'))
            ->where('actived=1');
        //echo $query;exit();
        return $query->fetch();
    }
    function getRole($user_id=0)
    {
        if (empty($user_id)) {
            $query = $this->select('id, name, description, actived', 'roles')
                ->where(not_null('usage'));
        }
        $query = $this->select('id, name, description, actived', 'roles')
            ->leftJoin('user_role', 'user_role.role_id=roles.id AND user_role.user_id='.$user_id, array('selected'=>new Expr('IF(user_role.id > 0, 1, 0)')))
            ->where(not_null('usage'));
        //echo $query;exit();
        return $query->fetch();
    }

    function getAllPermission()
    {
        $query = $this->select('name, id, parent_id, description', 'permissions')
        ->where('guard IN (\'mod\', \'act\')')
        ->where(not_null('usage'))
        ->order('parent_id, id')
        ;
        $permissions = $query->fetch('parent_id', true);
        $return = array();
        if (isset($permissions[0]) && is_array($permissions[0])) {
            foreach ($permissions[0] as $value) {
                if (isset($permissions[$value['id']]) && is_array($permissions[$value['id']])) {
                    $value['childs'] = array();
                    foreach ($permissions[$value['id']] as $v) {
                        array_push($value['childs'], $v);
                    }
                }
                array_push($return, $value);
            }
        }
        return $return;
    }

    /*function addRole($data)
    {
        
    }*/

    function getName($id)
    {
        
    }

    function getPermission($role_id)
    {
        return $this->select('permission_id', 'permission_role')->where('role_id=', $role_id)->fetchOnce('permission_id');
    }

    function savePermission($role_id, array $permission_id=NULL)
    {
        $rs = $this->delete('permission_role', 'role_id='.$role_id);
        if (empty($permission_id)) {
            return $rs;
        }
        global $id;
        $id = $role_id;
        $permission_id = array_map(function($value){
            global $id;
            return array($id, $value);
        }, $permission_id);
        return $this->insertArray('permission_role', array('role_id', 'permission_id'), $permission_id);
    }

    function getUserPermission($user_id)
    {
        return $this->select('permission_id', 'permission_user')->where('user_id=', $user_id)->fetchOnce('permission_id');
    }

    function saveUserPermission($user_id, $permission_id)
    {

    }

    function getContentType($id)
    {
        
    }

    function setContentType($role_id, array $typeId, array $permission)
    {
        
    }

    function addRole(array $insert)
    {
        $data = $this->parseSchema('roles', $insert);
        $data['actived'] = empty($insert['actived']) ? 0 : 1;
        $rs = $this->insert('roles', $data);
        /*echo $this;
        exit();*/
        if ($rs) {
            return $this->lastId();
        }
        return 0;
    }

    function editRole($id, $data)
    {
        //$rs = $this->update('roles', array('name'=>$name, 'description'=>$description), "id=$id");
        $data = $this->parseSchema('roles', $data);
        $data['actived'] = empty($data['actived']) ? 0 : 1;
        $rs = $this->update('roles', $data, 'id='.$id);
        /*$rs = $this->update('roles', array(
            'name'=>$data['name'], 
            'description'=>$data['description'],
            'actived'=>(int)$data['actived'],
        ), "id=$id");*/
        return $rs;
    }

    function delRole($id)
    {
        return $this->update('roles', array('usage'=>(object)'NULL'), 'id='.$id);
        /*$this->delete('permissions', 'role_id='.$id);
        $this->delete('user_role', 'role_id > 1 AND role_id='.$id);
        $this->delete('roles', 'id > 1 AND id='.$id);
        return true;*/
    }

    function updateUserRole($user_id, $roles)
    {
        $this->delete('user_role', 'user_id='.$user_id);
        if (is_array($roles)) {
            foreach ($roles as $role_id) {
                $this->insert('user_role', array('user_id'=>$user_id, 'role_id'=>$role_id));
            }
        }
    }
}