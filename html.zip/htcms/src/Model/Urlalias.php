<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Db\ArrayAssoc;
use Htlib\Db\Expr;
use Htlib\Configuration;

class Urlalias extends DbTable
{
	protected $_name = 'url_alias';
	function checkExist($url, $type='', $id=0)
	{
	    if (strlen(trim($url))==0) {
	        return false;
	    }
	    $query = $this->select(array('d'=>new Expr('COUNT(*)')), 'url_alias')->where('url=',$url);
	    if ($type && $id) {
	    	$query->where("`type`<>'$type' OR id<>$id");
	    }
	    $query = $query->fetch();
	    return (int)$query[0]['d'];
	}

	function add($url, $type, $id, $typeId='')
	{
	    if (strlen(trim($url))==0 || trim($url)=='#') {
	        return false;
	    }
	    $url = preg_replace('/[^a-z0-9\.\-_\#\/]/i', '-', $url);
	    return $this->insert(array('url'=>$url, 'type'=>$type, 'id'=>$id, 'type_id'=>$typeId));
	}

	function save($type, $id, $url, $typeId='')
	{
	    if (strlen(trim($url))==0 || trim($url)=='#') {
	        return false;
	    }
	    $url = preg_replace('/[^a-z0-9\.\-_\#\/]/i', '-', $url);
	    $rs = $this->insert(array('url'=>$url, 'type_id'=>$typeId, 'type'=>$type, 'id'=>$id), array('url'=>$url));
	    if ($rs) {
	        return true;
	    }
	    return false;
	}

	function updateUrl($url_alias_id, $url)
	{
	    if (strlen(trim($url))==0 || trim($url)=='#') {
	        return false;
	    }
	    $url = preg_replace('/[^a-z0-9\.\-_\#\/]/i', '-', $url);
	    $rs = $this->update(array('url'=>$url), 'url_alias_id='.$url_alias_id);
	    if ($rs) {
	        return true;
	    }
	    return false;
	}

	function del($url_or_id, $type='', $id='')
	{
	    $url = preg_replace('/[^a-z0-9\.\-_\#\/]/i', '-', $url); 
	    if (strlen($url_or_id)==0) {
	        $rs = $this->delete("`type`='$type' and `id`='$id'");
	    } else {
	        $rs = $this->delete("`url`='$url_or_id' OR url_alias_id=".parseInt($url_or_id));
	    }
	    if ($rs) {
	        return true;
	    }
	    return false;
	}

	function get($type, $id)
	{
		$query = $this->select('url', 'url_alias')->where('type=', $type)->where('id=', $id)->fetchRow();
		return $query['url'];
	}

	function getAll($key='', $limit=10, $page=0)
	{
	    $sql = $this->select('*', 'url_alias');
	    if (is_string($key) && $key) {
	        $key = str_ireplace(' ', '%', $key);
	        $sql->where("url LIKE '%$key%'");
	    }
	    $sql->limit($limit, $page);
	    $rows = $this->query($sql)->fetch();
	    $total = $this->query($sql->getCount())->fetch();
	    return array('rows'=>$rows, 'total'=>$total);
	}
	
	function getUrl($key='')
	{
	    $lang = Configuration::getLang();
	    $dfLang = key($lang);
	    $key = preg_replace('/(\s+)/','%', $key);

	    $w = $this->select('id', 'url_alias')->where('type=\'C\'');
	    $sql = $this->select('id', 'categories c')
	    ->innerJoin('category_lang cl', 'c.id=category_id', 'name')
	    ->where(not_null('c.usage'))
	    ->where('lang=', $dfLang)
	    ->where('c.id IN ('.$w.')');
	    strlen($key) && $sql->where('cl.name LIKE \'%'.$key.'%\'');
	    $categories = $this->query($sql)->fetch('id');

	    $w = $this->select('id', 'url_alias')->where('type=\'I\'');
	    $sql = $this->select('id', 'items i')
	    ->innerJoin('item_lang il', 'i.id=item_id', 'name')
	    ->where(not_null('i.usage'))
	    ->where('lang=', $dfLang)
	    ->where('i.id IN ('.$w.')');
	    strlen($key) && $sql->where('il.name LIKE \'%'.$key.'%\'');
	    $items = $this->query($sql)->fetch('id');

	    $id = array_merge(is_array($categories) ? array_keys($categories) : array(), is_array($items) ? array_keys($items) : array());
	    $sql = $this->select(array('url_alias_id', 'url', 'type', 'id', 'type_id', 'target', 'typeId'=>(object)'CONCAT(`type`, `type_id`)'), 'url_alias u')
	    ->where('id IN ('.implode(',', $id).')')
	    ->order('type, type_id');
	    $rsUrlalias = $this->query($sql)->fetch('typeId', true);
	    return array(
	        'urlalias'   => $rsUrlalias, 
	        'C' => $categories, 
	        'I'      => $items,
	    );
	}

	function getOnce($type, $id)
	{
	    $lang = 'vi';
	    $sql = $this->select(array('url_type' => 'type', 'url', 'type_id'), 'url_alias u')
	    ->where('u.type=', $type)
	    ->where('u.id=', $id);
	    switch ($type) {
	        case 'C':
	            $sql->leftJoin('categories c', 'c.id=u.id AND '.not_null('usage').' AND c.id='.$id, 'id')
	            ->leftJoin('category_lang', "c.id=category_id AND lang='$lang'", '*');
	            break;
	        case 'I':
	            $sql->leftJoin('items i', "i.id=u.id AND ".not_null('usage')." AND i.id='$id'", 'id')
	            ->leftJoin('item_lang il', "i.id=item_id AND lang='$lang'", '*');
	            break;
	        case 'T':
	            $sql->leftJoin('texthtml t', "t.id=u.id AND ".not_null('usage')." AND t.id='$id' AND lang='$lang'", '*');
	            break;
	    }
	    $rs = $this->query($sql)->fetch();
	    if ($rs) {
	        return $rs[0];
	    }
	    return array();
	}
}