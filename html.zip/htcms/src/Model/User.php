<?php 
namespace Model; 

use Htlib\Db\DbTable; 
use Htlib\Db\Expr; 
use Htlib\Session; 

class User extends DbTable
{
    public $error = '';
    protected $_name = 'users';

    function delete($username)
    {
        $result = $this->update(array('usage'=>(object)'NULL'), '(username=\''.$username.'\' OR id=\''.$username.'\') AND id<>1');
        if ($result) {
            return $this->affectedRows();
        }
        return false;
    }

    function info($id)
    {
        $user = $this->select('*', 'users u')
        ->leftJoin('user_role ua', 'ua.user_id=u.id', 'role_id')
        ->leftJoin('roles r', 'r.id = ua.role_id', array('role_name'=>'name', 'role_timestamp'=>'timestamp'))
        ->where(not_null('u.usage'))
        ->where('u.id=', $id)
        ->fetchRow()
        ;
        /*echo $user;
        exit();*/
        if ($user) {
            unset($user['password']);
            unset($user['salt']);
            return (object)$user;
        }
        return null;
    }

    function getPassword($password, $salt)
    {
        return sha1(sha1($password).$salt);
    }

    function generatorSalt()
    {
        $a = range('!', '~');
        shuffle($a);
        return implode('', array_slice($a, rand(0, 75), 15));
    }

    function confirmUserPass($username, $password)
    {
        (!get_magic_quotes_gpc()) && ($username = addslashes($username));
        $username = preg_replace('/[^a-z0-9]+/i','',$username);
        $query = $this->select()
            ->from(array('u'=>'users'), 'id, password, salt')
            ->innerJoin('user_role', 'u.id=user_id')
            ->where(not_null('u.usage'))
            ->where("actived=1 AND `username`='$username'");
        $user = $query->fetchRow();
        /*echo $query;
        print_r($user);
        exit();*/
        if ($user) {
            if ($this->getPassword($password, $user['salt']) == $user['password']) {
                $this->update(array(
                    'last_login'=>time(), 
                    'dtoken'=>$this->createDToken(), 
                ), 'id='.$user['id']);
                return $user['id'];
            } else {
                $this->error = 'invalid password';
            }
        } else {
            $this->error = 'username not exist';
        }
        return 0;
    }

    function confirmEmailPass($email, $password)
    {
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $user = $this->select()
                ->from(array('u'=>'users'), 'id, password, salt')
                ->innerJoin('user_role', 'u.id=user_id')
                ->where(not_null('u.usage'))
                ->where("actived=1 AND `email`='$email'")
                ->fetchRow();
            if ($user) {
                if ($this->getPassword($password, $user['salt']) == $user['password']) {
                    $this->update(array(
                        'last_login'=>time(), 
                        'dtoken'=>$this->createDToken(), 
                    ), 'id='.$user['id']);
                    return $user['id'];
                } else {
                    $this->error = 'invalid password';
                }
            } else {
                $this->error = 'username not exist';
            }
        }
        return 0;
    }

    function confirmProvider($provider, $provider_id, $email='')
    {
        $query = $this->select('id, provider_id', array('u'=>'users'))
            ->innerJoin('user_role', 'u.id=user_id')
            ->where(not_null('u.usage'))
            ->where('actived=1')
            ->where('provider=', $provider)
            ->where('provider_id=', $provider_id);
        empty($email) || $user->where('email=', $email);
        $user = $user->fetchRow();
        if (!empty($user['provider_id']) && $user['provider_id']==$provider_id) {
            $this->update(array(
                'last_login'=>time(), 
                'dtoken'=>$this->createDToken(), 
            ), 'id='.$user['id']);
            return $user['id'];
        }
        return 0;
    }

    function addLog($username,$password=NULL)
    {
        $iplogin = $_SERVER['REMOTE_ADDR'];
        if (is_null($password)) {
            $this->insert('user_login', array(
                'username' => $username,
                'iplogin' => $iplogin,
                'timelogin' => (object)'NOW()',
            ));
        } else {
            $this->insert('user_login', array(
                'username' => $username,
                'password' => $password,
                'iplogin' => $iplogin,
                'timelogin' => (object)'NOW()',
                'status' => 1,
            ));
        }
    }

    function add($data, array $profile=NULL)
    {
        if(!isset($data['username']) || preg_match('/[^a-z0-9]+/i', $data['username']))
        {
            $this->error = 'Username is invalid!';
            return false;
        }
        if(!isset($data['password']) || strlen($data['password'])==0)
        {
            $this->error = 'Password is null!';
            return false;
        }
        $data['salt'] = $this->generatorSalt();
        $data['password'] = $this->getPassword($data['password'], $data['salt']);
        $data['creator'] = Session::get('user_id');
        $data['time_create'] = date('Y-m-d H:i:s');
        $data['timestamp'] = (object)"CURRENT_TIMESTAMP";
        $role_id = @$data['role_id'];
        $group_id = @$data['group_id'];
        $data = $this->parseSchema('users', $data);
        $rs = $this->insert($data);
        $id = $this->lastid();
        $this->error = $this->error();
        if ($id) {
            $this->insert('user_group', array(
                'user_id'=>$id, 
                'group_id'=>empty($group_id) ? $id : $group_id
                ));
            if (is_array($profile)) {
                foreach ($profile as $key => $value) {
                    $this->insert('profiles', array(
                        'user_id' => $id, 
                        'name' => $key, 
                        'value' => $value, 
                    ));
                }
            }
        }
        return $id;
    }

    function save($id, $data)
    {
        unset($data['id']);
        unset($data['username']);
        unset($data['password']);
        unset($data['salt']);
        $data['user_update_id'] = Session::get('user_id');
        $data['time_update'] = date('Y-m-d H:i:s');
        $rs = $this->update($this->parseSchema('users', $data), "`id`=$id");
        // echo $this->toSQLcmd();
        // exit();
        // isset($data['role_id']) && $this->delete('user_role', 'user_id='.$id);
        // isset($data['role_id']) && $this->insert('user_role', array('user_id'=>$id, 'role_id'=>$data['role_id']));
        $this->error = $this->error();
        return $rs;
    }

    function getAll(array $where=null, $limit = 10, $offset=0)
    {
        $user_id = (int)Session::get('user_id');
        $users = $this->select('id, username, fullname, email, actived', array('u'=> 'users'))
            ->leftJoin(array('ua'=> 'user_role'), "ua.user_id=u.id")
            ->leftJoin('roles r', 'r.id=ua.role_id', array('name'=>new Expr('GROUP_CONCAT', 'name')))
            ->where(not_null('u.usage'))
            ->where("u.id>1 OR u.id=".$user_id)
            ->where($where)
            ->order('id')
            ->group('id')
            ->limit($limit, $offset)
            ->get();
        /*print_r($where);
        echo $sql->toSQLcmd();exit();*/
        if ($users) {
            return array('rows'=>$users->rows, 'total'=>$users->count);
        }
        return NULL;
    }

    function getOnce($user_id)
    {
        $user = $this->select('*', 'users u')
            ->leftJoin('user_role ua', 'ua.user_id=u.id', 'role_id')
            ->where(not_null('u.usage'))
            ->where('u.id=', $user_id)
            ->fetchRow()
            ;
        /*echo $user;
        exit();*/
        if ($user) {
            unset($user['password']);
            unset($user['salt']);
            return $user;
        }
        return null;
    }

    

    function updateNewPassword($id, $password)
    {
        $salt = $this->generatorSalt();
        $password = $this->getPassword($password, $salt);
        $rs = $this->update(array('password'=>$password, 'salt'=>$salt), "`id`=".$id);
        if ($rs) {
            return true;
        }
        $this->error = $this->error();
        return false;
    }

    function createDToken() 
    {
        $s = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwzyx';
        $t = '';
        for ($i=0; $i < 38; $i++) {
            $t.= substr($s, rand(0, strlen($s)), 1);
        }
        return $t;
        /*return bin2hex(random_bytes(38));*/
    }

    function resetPassword($token)
    {
        $s = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwzyx';
        $p = '';
        for($i=1; $i<=8; $i++) {
            $p.= $s[rand(0,strlen($s)-1)];
        }
        $salt = $this->generatorSalt();
        $password = $this->getPassword($p, $salt);
        $ntoken = uniqid().$token;
        $rs = $this->update(array(
                'password'=>$password, 
                'salt'=>$salt, 
                'dtoken'=>$ntoken,
            ), '`dtoken`=\''.$token.'\'');
        if ($rs) {
            $user = $this->select('username, password, salt', 'users')->where('dtoken=', $ntoken)->fetchRow();
            if ($user) {
                if ($this->getPassword($p, $user['salt']) == $user['password']) {
                    return array('username' => $user['username'], 'password'=>$p);
                }
            }
        }
        $this->error = $this->error();
        return null;
    }

    function updatePassword($uid, $current_password, $password)
    {
        $user = $this->select('password, salt', 'users')
        ->where(not_null('usage'))
        ->where('id=', $uid)
        ->fetchRow();
        if ($user) {
            if($this->getPassword($current_password, $user['salt']) == $user['password']) {
                $salt = $this->generatorSalt();
                $password = $this->getPassword($password, $salt);
                $this->update(array('password'=>$password, 'salt'=>$salt), "`id`=".$uid);
                return true;
            } else {
                $this->error = 'current password is not correct';
                return false;
            }
        }
        return false;
    }

    function deleteUser($username)
    {
        $result = $this->update('users', array('usage'=>(object)'NULL'), '(username=\''.$username.'\' OR id=\''.$username.'\') AND id<>1');
        if ($result) {
            return $this->affectedRows();
        }
        return false;
    }
}