<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Configuration;
use Htlib\Session;

class Category extends DbTable
{
    public 
        $lang = 'vi',
        $level = 0,
        $type = 0;

    public function setLang ($lang)
    {
        if ($lang) {
            $this->lang = $lang;
        } else {
            $cfg = new Configuration();
            if (is_array($cfg->lang)) {
                $this->lang = key($cfg->lang);
            }
        }
    }

    public function getName(array $id=NULL)
    {
        $sql = $this->select('id', 'categories c')->distinct()
        ->leftJoin('category_lang cl', 'c.id=cl.category_id AND cl.lang=\''.$this->lang.'\'', 'name')
        ->where(not_null('c.usage'))
        ->where('c.category_type=', $this->type)
        ->order('c.order');
        if ($id) {
            $sql->where('c.id IN('.implode(',', $id).')');
        }
        return $this->query($sql)->fetchOnce('name', 'id');
    }

    public function get(array $where=NULL) 
    {
        $sql = $this->select('*', 'categories c')
        ->leftJoin('category_lang cl', 'c.id=cl.category_id AND cl.lang=\''.$this->lang.'\'', array('name', 'lang'=>(object)('IF(LENGTH(cl.lang)>0, cl.lang, \''.$this->lang.'\')')))
        ->where(not_null('c.usage'))
        ->where('c.category_type=', $this->type)
        ->order('c.parent_id, c.order');
        if (is_array($where)) {
            foreach ($where as $value) {
                $sql->where($value);
            }
        }

        $rs = $this->query($sql)->fetch('parent_id', true);
        
        return $this->treeList($rs);
    }

    private function treeList($ar, $p=0, $lv=1)
    {
        $a = array();
        if (($this->level==0 || $lv <= $this->level) && isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])) {
            foreach ($ar[$p] as $i=>$row) {
                $a[] = array_replace($row, array(
                        'level'=>$lv,
                        'haschild'=>count(@$ar[$row['id']]),
                        'parent'=>$p,
                    ));
                if (isset($ar[$row['id']])) {
                    $a = array_merge($a, $this->treeList($ar, $row['id'], $lv+1));
                }
            }
        }
        return $a;
    }

    public function getTree(array $where=NULL) 
    {
        $sql = $this->select('*', 'categories c')
        ->leftJoin('category_lang cl', 'c.id=cl.category_id AND cl.lang=\''.$this->lang.'\'', 'name')
        ->where(not_null('c.usage'))
        ->where('c.category_type=', $this->type)
        ->order('c.parent_id, c.order');
        if ($where) {
            $sql->where($where);
        }

        $rs = $this->query($sql)->fetch('parent_id', true);
        
        return $this->tree($rs);
    }
    private function tree($ar, $p=0, $lv=1)
    {
        $a = array();
        if(($this->level==0 || $lv <= $this->level) && isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])) {
            foreach ($ar[$p] as $i=>$row) {
                if (isset($ar[$row['id']])) {
                    $a[] = array_replace($row, array(
                        'childs'=>$this->treeList($ar, $row['id'], $lv+1),
                    ));
                } else {
                    $a[] = $row;
                }
            }
        }
        return $a;
    }
    
    public function getTreeOption($edit_id)
    {
        /*is_array($this->lang) && reset($this->lang);
        $lang = is_array($this->lang) ? key($this->lang) : $this->lang;
        $select = $this->select('id, parent_id', 'categories c')
            ->leftJoin('category_lang cl', 'c.id=cl.category_id AND cl.lang=\''.$lang.'\'', 'name')
            ->where('c.deleted IS NULL OR c.deleted=0')
            ->where('c.category_type=', $this->type)
            ->where('c.id<>', $edit_id)
            ->order('c.parent_id, c.order');
        $rs = $this->query($select)->fetch('parent_id', true);
        return $this->treeOption($rs);*/
        /*echo $select->toSQLcmd();*/
    }

    private function treeOption($ar, $p=0, $lv=1){
        $a = array();
        if(($this->level ==0 || $lv <= $this->level) && isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])){
            foreach($ar[$p] as $i=>$row){
                $a[] = array(
                    'id'=>$row['id'],
                    'level'=>$lv,
                    'name'=>$row['name'],
                );
                if(isset($ar[$row['id']]))
                    $a = array_merge($a, $this->treeOption($ar, $row['id'], $lv+1));
            }
        }
        return $a;
    }
    
    public function add($data)
    {
        $cfg = new Configuration();
        $arlang = array_keys($cfg->lang);
        $lang = empty($this->lang) ? key($cfg->lang) : $this->lang;
        isset($data['category_type']) || ($data['category_type'] = $this->type);
        isset($data['thumbnail']) && is_array($data['thumbnail']) && ($data['thumbnail'] = @$data['thumbnail'][0]);
        $data['time_create'] = time();
        $data['user_id'] = $data['user_create'] = (int)Session::get('user_id');
        $rs = $this->insert('categories', $this->parseSchema('categories', $data));
        $id = $rs ? $this->lastid() : 0;
        if ($id) {
            $category_lang = $this->parseSchema('category_lang', $data);
            $array = array('category_id' => $id);
            foreach ($arlang as $lang){
                $array['lang'] = $lang;
                foreach ($category_lang as $key => $value){
                    $array[$key] = $value[$lang];
                }
                $this->insert('category_lang', $array);
            }

            if (!empty($data['option']) && is_array($data['option'])) {
                foreach ($data['option'] as $oid => $value) {
                    if (!empty($value) && is_array($value)) {
                        foreach ($value as $key => $v) {
                            if (isset($cfg->lang[$key])) {
                                $this->insert('category_option', array(
                                    'category_id' => $id, 
                                    'option_id' => $oid, 
                                    'lang' => $key, 
                                    'value' => is_array($v) ? array_shift($v) : $v
                                ));
                            }
                        }
                    }
                }
            }
        }
        return $id;
    }
    
    public function save($id, $data)
    {
        //$langCfg = Configuration::getLang();
        $cfg = new Configuration();
        $arlang = array_keys($cfg->lang);
        isset($data['thumbnail']) && is_array($data['thumbnail']) && ($data['thumbnail'] = "".@$data['thumbnail'][0]."");
        $data['display'] = (int)@$data['display'];
        $data['in_home'] = (int)@$data['in_home'];
        $data['user_id'] = (int)Session::get('user_id');
        
        $rs = $this->update('categories', $this->parseSchema('categories', $data), "id = $id");
        
        if ($rs) {
            $category_lang = $this->parseSchema('category_lang', $data);
            $cl_insert = array('category_id' => $id);
            $cl_update = array();
            foreach ($arlang as $lang){
                $cl_insert['lang'] = $lang;
                foreach ($category_lang as $key => $value){
                    $cl_insert[$key] = $value[$lang];
                    $cl_update[$key] = $value[$lang];
                }
                $this->insert('category_lang', $cl_insert, $cl_update);
            }

            /*foreach ($arlang as $lang) {
                $category_lang = array();
                $category_lang['category_id'] = $id;
                $category_lang['lang'] = $lang;
                $category_lang['name'] = isset($data['name'][$lang]) ? trim($data['name'][$lang]) :NULL;
                $category_lang['title'] = isset($data['title'][$lang]) ? trim($data['title'][$lang]) :NULL;
                $category_lang['keyword'] = isset($data['keyword'][$lang]) ? trim($data['keyword'][$lang]) :NULL;
                $category_lang['description'] = isset($data['description'][$lang]) ? trim($data['description'][$lang]) :NULL;
                $this->insert('category_lang', $category_lang, array(
                    'name' => $category_lang['name'], 
                    'title' => $category_lang['title'], 
                    'keyword' => $category_lang['keyword'], 
                    'description' => $category_lang['description'], 
                ));
            }*/

            if (!empty($data['option']) && is_array($data['option'])) {
                foreach ($data['option'] as $oid => $value) {
                    if (!empty($value) && is_array($value)) {
                        foreach ($value as $key => $v) {
                            if (isset($langCfg[$key])) {
                                $this->insert('category_option', array(
                                    'category_id' => $id, 
                                    'option_id' => $oid, 
                                    'lang' => $key, 
                                    'value' => is_array($v) ? array_shift($v) : $v
                                ), array(
                                    'value'=>is_array($v) ? array_shift($v) : $v
                                ));
                            }
                        }
                    }
                }
            }
        }
        if ($rs) {
            return true;
        }
        return false;
    }
    
    public function del($id, $delete=0)
    {
        if ($delete) {
            $this->delete('category_lang', "category_id=$id");
            $rs = $this->delete('categories', "category_id=$id");
        } else {
            $sql = "UPDATE `{categories}` a
            INNER JOIN `{categories}` b
            ON a.`parent_id`=b.`id`
            SET a.`parent_id`=b.`parent_id`
            WHERE b.`id`=$id";
            // echo $sql; exit();
            $rs = $this->query($sql);
            if (!$rs->error) {
                $rs = $this->update('categories', array(
                        'usage'=> (object)"NULL",
                        'time_update'=>time(),
                        'user_id'=>(int)Session::get('user_id'),
                ), "`id`=$id");
                // echo('arg1');
                // echo $this->toSQLcmd();exit();
                return $rs;
            }
            return false;
        }
        
        if($rs)
            return true;
        return false;
    }
    
    public function getForArticle() 
    {
        $sql = $this->select('id, parent_id', array('c'=>'categories'))
        ->leftJoin(array('l'=>'category_lang'), 'c.id=l.category_id', 'name')
        ->leftJoin(array('u'=>'url_alias'), 'u.id=c.id AND u.type="C"', 'url')
        ->where("c.deleted=0 AND l.lang='".$this->lang."'")
        ;
        if (is_numeric($this->type) && $this->type) {
            $sql->where("c.category_type=".$this->type);
        } else { 
            if (is_array($this->type)) {
                $t = array(0);
                foreach ($this->type as $v) {
                    $t[] = parseInt($v);
                }
                $sql->where("c.category_type IN (".implode(', ', $t).")");
            }
        }
        $sql->order('parent_id, order, id');
        /*echo $sql->toSQLcmd();*/
        $rs = $this->query($sql)->fetch('parent_id', true);
        $output = array();
        $output = $this->opt($rs);
        
        return $output;
    }

    public function getForItem() 
    {
        $sql = $this->select('id, parent_id', array('c'=>'categories'))
        ->leftJoin(array('l'=>'category_lang'), 'c.id=l.category_id', 'name')
        ->leftJoin(array('u'=>'url_alias'), 'u.id=c.id AND u.type="C"', 'url')
        ->where("c.deleted=0 AND l.lang='".$this->lang."'")
        ;
        if (is_numeric($this->type) && $this->type) {
            $sql->where("c.category_type=".$this->type);
        } else {
            if (is_array($this->type)){
                $t = array(0);
                foreach ($this->type as $v) {
                    $t[] = parseInt($v);
                }
                $sql->where("c.category_type IN (".implode(', ', $t).")");
            }
        }
        $sql->order('parent_id, order, id');
        $rs = $this->query($sql)->fetch('parent_id', true);
        $output = array();
        $output = $this->opt($rs);
        
        return $output;
    }

    public function getOption($edit_id=0) 
    {
        $sql = $this->select('id, parent_id', array('c'=>'categories'))
        ->leftJoin(array('l'=>'category_lang'), 'c.id=l.category_id', 'name')
        ->leftjoin(array('u'=>'url_alias'), 'u.id=c.id AND u.type="C"', 'url')
        ->where("c.deleted=0 AND l.lang='".$this->lang."'")
        ->where("c.id <> $edit_id");
        if (is_numeric($this->type) && $this->type) {
            $sql->where("c.category_type=".$this->type);
        }
        
        $sql->order('parent_id, order, id');
        
        $rs = $this->query($sql)->fetch('parent_id', true);
        
        $output = $this->opt($rs);
        

        
        return $output;
    }
    
    private function opt($ar, $p=0, $lv=0)
    {
        if (!$this->level || $lv<$this->level-1) {
            $output = array();
            if (isset($ar[$p]) && is_array($ar[$p]) && count($ar[$p])) {
                foreach ($ar[$p] as $i=>$row) {
                    $output[$row['id']] = array(
                        'name' => $row['name'], 
                        'haschild' => isset($ar[$row['id']]) && count($ar[$row['id']]) ? 1 : 0,
                        'url' => $row['url'],
                        'level' => $lv,
                    );
                    if (isset($ar[$row['id']])) {
                        $output = array_replace($output, $this->opt($ar,  $row['id'], $lv+1));
                    }
                    
                }
            }
            return $output;
        } else {
            return array();
        }
    }
    
    function getOnce($id)
    {
        $cfg = new Configuration();
        $arlang = Configuration::getLang();
        $arlang = array_keys($cfg->lang);
        $lang = empty($this->lang) ? $arlang[0] : $this->lang;
        $sql = $this->select("*", 'categories c')
        ->leftjoin('url_alias ua', 'c.id=ua.id AND ua.type=\'C\'', 'url')
        ->where('c.id=', $id);
        $rs = $this->query($sql)->fetch();
        if($rs){
            $data = $rs[0];
            // $sql = $this->select('*', 'category_lang')
            // ->where('category_id=', $id)
            // ->where('lang IN (\''.implode('\',\' ', $arlang).'\')');
            // $rs = $this->query($sql)->fetch();
            $query = $this->select('*', 'category_lang')->where('category_id=', $id);
            $category_lang = $query->fetch('lang');
            $keys = $this->getTableSchema('category_lang');
            unset($keys['id']);
            unset($keys['category_id']);
            unset($keys['lang']);
            // print_r($keys);
            $keys = array_keys($keys);
            // print_r($category_lang);exit();
            foreach ($arlang as $lang) {
                foreach ($keys as $key) {
                    $data[$key][$lang] = empty($category_lang[$lang][$key]) ? '' : $category_lang[$lang][$key];
                }
            }
            /*foreach ($rs as $r) {
                unset($r['id']);
                unset($r['category_id']);
                $l = $r['lang'];
                unset($r['lang']);
                foreach ($r as $f => $v) {
                    $data[$f][$l] = $v;
                }
            }*/

            $sql = $this->select('option_id, value, lang', 'category_option')
            ->where('category_id=', $id)
            ->where('lang IN (\''.implode('\',\' ', $arlang).'\')');
            $rs = $this->query($sql)->fetch();
            $data['option'] = array();
            if (is_array($rs)) {
                foreach ($rs as $v) {
                    $data['option'][$v['option_id']][$v['lang']] = $v['value'];
                }
            }
            return $data;
        }
        return array();
    }

    public function getOptionValue($option_id='', $category_id='')
    {
        $sql = $this->select('option_id, category_id, value', 'category_option');
        (strlen($option_id)>0) && $sql->where("option_id IN ($option_id)");
        (strlen($category_id)>0) && $sql->where("category_id IN ($category_id)");
        $rs = $this->query($sql)->fetch();
        $data = array();
        if(is_array($rs))
        {
            foreach ($rs as $r) 
            {
                $data[$r['option_id']][$r['category_id']] = $r['value'];
            }
        }
        return $data;
    }
    
}
