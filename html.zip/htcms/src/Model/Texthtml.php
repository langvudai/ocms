<?php 
namespace Model;
use Htlib\Db\DbTable;
use Htlib\Configuration;
use Htlib\Session;

class Texthtml extends DbTable
{
    public $type = 0, $lang = 'vi', $_name='texthtml';

    public function add($data)
    {
        $data['user_create'] = (int)Session::get('user_id');
        $data['time_create'] = time();
        if (empty($data['name'])) {
            unset($data['name']);
        } else {
            $data['name'] = preg_replace('/[^a-z0-9_\$\.\-]+/i','-',$data['name']);
        }
        $this->insert( $this->parseSchema('texthtml', $data) );
        $id = $this->lastId();
        if ($id && $data['data_type']=='4') {
            $this->insert('texthtml_content', array('texthtml_id'=>$id, 'lang'=>(object)"''", 'value'=>json_encode($data['struct'], JSON_UNESCAPED_UNICODE)));
        }
        return $id;
    }
    public function edit($id, $data)
    {
        $data = $this->parseSchema('texthtml', $data);
        unset($data['id']);
        $rs = $this->update($data, "id=$id");
        return $rs;
    }
    public function saveContent($texthtml_id, $data)
    {
        $arlang = Configuration::getLang();
        if (is_object($arlang)) {
            $arlang = get_object_vars($arlang);
        }
        $data_type = $data['data_type'];
        $value = $data['value'];
        if (is_array($arlang) && count($arlang)>0) {
            foreach( $arlang as $lang=>$text ) {
                if (isset($value[$lang])) {
                    $content = in_array($data_type, array(4,5)) ? json_encode($value[$lang], JSON_UNESCAPED_UNICODE) : $value[$lang];
                    $this->insert('texthtml_content', array(
                        'texthtml_id' => $texthtml_id, 
                        'lang' => $lang, 
                        'value' => $content,
                    ), array('value' => $content));
                }
            }
        }
        return true;
    }
    public function del($id)
    {
        if ($this->update(array('usage'=>(object)'NULL'), "id=$id")) {
            return true;
        }
        return false;
    }
    public function getList(array $where=null, $limit=10, $page=0)
    {
        $query = $this->select('id, name, data_type, description', $this->_name)->where(not_null('usage'))->order('name')->limit($limit, $page);
        empty($where['type'])||$query->where('type=', $where['type']);
        empty($where['id'])||$query->where('id=', $where['id']);
        empty($where['name'])||$query->where('name=', $where['name']);
        return $query->get();
    }
    public function get(array $where=null, $limit=10, $page=0, $sort='')
    {
        $query = $this->select('*', array('t'=>$this->_name))
        ->leftJoin('texthtml_content tc', "texthtml_id=t.id AND t.data_type=2 AND lang='".$this->lang."'", 'value')
        ->where('t.type=', $this->type)
        ->where(not_null('t.usage'))
        ->limit($limit, $page);
        empty($sort) ? $query->order('t.id') : $query->order($sort);
        return $query->get();
    }
    public function getOnce($id)
    {
        $data = $this->select('*', 'texthtml t')
        ->leftJoin('texthtml_content tc', "t.id=texthtml_id AND lang=''", array('keys'=>'value'))
        ->where(not_null('t.usage'))
        ->where('t.id=', $id)
        ->fetchRow();
        $query = $this->select('lang,value', 'texthtml_content')->where('texthtml_id=', $id)->fetchOnce('value', 'lang');
        $arlang = Configuration::getLang();
        if (is_object($arlang)) {
            $arlang = get_object_vars($arlang);
        }
        $data['value'] = array();
        if ($data['data_type']==4) {
            $keys = json_decode($data['keys'], JSON_UNESCAPED_UNICODE);
            $data['keys'] = $keys;
            foreach ($arlang as $lang=>$t) {
                $value = empty($query[$lang]) ? array() : json_decode($query[$lang], JSON_UNESCAPED_UNICODE);
                if (is_object($value)) {
                    $value = get_object_vars($value);
                }
                foreach ($keys as $key) {
                    array_push($data['value'], array(
                        'lang' => $lang,
                        'key'  => $key,
                        'value'=> empty($value[$key]) ? '' : $value[$key]
                    ));
                }
            }
        } elseif ($data['data_type']==5) {
            foreach ($arlang as $lang=>$t) {
                $value = empty($query[$lang]) ? array() : json_decode($query[$lang], JSON_UNESCAPED_UNICODE);
                if (is_object($value)) {
                    $value = get_object_vars($value);
                }
                array_push($data['value'], array(
                    'lang' => $lang,
                    'title'  => empty($value['title']) ? '' : $value['title'],
                    'image'  => empty($value['image']) ? '' : $value['image'],
                    'summary'  => empty($value['summary']) ? '' : $value['summary'],
                    'content'  => empty($value['content']) ? '' : $value['content'],
                ));
            }
        } else {
            foreach ($arlang as $lang=>$t) {
                array_push($data['value'], array(
                    'lang' => $lang,
                    'value'=> empty($query[$lang]) ? '' : $query[$lang]
                ));
            }
        }
        return $data;
    }
    public function getId($name)
    {
        $query = $this->select('id', $this->_name)->where(not_null('usage'))->where('name=', $name)->fetchRow();
        return $query['id'];
    }
}