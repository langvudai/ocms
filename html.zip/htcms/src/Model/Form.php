<?php 
namespace Model;

use Htlib\Configuration;
use Htlib\G;
use Htlib\Gf;
use Htlib\Session;
use Htlib\Db\DbTable;
use Htlib\Db\Expr;

/**
 * 
 */
class Form extends DbTable
{
	function add($data)
	{
		$data = $this->parseSchema('forms', $data);
		$data['user_create'] = Session::get('user_id');
		$data['time_create'] = time();
		$this->insert('forms', $data);
		return $this->lastId();
	}
	function edit($id, $data)
	{
		$data = $this->parseSchema('forms', $data);
		$data['user_id'] = Session::get('user_id');
		$data['time_update'] = time();
		unset($data['id']);
		$this->update('forms', $data, '$id='.$id);
		return true;
	}
	function del($id)
	{
		$data['user_id'] = Session::get('user_id');
		$data['time_update'] = time();
		$this->update('forms', array('usage'=>Expr::null()), '$id='.$id);
		return $this->lastId();
	}
	function get($keyword='', $limit=10, $offset=0)
	{
		$query=$this->select('id, name, header, caption, footer, time_update, user_id', 'forms')
		->where(not_null('usage'))
		->limit($limit, $offset);
		empty($keyword) || is_scalar($keyword) && $query->where("name LIKE '%". str_replace(' ', '%', $keyword) ."%'");
		return $query->get();
	}
}