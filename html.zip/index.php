<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
define('DEBUG', true);
define('DA', __DIR__);
define('DS', DIRECTORY_SEPARATOR);
/* set timezone GMT +7 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
/* include */
require DA.DS. 'includes' .DS. 'app.php';
require DA.DS. 'includes' .DS. 'helper.php';
/* load configs dir */
Configuration::load(DA.DS.'configs');
/* init session */
Session::instance(config('app.paths.sessiond'));
App::boot()->run();
