<?php
return array(
    'compiler' => DA.DS.'data'.DS.'views',
);