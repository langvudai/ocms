<?php 

return array(
    'base_url' => 'http://localhost/',
    'paths' => array(
        'sessiond' => DA.DS. 'data' .DS. 'sessiond', 
        'log_dir' => DA.DS. 'data' .DS. 'log',
    ),
    'mysql' => array(
        'host' => 'localhost',
        'username' => 'root',
        'password' => '',
        'database' => '',
    ),
    'sql_log' => true,
);