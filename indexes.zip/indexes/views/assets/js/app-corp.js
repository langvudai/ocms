$(function() {

	const mediaMd = window.matchMedia('(min-width: 768px)');
	const mediaLg = window.matchMedia('(min-width: 992px)');
	const mediaVLg = window.matchMedia('(min-width: 3992px)');

	/* === DARKER =========================================================== */

	function toggleDarker(duration = 0.3) {

		let template = '<div class="darker"></div>';

		if ($('.darker').length) {
			gsap.to($('.darker'), duration, {
				opacity: 0,
				ease: Power2.easeIn,
				clearProps: 'all',
				onComplete: () => $('.darker').remove()
			});
		} else {
			$(template).appendTo('body');
			gsap.set($('.darker'), {
				opacity: 0
			});
			gsap.to($('.darker'), duration, {
				opacity: 1,
				ease: Power2.easeOut,
				clearProps: 'opacity'
			});
		}

	}

	/* === MENU ============================================================= */

	const sideMenu = {
		container: $('[data-js-menu]'),
		toggleButton: $('[data-js-menu-toggle]'),
		burgerWrapper: $('[data-js-burger-wrapper]'),
		timeLine: gsap.timeline({ paused: true, reversed: true }),
		logoMy: $('[data-js-logo-my]'),
		logoLetters: $('[data-js-logo-letters]'),
		logoArrow: $('[data-js-logo-arrow]'),
		body: $('[data-js-menu-body]'),
		bodyChilds: $('[data-js-menu-body]').children('div'),
		bodyLang: $('[data-js-menu-language]'),
		// sideLang: $('[data-js-side-language]'),
		sideLinks: $('[data-js-side-list]').find('a'),
		isActive: false
	}

	function sideMenuOpenAnim() {

		let	tl = gsap.timeline();

		tl
			.set([sideMenu.container, sideMenu.sideLang, sideMenu.sideLinks, sideMenu.burgerWrapper], {
				clearProps: 'all'
			})
			.set(sideMenu.container, {
				zIndex: 200
			})
			.to(sideMenu.container, 0.8, {
				width: (mediaMd.matches) ? 300 : null,
				height: (mediaMd.matches) ? null : '100%',
				ease: Power4.easeInOut
			})
			.set(sideMenu.burgerWrapper, {
				display: (mediaMd.matches) ? 'none' : null,
				delay: 0.6
			}, 0)
			.to(sideMenu.burgerWrapper, 0.6, {
				opacity: (mediaMd.matches) ? 0 : null,
				ease: Power4.easeInOut
			}, 0)
			.staggerTo(sideMenu.sideLinks, 0.25, {
				opacity: 0,
				y: 20,
				x: 0,
				ease: Power4.easeInOut
			}, 0.075, 0)
			.to(sideMenu.sideLang, 0.3, {
				opacity: 0,
				ease: Power4.easeInOut
			}, 0);

		return tl;

	}
	function sideMenuLogoAnim() {

		let	tl = gsap.timeline();

		tl
			.set([sideMenu.logoMy, sideMenu.logoLetters, sideMenu.logoArrow], { clearProps: 'all' })
			.to(sideMenu.logoMy, 0.4, {
				height: 30,
				'margin-right': 3,
				ease: Power4.easeInOut
			})
			.to(sideMenu.logoArrow, 0.3, {
				height: 31,
				ease: Power4.easeInOut
			}, 0)
			.set(sideMenu.logoLetters, {
				height: 30, //new-year original 30
				left: -3, //new-year
				width: 0
			}, 0.1)
			.to(sideMenu.logoLetters, {
				width: 153,
				'margin-right': 4,
				ease: Power4.easeInOut
			}, 0.1);

		return tl;

	}
	function sideMenuBodyAnim() {

		let	tl = gsap.timeline();

		tl
			.set([sideMenu.body, sideMenu.bodyChilds], { clearProps: 'all' })
			.set(sideMenu.body, {
				width: (mediaMd.matches) ? 0 : null,
				height: (mediaMd.matches) ? null : 0
			})
			.to(sideMenu.body, 0.8, {
				width: (mediaMd.matches) ? 300 : null,
				height: (mediaMd.matches) ? null : '100%',
				ease: Power4.easeInOut
			})
			.set(sideMenu.bodyChilds, {
				opacity: 0,
				x: -50
			}, 0)
			.staggerTo(sideMenu.bodyChilds, 0.35, {
				x: 0,
				opacity: 1,
				ease: Power4.easeInOut
			}, 0.075, 0.5)
			.set(sideMenu.body, {
				'overflow-x': 'hidden',
				'overflow-y': 'auto'
			})
			.fromTo(sideMenu.bodyLang, 0.3, {
				y: '100%'
			}, {
				delay: 0.5,
				y: 0,
				ease: Power4.easeInOut
			}, 0.3);

		return tl;

	}
	function sideMenuCreateAnim() {

		sideMenu.timeLine.clear();
		sideMenu.timeLine
			.add(sideMenuOpenAnim(), 0)
			.add(sideMenuLogoAnim(), 0.2)
			.add(sideMenuBodyAnim(), 0);

	}
	function sideMenuClear() {
		gsap.set([sideMenu.container, sideMenu.logoMy, sideMenu.logoLetters, sideMenu.logoArrow, sideMenu.body, sideMenu.bodyChilds, sideMenu.bodyLang, sideMenu.sideLang, sideMenu.sideLinks, sideMenu.burgerWrapper], { clearProps: 'all' });
		sideMenuCreateAnim();
		sideMenu.timeLine.reverse();
		if (sideMenu.container.hasClass('active') && modal.isActive == false) $('.darker').remove();
		sideMenu.container.removeClass('active');
		sideMenu.isActive = false;
	}
	function sideMenuToggleState() {
		if (sideMenu.isActive == false) {
			sideMenu.isActive = true;
		} else {
			sideMenu.isActive = false;
		}
	}

	sideMenuCreateAnim();
	sideMenu.toggleButton.on('click', (e) => {
		e.preventDefault();
		sideMenu.timeLine.reversed() ? sideMenu.timeLine.play() : sideMenu.timeLine.reverse();
		sideMenu.container.toggleClass('active');
		sideMenuToggleState();
		toggleDarker(0.8);
	});
	$(document).on('click', '.darker', (e) => {
		e.preventDefault();
		if (sideMenu.container.hasClass('active')) {
			sideMenu.timeLine.reverse();
			sideMenu.container.toggleClass('active');
			sideMenuToggleState();
			toggleDarker(0.8);
		}
	});

	/* === COLSPAN / HOVER ================================================== */

	const colspanHover = {
		container: 'data-js-colspan-hover',
		toggleButton: 'data-js-colspan-toggle',
		hiddenElement: 'data-js-colspan-hidden',
		mediaBreakPoint: 'data-js-colspan-hover-media'
	}

	function colspanHoverOpen(el, isHover = false) {
		el.show();
		if (isHover) {
			// right offset
			if (el.offset().left + el.outerWidth() >= window.innerWidth) {
				let offset = el.offset().left + el.outerWidth() - window.innerWidth + 15;
				gsap.set(el, { x: -offset });
			}
			// left offset
			if (el.offset().left <= 0) {
				let offset = Math.abs(el.offset().left) + 15
				gsap.set(el, { x: +offset });
			}
			gsap.set(el, { y: -25, opacity: 0 });
			gsap.to(el, 0.2, { y: 0, opacity: 1, ease: Power4.easeInOut });
		} else {
			gsap.set(el, { height: 0, overflow: 'hidden' });
			gsap.to(el, 0.25, { height: 'auto', ease: Power4.easeInOut, clearProps: 'overflow' });
		}
	}
	function colspanHoverClose(el, isHover = false) {
		if (isHover) {
			gsap.to(el, 0.15, { y: 10, opacity: 0, ease: Power4.easeInOut, clearProps: 'all', onComplete: () => {
					el.hide();
				}});
		} else {
			gsap.set(el, { overflow: 'hidden' })
			gsap.to(el, 0.25, { height: 0, ease: Power4.easeInOut, clearProps: 'all', onComplete: () => {
					el.hide();
				}});
		}
	}
	function colspanHoverClearAll() {
		$('['+colspanHover.container+']').each((i, el) => {
			if ($(el).attr(colspanHover.mediaBreakPoint) == 'mediaMd' && mediaMd.matches) {
				$(el).removeClass('active');
				$(el).find('['+colspanHover.hiddenElement+']').removeAttr('style');
			}
			if ($(el).attr(colspanHover.mediaBreakPoint) == 'mediaLg' && mediaLg.matches) {
				$(el).removeClass('active');
				$(el).find('['+colspanHover.hiddenElement+']').removeAttr('style');
			}
		});
	}

	$('['+colspanHover.toggleButton+']').on('click', (e) => {

		let media = $(e.currentTarget).parent('['+colspanHover.container+']').attr(colspanHover.mediaBreakPoint);

		if (!eval(media).matches) {

			let container = $(e.currentTarget).parent('['+colspanHover.container+']');
			let elToOpen = container.find('['+colspanHover.hiddenElement+']');

			e.preventDefault();

			if (container.hasClass('active')) {
				colspanHoverClose(elToOpen);
			} else {
				colspanHoverOpen(elToOpen);
			}
			container.toggleClass('active');

		}

	});
	$('['+colspanHover.container+']').hover((e) => {
		let media = $(e.currentTarget).attr(colspanHover.mediaBreakPoint);
		if (eval(media).matches) {
			let container = $(e.currentTarget);
			let elToOpen = container.find('['+colspanHover.hiddenElement+']');
			container.addClass('active');
			colspanHoverOpen(elToOpen, true);
		}
	}, (e) => {
		let media = $(e.currentTarget).attr(colspanHover.mediaBreakPoint);
		if (eval(media).matches) {
			let container = $(e.currentTarget);
			let elToOpen = container.find('['+colspanHover.hiddenElement+']');
			container.removeClass('active');
			colspanHoverClose(elToOpen, true);
		}
	});



	/* === TOP SEARCH ======================================================= */

	const topSearch = {
		button: $('[data-js-topsearch-toggle]'),
		overlay: $('.menuSearch__overlay'),
		input: $('#searchinput'),
		tips: $('.search-tips'),
		results: $('#searchresults'),
		buttonClose: $('.menuSearch__close'),
		container: $('.topSearch'),
		input: $('.topSearch__input'),
		timeLine: gsap.timeline({ paused: true, reversed: true })
	}

	topSearch.button.on('click', openSearch);
	topSearch.buttonClose.on('click', closeSearch);

	function openSearch() {
		topSearch.overlay.removeClass('hidden');
		topSearch.input.css({
			visibility: 'inherit',
			width: '100%',
			margin: '50px auto 0'
		});
		topSearch.input.focus();
	}
	function closeSearch() {
		topSearch.overlay.addClass('hidden');
		topSearch.input.val('');
		topSearch.tips.html('');
		topSearch.results.html('');
		topSearch.container.removeClass('active');
	}

	function topSearchInit() {
		topSearch.timeLine
			.set(topSearch.input, { clearProps: 'all' })
			.set(topSearch.input, { autoAlpha: 0 })
			.to(topSearch.input, 0.55, { autoAlpha: 1, width: 460, ease: Back.easeOut });
	}

	topSearchInit();

	topSearch.button.on('click', (e) => {
		e.preventDefault();
		topSearch.timeLine.reversed() ? topSearch.timeLine.play() : topSearch.timeLine.reverse();
		topSearch.container.toggleClass('active');
	})

	$(document).on('click', (e) => {
		if (!$(e.target).closest(topSearch.container).length && !topSearch.timeLine.reversed() && mediaMd.matches) {
			topSearch.timeLine.reverse();
			topSearch.container.toggleClass('active');
		}
	})


	//search
	//search
	const search = {
		debug: false,
		ajaxSearchInit: function(input, tips, form){

			search.input = $(input);
			search.tips = $(tips);
			search.form = $(form)

			search.input.on('change keyup input click', this.ajaxSearch);

			search.tips.on('click', '.search-tip', function(){
				search.input.val($(this).html());
				search.input.focus();
				search.tips.hide();
				search.ajaxSearch();
			});

			search.form.on('submit', function(e) {
				if (search.ajaxSearchTipsSelect)
					return false;
			});

			$(document).on('click','.menuSearch-i',function(e){
				e.stopPropagation();
				e.preventDefault();

				if($('.menuSearch__overlay').length){

					search.input.val('');

				} else if($('.search-form-wrap').length){
					if ($('.search-form-wrap').hasClass('hide'))
					{
						$('.search-form-wrap').removeClass('hide').addClass('show');
						$('.search-form-wrap .searchinput').focus();
					}
				}

			});
			// $(document).on('click','.header-search-overlay .close', this.ajaxSearchClose);
		},
		ajaxSearchTipsSelect:0,
		ajaxSearchTips:[],
		ajaxSearch: function (e){
			let selectedTip;
			let query = search.input.val();
			if (e) {
				if (e.keyCode == 27) { // Escape
					if (search.ajaxSearchTips.length) {
						search.ajaxSearchTipsSelect = 0;
						search.ajaxSearchTips = [];
						$('#searchtips').hide();
						topSearchClose();
						return false;
					} else {
						topSearchClose();
					}

					return;
				} else if (e.keyCode == 40) { // arrow down
					if (search.ajaxSearchTips.length) {
						search.ajaxSearchTipsSelect ++;
						if (search.ajaxSearchTipsSelect > search.ajaxSearchTips.length)
							search.ajaxSearchTipsSelect = 0;

						$ST = $('#searchtips .search-tip');
						$ST.removeClass('select');

						if (search.ajaxSearchTipsSelect){
							$ST.eq(search.ajaxSearchTipsSelect-1).addClass('select');
							selectedTip = search.ajaxSearchTipsSelect-1;
						}

						if (search.debug) console.log (search.ajaxSearchTipsSelect);

					}
					return;
				} else if (e.keyCode == 38) { // arrow up
					if (search.ajaxSearchTips.length) {
						search.ajaxSearchTipsSelect --;
						if (search.ajaxSearchTipsSelect <0)
							search.ajaxSearchTipsSelect = search.ajaxSearchTips.length;

						$ST = $('#searchtips .search-tip');

						$ST.removeClass('select');
						if (search.ajaxSearchTipsSelect){
							$ST.eq(search.ajaxSearchTipsSelect-1).addClass('select');
							selectedTip = search.ajaxSearchTipsSelect-1
						}
						if (search.debug) console.log (search.ajaxSearchTipsSelect);
					}
					return;
				} else if (e.keyCode == 13 || e.keyCode == 39) { // Enter or Right Btn
					if (search.ajaxSearchTipsSelect) {
						$ST = $('#searchtips .search-tip');
						topSearch.input.val($ST.eq(search.ajaxSearchTipsSelect-1).text());
						// $ST.eq(search.ajaxSearchTipsSelect).click()
						// переходим по ссылке
						location.href = location.origin + $ST.eq(search.ajaxSearchTipsSelect-1).attr('href')
						search.ajaxSearchTipsSelect = 0;
						search.ajaxSearchTips = [];
						$('#searchtips').hide();
						search.ajaxSearch();
						return false;
					}
				}
			}

			// if (search.ajaxSearchQuery == query){
			// 	if (search.debug) console.log('return false')
			// 	return false;
			// }

			var oldquery = search.ajaxSearchQuery;
			search.ajaxSearchQuery = query;


			if (search.ajaxSearchInProgess) {
				search.ajaxSearchInProgess ++;
				return false;
			}
//      console.log (DH);
//      if (query.length>2)
			search.ajaxSearchJSON (query, oldquery);
		},
		ajaxSearchJSON: function (query, oldquery) {

			if (!query) {
				search.ajaxSearchInProgess = 0;
				return false;
			}

			search.ajaxSearchInProgess = 1;
			search.form.addClass('sloading');

			var url = '/s/search/?q='+encodeURI(query);

			if (oldquery)
				url += '&oq='+encodeURI(oldquery)

			$.getJSON (url, function (res) {

			}).fail(function(err) {
				console.log(err, 'err');
			}).done(function(data) {
				if (!data)
					return;
				if (data.Tips) {
					search.ajaxSearchShowTips (data.Tips);
				}
				if (data.Results) {
					search.ajaxSearchShowResults (data.Results);
				}
			}).always(function() {
				search.form.removeClass('sloading');
				if (search.ajaxSearchInProgess>1){
					search.ajaxSearchJSON (search.ajaxSearchQuery, query);
				}else {
					search.ajaxSearchInProgess = 0;
				}
			});

		},
		ajaxSearchClose: function (){
			$('.header-search-overlay').stop(true,true).animate({'opacity' :0},600,'easeOutExpo',function(){
				$(this).addClass('hide');
			});
			$('body').css({overflow:'auto'});
		},
		ajaxSearchShowTips: function (Tips){
			search.ajaxSearchTips = Tips;
			$ST = search.tips;
			$ST.html('').show();
			Tips.forEach(function(i) {
				// $ST.append('<div class="search-tip">'+i+'</div>');
				$ST.append(`<li><a href="/s/search?q=${i}" class="search-tip">${i}</a></li>`);
			});
		},
		ajaxSearchShowResults: function (Html){

			$SR = $('#searchresults');
			$SR.hide(500).html(Html).show(500);
		},
	}

	//иницилизация
	if (document.documentElement.clientWidth < 767) {
		search.ajaxSearchInit('#inputsearch-mobile','.searchTips', 'searchformMobile');
		$('.btn-mobileSearch').on('click', function (e) {

			let value = $('#inputsearch-mobile').val()
			let url = location.origin + '/s/search/?q=' + value;
			$(this).attr('href', url)
		});
	} else {
		search.ajaxSearchInit('#searchinput','#searchtips', '#searchform');
	}
	/* === MODALS =========================================================== */

	const modal = {
		data: 'data-js-modal',
		openButton: $('[data-js-modal]'),
		closeButton: $('[data-js-modal-close]'),
		cssClass: 'modal',
		cssLeftClass: 'modal--side-left',
		cssRightClass: 'modal--side-right',
		cssContentClass: 'modal__content',
		cssWrapperClass: 'modal__wrapper',
		isActive: false
	}

	function modalOpen(el, elType, delay) {

		el.show().addClass('active');
		modal.isActive = true;

		$('#nameModal').focus();

		let overflowProp = (el.find('.' + modal.cssContentClass).outerHeight() > window.innerHeight) ? { overflowX: 'hidden' } : { overflowX: 'hidden', overflowY: 'hidden' }

		gsap.set(el.find('.' + modal.cssWrapperClass), overflowProp);
		gsap.set(el.find('.' + modal.cssWrapperClass), { clearProps: 'overflow', delay: (0.35 + delay) });

		switch (elType) {

			case 'left':
				gsap.from(el.find('.' + modal.cssContentClass), 0.35, { x: '-100%', delay: delay, ease: Power4.easeInOut });
				break;

			case 'right':
				gsap.from(el.find('.' + modal.cssContentClass), 0.35, { x: '100%', delay: delay, ease: Power4.easeInOut });
				break;

			default:
				gsap.from(el.find('.' + modal.cssContentClass), 0.35, { opacity: 0, y: -30, delay: delay, ease: Power4.easeInOut });
				break;

		}

	}
	function modalClose(el) {

		let	elType = 'middle';
		let tl = gsap.timeline({
			onComplete: () => {
				gsap.set(el, { clearProps: 'all' });
				gsap.set(el.find('.' + modal.cssContentClass), { clearProps: 'all' });
				el.hide().removeClass('active');
				modal.isActive = false;
			}
		});

		if (el.hasClass(modal.cssLeftClass)) elType = 'left';
		if (el.hasClass(modal.cssRightClass)) elType = 'right';

		let overflowProp = (el.find('.' + modal.cssContentClass).outerHeight() > window.innerHeight) ? { overflowX: 'hidden' } : { overflowX: 'hidden', overflowY: 'hidden' }

		tl.clear();
		gsap.set(el.find('.' + modal.cssWrapperClass), overflowProp);
		gsap.set(el.find('.' + modal.cssWrapperClass), { clearProps: 'overflow', delay: 0.35 });

		switch (elType) {

			case 'left':
				tl.to(el.find('.' + modal.cssContentClass), 0.35, { x: '-100%', ease: Power4.easeInOut });
				break;

			case 'right':
				tl.to(el.find('.' + modal.cssContentClass), 0.35, { x: '100%', ease: Power4.easeInOut });
				break;

			default:
				tl.to(el.find('.' + modal.cssContentClass), 0.35, { opacity: 0, y: 30, ease: Power4.easeInOut });
				break;

		}

		tl.play();

	}

	modal.openButton.on('click', (e) => {

		let	elToOpen = $('#' + $(e.currentTarget).attr(modal.data));
		let elType = 'middle';
		let delay = 0;

		e.stopPropagation();

		if (elToOpen.hasClass(modal.cssLeftClass)) elType = 'left';
		if (elToOpen.hasClass(modal.cssRightClass)) elType = 'right';

		if (!elToOpen.length) return;
		if (elToOpen.hasClass('active')) return;

		if ($('.' + modal.cssClass + '.active').length) {
			modalClose($('.' + modal.cssClass + '.active'));
			delay = 0.3;
		} else {
			if (sideMenu.isActive == false) toggleDarker(0.35);
		}

		modalOpen(elToOpen, elType, delay);

	});
	modal.closeButton.on('click', (e) => {
		modalClose($('.' + modal.cssClass + '.active'));
		if (sideMenu.isActive == false) toggleDarker(0.65);
	})
	$(document).on('click', (e) => {
		if ($('.' + modal.cssClass + '.active').length && !$(e.target).closest('.' + modal.cssContentClass).length) {
			modalClose($('.' + modal.cssClass + '.active'));
			if (sideMenu.isActive == false) toggleDarker(0.65);
		}
	});

	/* === SMOOTH SCROLLBAR ================================================= */

	class HorizontalScrollPlugin extends Scrollbar.ScrollbarPlugin {
		transformDelta(delta, fromEvent) {
			if (!/wheel/.test(fromEvent.type)) return delta;
			const { x, y } = delta;
			return {
				x: (mediaMd.matches) ? delta.y : delta.x,
				y: (mediaMd.matches) ? delta.x : delta.y
			};
		}
	}
	HorizontalScrollPlugin.pluginName = 'horizontalScroll';
	Scrollbar.use(HorizontalScrollPlugin);

	var scrollbar;

	function initScrollbar() {

		if (mediaMd.matches && $('[data-js-main-scrollbar]').length) {
			scrollbar = Scrollbar.init($('[data-js-main-scrollbar]')[0], { damping: .03, alwaysShowTracks: false });
		} else {
			if (scrollbar) scrollbar.destroy();
		}

	}

	if ($('[data-js-main-scrollbar]').length) initScrollbar();

	/* === INDEX ANIMATIONS ================================================= */

	var controller, scenes = [];

	function createScene(triggerElement, duration = null, target, properties) {

		return new ScrollMagic.Scene({
			triggerElement: triggerElement,
			triggerHook: 1,
			duration: duration
		})
			.setTween(gsap.from(target, properties))
			.addTo(controller);

	}
	function indexAddScenes() {

		scenes.push(
			createScene('.s-products__background-thirteen', '130%', '.s-products__background-thirteen', {backgroundPosition: '79% 46%'}), // 13 number
			createScene('.s-company__cover', '130%', '.s-company__cover', {backgroundPosition: '65% 90%'}), // company image
			createScene('.s-company__background-qty-countries', '90%', '.s-company__background-qty-countries', {backgroundPosition: '80% 77%'}), // five number
			createScene('.s-company__greenway-today', '130%', '.s-company__greenway-today', {y: '+=80' }), // title greenway-today
			createScene('.s-company__body', '170%', '.s-company__background-pink', {x: '-=100'}), // leaves block
			createScene('.s-company__body', '130%', $('.s-company__leaves').children()[0], {x: '-=300'}), // leaf
			createScene('.s-company__body', '110%', $('.s-company__leaves').children()[1], {x: '-=110', rotate: '30'}), // leaf
			createScene('.s-company__body', '110%', $('.s-company__leaves').children()[2], {x: '-=150'}), // leaf
			createScene('.s-opportunities__cover', '100%', '.s-opportunities__cover', {backgroundPosition: '230% 50%'}), // opportunities image
			createScene('.s-travel__cover', '150%', '.s-travel__cover', {backgroundPosition: '100% 50%'}), // travel image
			createScene('.s-travel__cover', null, $('.s-travel__cover > img'), {duration: 1, delay: 0.75, x: '-100%', ease: 'expo.out'}), // travel title
			createScene('.s-carbonus__mercedes', '130%', '.s-carbonus__mercedes', {y: '+=80'}), // mercedes title
			createScene('.s-eco__cover', '100%', '.s-eco__cover', {backgroundPosition: '100% 50%'}), // eco image
			createScene('.s-news__cover', '170%', '.s-news__cover', {backgroundPosition: '100% 50%'}), // news image
			createScene('.s-news__background', '170%', '.s-news__background', {backgroundPosition: '90% 90%'}) // news background
		);

	}
	function initController() {

		if ($('[data-js-main-scrollbar]').length) {
			if (mediaMd.matches) {
				controller = new ScrollMagic.Controller({
					vertical: false,
					refreshInterval: 0
				});
				indexAddScenes();
				scrollbar.addListener(() => {
					scenes.forEach(function(scene) {
						scene.refresh();
					});
				});
			} else {
				if (controller) {
					controller = controller.destroy(true);
					gsap.set($('[data-js-animation]'), { clearProps: 'all' });
				}
			}
		}

	}

	initController();

	/* === INDEX SECTION'S COUNTER ========================================== */

	const sections = {
		items: $('.anchorLink'),
		counterCurrent: $('#index-counter-current'),
		counterAll: $('#index-counter-all'),
		anchorLink: '[data-js-anchor-go]'
	}

	function indexAnchors() {

		let	sideMenuIds = [];

		if (sections.counterCurrent.length && mediaMd.matches) {

			sections.counterAll.text(sections.items.length);
			$(sections.anchorLink).toArray().forEach((el) => {
				sideMenuIds.push($(el).attr('href'));
			});
			sections.items.each(function(key) {
				scenes.push(
					new ScrollMagic.Scene({
						triggerElement: this,
						triggerHook: 0.6,
						duration: $(this).width()
					})
						.setClassToggle(this, 'active')
						.on('enter', () => {
							sections.counterCurrent.text(sections.items.toArray().indexOf(this) + 1);
							$(sections.anchorLink).removeClass('active');
							$(`a[href="#${$(this).attr('id')}"]`).addClass("active");
						})
						.addTo(controller)
				);
			});

		}

	}

	indexAnchors();
	$(sections.anchorLink).on('click', (e) => {

		if (scrollbar) {
			let	moveTo = $(e.currentTarget).attr('href').replace('#',''),
				cordinates = (mediaMd.matches) ? $(`a[id="${moveTo}"]`).offset().left + scrollbar.offset.x - 80 : $(`a[id="${moveTo}"]`).offset().top + scrollbar.offset.x - 60;

			e.preventDefault();
			if (mediaMd.matches) {
				scrollbar.scrollTo(cordinates, 0, 1400);
			} else {
				scrollbar.scrollTo(0, cordinates, 1400);
			}
		}

	});

	/* === INDEX: PRODUCTS & NEWS CAROUSELS & ECO =========================== */

	function clearIndexCarouselsStates() {
		if ($('.productsCarousel').length) $('.productsCarousel').find('.productsCarousel__item').removeAttr('style');
		if ($('.newsCarousel').length) $('.newsCarousel').find('.newsCarousel__item').removeAttr('style')
		if ($('.ecoCarousel').length) $('.ecoCarousel').find('.ecoCarousel__item').removeAttr('style');
	}

	if ($('.productsCarousel').length) {
		let productsCarousel = new Swiper ('.productsCarousel', {
			freeMode: true,
			slidesPerView: 'auto',
			simulateTouch: true,
			spaceBetween: 10,
			slidesOffsetBefore: 10,
			slidesOffsetAfter: 10,
			pagination: {
				el: '.productsCarousel__fractions',
				type: 'fraction',
				currentClass: 'carouselPages__current',
				totalClass: 'carouselPages__total'
			},
			navigation: {
				nextEl: '.productsCarousel__arrows--next',
				prevEl: '.productsCarousel__arrows--prev',
				disabledClass: 'carouselArrow--disabled'
			},
			breakpoints: {
				768: {
					freeMode: false,
					slidesPerView: 1,
					spaceBetween: 30,
					slidesOffsetBefore: 0,
					slidesOffsetAfter: 0
				}
			}
		});
	}
	if ($('.newsCarousel').length) {
		let newsCarousel = new Swiper ('.newsCarousel', {
			slidesPerView: 'auto',
			simulateTouch: true,
			spaceBetween: 10,
			slidesOffsetBefore: 10,
			slidesOffsetAfter: 10,
			pagination: {
				el: '.newsPages__fractions',
				type: 'fraction',
				currentClass: 'carouselPages__current',
				totalClass: 'carouselPages__total'
			},
			navigation: {
				nextEl: '.newsPages__arrows--next',
				prevEl: '.newsPages__arrows--prev',
				disabledClass: 'carouselArrow--disabled'
			},
			breakpoints: {
				768: {
					slidesPerView: 3,
					spaceBetween: 30,
					slidesOffsetBefore: 0,
					slidesOffsetAfter: 0
				}
			}
		});
	}
	if ($('.ecoCarousel').length) {
		let ecoCarousel = new Swiper ('.ecoCarousel', {
			slidesPerView: 'auto',
			simulateTouch: true,
			spaceBetween: 10,
			slidesOffsetBefore: 10,
			slidesOffsetAfter: 10,
			navigation: {
				nextEl: '.ecoCarousel__arrows--next',
				prevEl: '.ecoCarousel__arrows--prev',
				disabledClass: 'carouselArrow--disabled'
			},
			pagination: {
				el: '.ecoCarousel__bullets',
				type: 'bullets',
				clickable: true,
				bulletClass: 'carouselBullets__item',
				bulletActiveClass: 'carouselBullets__item--active'
			},
			breakpoints: {
				768: {
					//slidesPerView: 'auto',
					spaceBetween: 60,
					slidesOffsetBefore: 0,
					slidesOffsetAfter: 0
				}
			}
		});
	}

	/* === NEWS: PROMO CAROUSEL ============================================= */

	if ($('.newsPromoCarousel').length) {
		let newsPromoCarousel = new Swiper ('.newsPromoCarousel', {
			slidesPerView: 1,
			simulateTouch: true,
			spaceBetween: 15,
			pagination: {
				el: '.newsPromoCarousel__bullets',
				type: 'bullets',
				clickable: true,
				bulletClass: 'carouselBullets__item',
				bulletActiveClass: 'carouselBullets__item--active'
			},
			breakpoints: {
				768: {
					spaceBetween: 30
				}
			}
		});
	}

	/* === GENERAL SWIPERS ================================================== */

	if ($('[data-js-general-swiper]').length) {
		let generalSwipers = new Swiper ('[data-js-general-swiper]', {
			slidesPerView: 1,
			simulateTouch: true,
			spaceBetween: 15,
			pagination: {
				el: '.carouselBullets',
				type: 'bullets',
				clickable: true,
				bulletClass: 'carouselBullets__item',
				bulletActiveClass: 'carouselBullets__item--active'
			},
			navigation: {
				nextEl: '.carouselArrow--next',
				prevEl: '.carouselArrow--prev',
				disabledClass: 'carouselArrow--disabled'
			},
			breakpoints: {
				576: {
					slidesPerView: 2
				},
				1200: {
					slidesPerView: 3,
					spaceBetween: 30
				}
			}
		});
	}

	/* === COLSPAN ========================================================== */

	const colspan = {
		toggle: 'data-js-colspan',
		optionCloseOther: 'data-js-close-other-colspans'
	}

	function colspanOpen(colspan) {

		let naturalHeight = 0;

		colspan.show().addClass('active');
		naturalHeight = colspan.outerHeight();
		gsap.set(colspan, {
			height: 0,
			opacity: 0,
			overflow: 'hidden'
		});
		gsap.to(colspan, 0.35, {
			height: naturalHeight,
			ease: Power4.easeInOut,
			clearProps: 'height'
		});
		gsap.to(colspan, 0.45, {
			opacity: 1,
			ease: Power4.easeInOut,
			onComplete: () => {
				gsap.set(colspan, { overflow: 'auto' });
			}
		});

	}
	function colspanClose(colspan) {

		gsap.set(colspan, {
			overflow: 'hidden'
		});
		gsap.to(colspan, 0.35, {
			opacity: 0,
			ease: Power4.easeInOut
		});
		gsap.to(colspan, 0.35, {
			height: 0,
			ease: Power4.easeInOut,
			onComplete: () => {
				colspan.hide().removeClass('active');
			},
			clearProps: 'all'
		});

	}

	$('[' + colspan.toggle + ']').on('click', (e) => {

		let toOpen = $('#' + $(e.currentTarget).attr(colspan.toggle)),
			closeOtherFlag = ($(e.currentTarget)[0].hasAttribute(colspan.optionCloseOther)) ? true : false;

		if (closeOtherFlag) {
			$('[' + colspan.toggle + ']').each((i, el) => {
				let toClose = $('#' + $(el).attr(colspan.toggle));
				if (toClose.hasClass('active')) colspanClose(toClose);
			});
		}
		if (toOpen.hasClass('active')) {
			colspanClose(toOpen);
		} else {
			colspanOpen(toOpen);
		}

	});

	/* === SHOW MORE ======================================================== */

	const showMore = {
		toggle: 'data-js-show-more',
		changeTextOption: 'data-js-change-text'
	}

	function showMoreOpen(show) {

		show.addClass('active').data('sourceHeight', show.outerHeight());
		gsap.set(show, {
			'max-height': 'none',
			height: show.outerHeight()
		});
		gsap.to(show, 0.45, {
			height: 'auto',
			ease: Power4.easeInOut
		});

	}
	function showMoreClose(show) {

		show.removeClass('active');
		gsap.to(show, 0.45, {
			height: show.data('sourceHeight'),
			ease: Power4.easeInOut,
			clearProps: 'all',
			onComplete: () => {
				show.removeData('sourceHeight');
			}
		});

	}

	$('[' + showMore.toggle + ']').on('click', (e) => {

		let toOpen = $('#' + $(e.currentTarget).attr(showMore.toggle));

		e.preventDefault();
		if (toOpen.hasClass('active')) {
			showMoreClose(toOpen);
		} else {
			showMoreOpen(toOpen);
		}

	});

	/* === TEXT TOGGLE ====================================================== */

	const textToggle = {
		toggle: 'data-js-text-toggle'
	}

	function elementTextToggle(el) {

		let currentText = el.html();

		el.html(el.attr(textToggle.toggle));
		el.attr(textToggle.toggle, currentText);

	}

	$('[' + textToggle.toggle + ']').on('click', (e) => {
		e.preventDefault();
		elementTextToggle($(e.currentTarget));
	});

	/* === CUSTOM SCROLL BLOCK ============================================== */

	if ($('[data-scrollable-block]').length) {
		let scrollableBlock = new Swiper ('[data-scrollable-block]', {
			slidesPerView: 'auto',
			freeMode: true,
			scrollbar: {
				el: '.swiper-scrollbar',
				hide: true
			},
			mousewheel: true
		});
	}

	/* === FULL SCREEN SLIDER (COMPANY & OPPORTUNITIES) ===================== */

	let fullScreenSlider, scrollSlider = [];

	function swiperScrollBlock() {

		if ($('[data-js-swiper-scrollblock]').length) {
			if (mediaLg.matches) {
				scrollSlider = new Swiper('[data-js-swiper-scrollblock]', {
					direction: 'vertical',
					slidesPerView: 'auto',
					freeMode: true,
					scrollbar: {
						el: '.swiper-scrollbar',
					},
					setWrapperSize: true,
					mousewheel: true
				});
			} else {
				if (Array.isArray(scrollSlider)) {
					scrollSlider.forEach(function(slider) {
						slider.destroy();
					});
				} else {
					scrollSlider.destroy();
				}
			}
		}

	}

	$(window).on('load', function() {
		if ($('[data-js-swiper-scrollblock]').length) {
			if (Array.isArray(scrollSlider)) {
				scrollSlider.forEach(function(slider) {
					slider.updateSize();
					slider.updateSlides();
				});
			} else {
				scrollSlider.updateSize();
				scrollSlider.updateSlides();
			}
		}
	});

	function fullScreenSliderDesktop() {

		if ($('[data-js-fullScreen-slider]').length) {
			if (mediaLg.matches) {
				$('.app').addClass('app--scrollDisable').scrollTop(0);
				fullScreenSlider = new Swiper ('[data-js-fullScreen-slider]', {
					effect: 'fade',
					fadeEffect: {
						crossFade: true
					},
					simulateTouch: false,
					allowTouchMove: false,
					preventInteractionOnTransition: true,
					direction: 'vertical',
					slidesPerView: 1,
					nested: true,
					on: {
						reachEnd: () => {
							$('.app').removeClass('app--scrollDisable').scrollTop(0);
						},
						slideChange: () => {

							let targetSlide = $('[data-js-fullScreen-slider] > .swiper-wrapper > .swiper-slide').eq(fullScreenSlider.activeIndex);
							let animationElements = targetSlide.find('[data-fslider-animation]');

							if (animationElements.length) {

								animationElements.each((i, el) => {

									let type = $(el).data('fsliderType') || 'opacity';
									let delay = $(el).data('fsliderDelay') || 0;

									let duration = $(el).data('fsliderDuration') || 0.3;
									switch (type) {
										case 'fromRight':
											gsap.from($(el), { x: '105%', duration: duration, delay: delay, ease: "expo.inOut", clearProps: 'all' });
											break;
										case 'fromLeft':
											gsap.from($(el), { x: '-105%', duration: duration, delay: delay, ease: "expo.inOut", clearProps: 'all' });
											break;
										case 'fromTop':
											gsap.from($(el), { y: '-105%', duration: duration, delay: delay, ease: "expo.inOut", clearProps: 'all' });
											break;
										case 'fromBottom':
											gsap.from($(el), { y: '105%', duration: duration, delay: delay, ease: "expo.inOut", clearProps: 'all' });
											break;
										case 'revealBottom':
											gsap.from($(el), { opacity: 0, y: '75', duration: duration, delay: delay, ease: "power2.out", clearProps: 'all' });
											break;
										case 'revealTop':
											gsap.from($(el), { opacity: 0, y: '-75', duration: duration, delay: delay, ease: "power2.out", clearProps: 'all' });
											break;
										case 'revealLeft':
											gsap.from($(el), { opacity: 0, x: '-75', duration: duration, delay: delay, ease: "power2.out", clearProps: 'all' });
											break;
										case 'revealRight':
											gsap.from($(el), { opacity: 0, x: '75', duration: duration, delay: delay, ease: "power2.out", clearProps: 'all' });
											break;
									}

								});

							}
							// set current counter
							$('#company-counter-current').text(fullScreenSlider.activeIndex + 1);
						}
					},
					speed: 500
				});
				$('.app').on('wheel', (event) => {
					if (event.originalEvent.deltaY >= 0 && $('.app').scrollTop() < 1) fullScreenSlider.slideNext(); // wheel down change
					if (event.originalEvent.deltaY <= 0 && $('.app').scrollTop() < 1) {
						fullScreenSlider.slidePrev(); // wheel up change
						if (!$('.app').hasClass('app--scrollDisable') && $('.app').scrollTop() < 1) {
							$('.app').addClass('app--scrollDisable');
						}
					}
				});
				// prevent slide change in scrollable blocks
				$('[data-js-swiper-scrollblock]').on('wheel', (event) => {
					event.stopPropagation();
				});
				// counter set all
				$('#company-counter-all').text(fullScreenSlider.slides.length);
			} else {
				$('.app').unbind('wheel');
				$('.app').removeClass('app--scrollDisable');
				if (fullScreenSlider) fullScreenSlider.destroy();
			}
		}

	}

	fullScreenSliderDesktop();
	swiperScrollBlock();

	/* === MEDIA QUERY LISTENER ON RESIZE =================================== */

	mediaMd.addListener(() => {
		sideMenuClear(); // clear menu states on resize.
		initScrollbar(); // smooth scrollbar init / destroy on mobile.
		initController(); // index animation controller init / destroy on mobile.
		indexAnchors(); // index anchors links & section's counter
		clearIndexCarouselsStates(); // index carousels clear mobile states
	});

	mediaLg.addListener(() => {
		fullScreenSliderDesktop(); // full screen slider init / destroy on mobile.
		swiperScrollBlock(); // scrollable block init / destroy on mobile.
	});

	/* === INPUTS MASK ====================================================== */

	$('[data-js-mask-phone]').mask("+7 (000) 000-00-00", {placeholder: "+7"});
	$('[data-js-mask-num]').mask('#', {reverse: true });
	$('[data-js-mask-birthday]').mask('00.00.0000', {placeholder: "__.__.____" });

	/* === OBJECT FIT (for IE) ============================================== */

	objectFitPolyfill($('.s-intro__video'));
	objectFitPolyfill($('[data-js-fit-object]'));

	/* === CUSTOM SELECT ==================================================== */

	$('[data-js-search-select]').selectize();

	/* === ANCHOR LINKS ===================================================== */

	$('a[href^="#"]').on('click', (e) => {
		e.preventDefault();
		if ($(e.currentTarget).attr('href').split('#').pop()) {
			if ($($.attr(e.currentTarget, 'href')).length) {
				$('.app').animate({
					scrollTop: $($.attr(e.currentTarget, 'href')).offset().top - 70
				}, 500);
			}
		}
	});


	/*
		Аргументы:
		name
		название cookie.

		value
		значение cookie (строка).

		props
		объект с дополнительными свойствами для установки cookie:
			expires
			Время истечения cookie. Интерпретируется по-разному, в зависимости от типа:
				Если число - количество секунд до истечения.
				Если объект типа Date - точная дата истечения.
				Если expires в прошлом, то cookie будет удалено.
				Если expires отсутствует или равно 0, то cookie будет установлено как сессионное и исчезнет при закрытии браузера.

			path
			Путь для cookie.

			domain
			Домен для cookie.

			secure
			Пересылать cookie только по защищенному соединению.
	*/
	function setCookie(name, value, props) {
		props = props || {};
		let exp = props.expires;

		if (typeof exp == "number" && exp) {
			let d = new Date();

			d.setTime(d.getTime() + exp * 1000);
			exp = props.expires = d;
		}

		if (exp && exp.toUTCString) {
			props.expires = exp.toUTCString();
		}

		value = encodeURIComponent(value);

		let updatedCookie = name + "=" + value;

		for (let propName in props) {
			updatedCookie += "; " + propName;

			let propValue = props[propName];

			if (propValue !== true) {
				updatedCookie += "=" + propValue;
			}
		}

		document.cookie = updatedCookie;
	}

	function getCookie(name) {
		let matches = document.cookie.match(new RegExp(
			"(?:^|; )" + name.replace(/([.$?*|{}()\[\]\\\/+^])/g, '\\$1') + "=([^;]*)"
		));

		return matches ? decodeURIComponent(matches[1]) : undefined;
	}

	function addChartMenu(attempt = 1) {
		let skey = getCookie('_a_');
		let skey_old = sessionStorage.getItem('pyapi_skey');
		let is_partner = false;
		let redir = getCookie('redirect');

		let add = function () {
			$('#submenu-1 ul.subMenu__list li.subMenu__list-item a[href="/my/business/"]')
				.closest('li')
				.find('ul')
				.append(
					'<li class="subMenu__more-wrapper">' +
					'<a href="//' + window.jsEnv.chart_host +'/dashboard/summary" target="_blank">Аналитика</a>' +
					'</li>'
				);
		};

		let save = function (data) {
			sessionStorage.setItem('pyapi_access_token', data.access_token);
			sessionStorage.setItem('pyapi_token_expired', data.expires_in);
			sessionStorage.setItem('pyapi_skey', data.skey);
			setCookie('pyapi_refresh_token', data.refresh_token, {'domain': window.jsEnv.base_host, 'path': '/'});
		};

		let flush = function () {
			sessionStorage.removeItem('pyapi_access_token');
			sessionStorage.removeItem('pyapi_token_expired');
			sessionStorage.removeItem('pyapi_skey');
			setCookie('pyapi_refresh_token', null, {'domain': window.jsEnv.base_host, 'path': '/', 'expires': -1});
		};

		let redirect = function () {
			setCookie('redirect', null, {'domain': window.jsEnv.base_host, 'path': '/', 'expires': -1});

			if (redir) {
				window.location = redir;
			}
			return false;
		};

		$.ajax({
			url: '/s/l/',
			method: 'post',
			dataType: 'json',
			async: false,
			data: {
				action: 'info'
			},
			success: function(data) {
				if (data && data.Status == 'Ok' && data.Data && data.Data.isPartner) {
					is_partner = data.Data.isPartner;
					return false;
				}
			},
			error: function () {
				return false;
			}
		});

		if (!window.jsEnv || !window.jsEnv.pyapi_host || !skey || !is_partner || attempt > 1) {
			flush();
			return false;
		}

		if (redir || (skey_old && skey !== skey_old)) {
			flush();
		}

		let access_token = sessionStorage.getItem('pyapi_access_token');
		let token_expired = sessionStorage.getItem('pyapi_token_expired');
		let refresh_token = getCookie('pyapi_refresh_token');

		if (access_token && token_expired && Date.now() < token_expired * 1000) {
			add();
			redirect();
		} else if (refresh_token) {
			$.ajax({
				url: '//' + window.jsEnv.pyapi_host + '/pyapi/v1/auth/refresh/',
				method: 'post',
				dataType: 'json',
				async: false,
				data: {
					refresh: refresh_token
				},
				success: function(data) {
					if (data && data.access_token && data.refresh_token && data.expires_in) {
						add();
						data.skey = skey;
						save(data);
						redirect();
					}
				},
				error: function() {
					flush();
					setTimeout(function () { addChartMenu(++attempt); }, 1000);
					return false;
				}
			});
		} else {
			$.ajax({
				url: '//' + window.jsEnv.pyapi_host + '/pyapi/v1/auth/session/',
				method: 'post',
				dataType: 'json',
				async: false,
				data: {
					session_id: skey
				},
				success: function(data) {
					if (data && data.access_token && data.refresh_token && data.expires_in) {
						add();
						data.skey = skey;
						save(data);
						redirect();
					}
				},
				error: function() {
					flush();
					setTimeout(function () { addChartMenu(++attempt); }, 1000);
					return false;
				}
			});
		}
	}
	addChartMenu();

});


////

$('.wrapper-video-auto, .btn-play').on('click',function(){
	// если клик по кнопке плей
	if ($(this).hasClass('btn-play')) {
		const video = $('.wrapper-video-auto');
		video.get(0).play();
		video.parent().removeClass('video-stop');
		setTimeout(()=> video.attr('controls','true'),1000);

	} else {//клик по фону

		if ($(this).parent().hasClass('video-stop')) {
			$(this).parent().removeClass('video-stop')
			setTimeout(()=> $(this).attr('controls','true'),1000)
			this.play();
		}
	}
});
////


var MD5=function(e){function h(a,b){var c,d,e,f,g;e=a&2147483648;f=b&2147483648;c=a&1073741824;d=b&1073741824;g=(a&1073741823)+(b&1073741823);return c&d?g^2147483648^e^f:c|d?g&1073741824?g^3221225472^e^f:g^1073741824^e^f:g^e^f}function k(a,b,c,d,e,f,g){a=h(a,h(h(b&c|~b&d,e),g));return h(a<<f|a>>>32-f,b)}function l(a,b,c,d,e,f,g){a=h(a,h(h(b&d|c&~d,e),g));return h(a<<f|a>>>32-f,b)}function m(a,b,d,c,e,f,g){a=h(a,h(h(b^d^c,e),g));return h(a<<f|a>>>32-f,b)}function n(a,b,d,c,e,f,g){a=h(a,h(h(d^(b|~c),e),g));return h(a<<f|a>>>32-f,b)}function p(a){var b="",d="",c;for(c=0;3>=c;c++)d=a>>>8*c&255,d="0"+d.toString(16),b+=d.substr(d.length-2,2);return b}var f=[],q,r,s,t,a,b,c,d;e=function(a){a=a.replace(/\r\n/g,"\n");for(var b="",d=0;d<a.length;d++){var c=a.charCodeAt(d);128>c?b+=String.fromCharCode(c):(127<c&&2048>c?b+=String.fromCharCode(c>>6|192):(b+=String.fromCharCode(c>>12|224),b+=String.fromCharCode(c>>6&63|128)),b+=String.fromCharCode(c&63|128))}return b}(e);f=function(b){var a,c=b.length;a=c+8;for(var d=16*((a-a%64)/64+1),e=Array(d-1),f=0,g=0;g<c;)a=(g-g%4)/4,f=g%4*8,e[a]|=b.charCodeAt(g)<<f,g++;a=(g-g%4)/4;e[a]|=128<<g%4*8;e[d-2]=c<<3;e[d-1]=c>>>29;return e}(e);a=1732584193;b=4023233417;c=2562383102;d=271733878;for(e=0;e<f.length;e+=16)q=a,r=b,s=c,t=d,a=k(a,b,c,d,f[e+0],7,3614090360),d=k(d,a,b,c,f[e+1],12,3905402710),c=k(c,d,a,b,f[e+2],17,606105819),b=k(b,c,d,a,f[e+3],22,3250441966),a=k(a,b,c,d,f[e+4],7,4118548399),d=k(d,a,b,c,f[e+5],12,1200080426),c=k(c,d,a,b,f[e+6],17,2821735955),b=k(b,c,d,a,f[e+7],22,4249261313),a=k(a,b,c,d,f[e+8],7,1770035416),d=k(d,a,b,c,f[e+9],12,2336552879),c=k(c,d,a,b,f[e+10],17,4294925233),b=k(b,c,d,a,f[e+11],22,2304563134),a=k(a,b,c,d,f[e+12],7,1804603682),d=k(d,a,b,c,f[e+13],12,4254626195),c=k(c,d,a,b,f[e+14],17,2792965006),b=k(b,c,d,a,f[e+15],22,1236535329),a=l(a,b,c,d,f[e+1],5,4129170786),d=l(d,a,b,c,f[e+6],9,3225465664),c=l(c,d,a,b,f[e+11],14,643717713),b=l(b,c,d,a,f[e+0],20,3921069994),a=l(a,b,c,d,f[e+5],5,3593408605),d=l(d,a,b,c,f[e+10],9,38016083),c=l(c,d,a,b,f[e+15],14,3634488961),b=l(b,c,d,a,f[e+4],20,3889429448),a=l(a,b,c,d,f[e+9],5,568446438),d=l(d,a,b,c,f[e+14],9,3275163606),c=l(c,d,a,b,f[e+3],14,4107603335),b=l(b,c,d,a,f[e+8],20,1163531501),a=l(a,b,c,d,f[e+13],5,2850285829),d=l(d,a,b,c,f[e+2],9,4243563512),c=l(c,d,a,b,f[e+7],14,1735328473),b=l(b,c,d,a,f[e+12],20,2368359562),a=m(a,b,c,d,f[e+5],4,4294588738),d=m(d,a,b,c,f[e+8],11,2272392833),c=m(c,d,a,b,f[e+11],16,1839030562),b=m(b,c,d,a,f[e+14],23,4259657740),a=m(a,b,c,d,f[e+1],4,2763975236),d=m(d,a,b,c,f[e+4],11,1272893353),c=m(c,d,a,b,f[e+7],16,4139469664),b=m(b,c,d,a,f[e+10],23,3200236656),a=m(a,b,c,d,f[e+13],4,681279174),d=m(d,a,b,c,f[e+0],11,3936430074),c=m(c,d,a,b,f[e+3],16,3572445317),b=m(b,c,d,a,f[e+6],23,76029189),a=m(a,b,c,d,f[e+9],4,3654602809),d=m(d,a,b,c,f[e+12],11,3873151461),c=m(c,d,a,b,f[e+15],16,530742520),b=m(b,c,d,a,f[e+2],23,3299628645),a=n(a,b,c,d,f[e+0],6,4096336452),d=n(d,a,b,c,f[e+7],10,1126891415),c=n(c,d,a,b,f[e+14],15,2878612391),b=n(b,c,d,a,f[e+5],21,4237533241),a=n(a,b,c,d,f[e+12],6,1700485571),d=n(d,a,b,c,f[e+3],10,2399980690),c=n(c,d,a,b,f[e+10],15,4293915773),b=n(b,c,d,a,f[e+1],21,2240044497),a=n(a,b,c,d,f[e+8],6,1873313359),d=n(d,a,b,c,f[e+15],10,4264355552),c=n(c,d,a,b,f[e+6],15,2734768916),b=n(b,c,d,a,f[e+13],21,1309151649),a=n(a,b,c,d,f[e+4],6,4149444226),d=n(d,a,b,c,f[e+11],10,3174756917),c=n(c,d,a,b,f[e+2],15,718787259),b=n(b,c,d,a,f[e+9],21,3951481745),a=h(a,q),b=h(b,r),c=h(c,s),d=h(d,t);return(p(a)+p(b)+p(c)+p(d)).toLowerCase()};

function _(text) {
	return text;
}

///////////////////// AUTH LOGIC
let status = '';

function _Send (form) {
	$('#statusModal').html(_(text.login_request)).removeClass('alert-danger').addClass('alert-info');
	status = 'send';

	let url = '/s/l/';
//    if (document.location.protocol=='http:' && $('#modalUseSsl').prop('checked')) {
//      url+= 'https://'+document.location.host;
//    }
//    url += '/s/l/';
	$.ajax({
		url: url,
		method:'post',
		dataType:'json',
		data:{
			type:'auth',
			action:'sessionkey'
		},
		success: function(data) {
			let sError = '';
			if (!data) {
				sError = _(text.login_error_no_data);

			} else if (data.Status === 'Error') {
				sError = data.Message;

			} else if (!data.Key) {
				sError = _(text.login_error_no_key)

			} else {
				var key = data.Key;
				$('#statusModal').html(_(text.login_allow));
				window.setTimeout (auth(key),500);
			}
			if (sError) {
				$('#statusModal').html(sError).addClass('alert-danger');
			}
		},
		error: function(data, type){
			$('#statusModal').html(_(text.login_error_connect)).addClass('alert-danger');

		},
		complete: function () {
			status = '';
		}
	});

	function auth (key) {
		$('#statusModal').removeClass('alert-danger').addClass('alert-info').html(_(text.login_auth));

		let checkSSL = document.location.href.replace('http://','https://');

		$.ajax(
			checkSSL,
			{
				success: function () {
					checkSSL = true
				},
				error: function () {
					checkSSL = false;
				},
				method: "head"
			}
		);


		if (checkSSL === true) {
			// if (document.location.protocol=='http:' && $('#modalUseSsl').prop('checked')) {
			$('#hiddenName').val($('#nameModal').val());
			$('#hiddenLocation').val(document.location.href.replace('http://','https://'));
			$('#hiddenPassword').val(MD5(key+MD5($('#passwordModal').val())));
			$('#hiddenLoginForm').attr('action', 'https://'+document.location.host+'/s/l/');
			$('#hiddenLoginForm').submit();
			return false;
		}

		$.ajax({
			url: '/s/l/',
			method:'post',
			dataType:'json',
			data:{
				type:'auth',
				action:'login',
				REMEMBER:($('#remembermeModal').prop('checked')==true?1:0),
				NAME:$('#nameModal').val(),
				PASSWORD:(MD5(key+MD5($('#passwordModal').val())))
			},
			success: function(data) {
				let sError = '';
				if (!data) {
					sError = _(text.login_error_no_data);
				} else if (data.Status == 'Error') {
					sError = data.Message;
				} else if (data.Status == 'Ok') {
					$('#statusModal').html(data.Message).removeClass('alert-danger');
					document.location = '/my/';
					return false;
				}
				if (sError) {
					$('#statusModal').html(sError).addClass('alert-danger');
				}
			},
			error: function(data, type){
				$('#statusModal').html(_(text.login_error_connect)).addClass('alert-danger');
			},
			complete: function () {
				status = '';
			}
		});
	}
	return false;
}
