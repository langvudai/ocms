<?php 

/**
 * 
 */
class Module_Mvc_AdminController extends Base
{
    private $messages, $properties;

    /**
     * run
     * @return void
     */
    public final function run()
    {
        // $process = new Module_Admin_Process_Login();
        // $process->verifyCurrentPassword(1, '');
        // exit('pppppppppp');

        $this->set('app', new App());
        $time = $this->app->start === null ? 1 : $this->app->start;
        Log::open('app')->info('start app', $time);

        $user_id = session()->user_id;
        $is_login_controller = get_class($this) === 'Module_Admin_Controller_Login';
        if (!$is_login_controller && !$user_id) {
            redirect('/login');
            exit();
        }
        
        $anti_request_forgery = session()->uniqueValue(true);
        if (!$is_login_controller && $this->app->arf !== $anti_request_forgery) {
            redirect('/login');
            exit();
        }
        $model = new Module_Admin_Model_Auth($user_id);        
        Module_Mvc_View::setUserModel($model);
        $messages = session()->get('messages');
        session()->delete('messages');
        Module_Mvc_View::setMessages($messages);
        $this->set('auth', $model);

        $method = Request::getMethod().'_'.$this->app->method;
        if (!$this->hasMethod($method)) {
            $method = $this->app->method;
        }

        $result = $this->invokeMethod($method);
        
        if ($result === false) {
            return false;
        }

        if (is_object($result)) {
            try {
                $render = $this->getReflectionMethod($result, 'render');
                if ($render->isPublic()) {
                    $render->invoke($result);
                }
            } catch (Exception $e) {
                Log::open('app')->error($e->getMessage());
            }
        } else {
            $data = is_array($result) && isset($result[1]) ? $result[1] : null;
            $template = is_string($result) ? $result : (is_array($result) && isset($result[0]) && is_string($result[0]) ? $result[0] : null);
            if (file_exists($template) && is_readable($template) && is_file($template)) {
                $this->includeTemplate($template, $data);
            } else {
                $template = Configuration::get('app.paths.view_dir') .'/'. $template .'.php';
                if (file_exists($template) && is_readable($template) && is_file($template)) {
                    $this->includeTemplate($template, $data);
                }
            }
        }
        $end_time = function_exists('microtime') ? microtime(true) : 0;
        Log::open('app')->info('end app', $end_time - $time);
    }

    public function __get($name)
    {
        return is_array($this->properties) && isset($this->properties[$name]) ? $this->properties[$name] : null;
    }

    /**
     * @param string $name
     * @param mixed $value
     */
    protected final function set($name, $value)
    {
        if (is_array($this->properties)) {
            $this->properties[$name] = $value;
        } else {
            $this->properties = array($name => $value);
        }
    }

    /**
     * @param string $message
     * @param string $type
     */
    protected final function message($message, $type = null)
    {
        if (!$this->messages) {
            $this->messages = array(array($message, $type));
        } else {
            $this->messages[] = array($message, $type);
        }
    }

    public function __destruct()
    {
        if ($this->messages) {
            session()->set('messages', $this->messages);
        }
    }
}