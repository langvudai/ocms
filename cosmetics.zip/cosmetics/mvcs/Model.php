<?php 
class Module_Mvc_Model
{
    private $publisher;

    final function __get($name)
    {
        return is_array($this->publisher) && isset($this->publisher[$name]) ? $this->publisher[$name] : null;
    }

    final function __set($name, $value)
    {

    }
    
    final function set($name, $value)
    {
        $name = to_camel_case($name);
        if (is_array($this->publisher)) {
            $this->publisher[$name] = $value;
        } else {
            $this->publisher = array($name => $value);
        }
    }
}