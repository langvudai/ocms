<?php 

class Cosmetic_Index_Controller_Home extends Cosmetic_Mvc_Controller
{
    function index()
    {
        return new Cosmetic_Mvc_View('home');
    }
}