<?php 

return array(
    array(
        '!' => function() {
            echo "page not fond";
        },
        '/' => array('class' => 'Cosmetic_Index_Controller_Home::index'),
    ),
    function($_this) {
        Module_Mvc_View::setViewDir(__DIR__.DS.'views');
        Module_Mvc_View::setCompilerDir(config('view.compiler'));
    }
);